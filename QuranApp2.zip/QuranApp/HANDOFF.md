# تطبيق القرآن الكريم — HANDOFF

## شنو كاين دابا (v1.0.0)
- **قراءة المصحف** بالرسم العثماني، 114 سورة و6236 آية، كيخدم **بلا أنترنيت** (`app/src/main/assets/quran.json`).
- **الاستماع**: 6 قراء (everyayah.com)، آية بآية، كيتابع الآية اللي كتتقرا، تكرار الآية، الصوت كيكمل فالخلفية مع إشعار (Media3).
- **التفسير**: الميسر والجلالين (api.alquran.cloud). كيتجاب أول مرة من الأنترنيت ومن بعد كيتخبا فالتلفون.
- **الترجمة**: فرنسية (Hamidullah) أو إنجليزية (Saheeh International) أو بلا.
- **البحث**: بالعربية بلا تشكيل (وكيقبل الصراط/الصرط…) وفالترجمات.
- **العلامات** + **كمّل القراءة** (آخر آية وقفتي فيها).
- الإعدادات: حجم الخط، الترجمة، التفسير، القارئ. وضع ليلي أوتوماتيكي.

## التقنية
Kotlin 2.0.21 • Jetpack Compose (Material 3) • Navigation Compose • DataStore • Media3 ExoPlayer/Session • kotlinx.serialization
minSdk 26 • targetSdk 35 • AGP 8.7.3 • Gradle 8.11.1

```
app/src/main/java/ma/quran/app/
├── QuranApplication.kt      ← كيصاوب الـ repositories
├── MainActivity.kt          ← RTL + Theme
├── data/                    ← Models, QuranRepository (القراءة+البحث), TafsirRepository, PrefsRepository
├── player/                  ← PlaybackService (خدمة الصوت), PlayerController
└── ui/                      ← QuranViewModel, QuranNavHost, theme/, screens/
```

## كيفاش تبنيه
1. حل الدوسي `QuranApp` فـ **Android Studio** (Ladybug أو أحدث).
2. خليه يدير Gradle Sync (كيحتاج أنترنيت أول مرة).
3. Run ▶ على تلفون أو Emulator.

> ⚠️ المشروع تكتب بلا ما يتبنى (ما كانش Android SDK فالبيئة ديالي). إلا طلع شي خطأ فالكومبيل، صيفط ليا الرسالة ونصلحوه.

## قبل النشر فـ Play Store
- [ ] بدل `applicationId` فـ `app/build.gradle.kts` (مثلا `com.smiytk.quran`) وبدل `namespace` والدوسي ديال الـ package إلا بغيتي.
- [ ] أيقونة نهائية (Android Studio → New → Image Asset).
- [ ] صاوب keystore وسيني الـ release: Build → Generate Signed App Bundle (.aab).
- [ ] **Privacy Policy** (ضروري): التطبيق ما كيجمع حتى معلومة شخصية، غير كيتصل بـ everyayah.com و alquran.cloud.
- [ ] Data safety form فـ Play Console: "No data collected".
- [ ] Screenshots (2 على الأقل) + وصف بالعربية والفرنسية.
- [ ] جرب على تلفون حقيقي: الصوت فالخلفية، الإشعار، الوضع الليلي، البحث.

## أفكار للنسخة الجاية
- **رواية ورش** (اللي كيقراو بيها فالمغرب): كتحتاج نص ورش + خط ورش + قارئ بورش (everyayah فيه دوسي `warsh`).
- تحميل السور للاستماع بلا أنترنيت.
- عرض صفحات المصحف (604 صفحة) بحال المصحف الورقي، وأجزاء/أحزاب.
- مواقيت الصلاة والقبلة.
- تفسير بالفرنسية.

## المصادر والتراخيص
- نص المصحف والترجمات: حزمة npm `quran-json` 3.1.2 (CC-BY-SA 4.0) ← quranenc.com و tanzil.net
- الخط: Amiri Quran (SIL OFL 1.1)
- التفسير: api.alquran.cloud • التلاوات: everyayah.com
