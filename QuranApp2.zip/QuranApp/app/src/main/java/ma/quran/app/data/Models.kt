package ma.quran.app.data

import kotlinx.serialization.Serializable
import java.util.Locale

@Serializable
data class SurahDto(
    val id: Int,
    val name: String,
    val tr: String,
    val meaning: String,
    val meaningEn: String,
    val type: String,
    val verses: List<VerseDto>,
)

@Serializable
data class VerseDto(val ar: String, val fr: String, val en: String)

data class Surah(
    val id: Int,
    val name: String,
    val transliteration: String,
    val meaningFr: String,
    val meaningEn: String,
    val isMeccan: Boolean,
    val ayahs: List<Ayah>,
)

data class Ayah(
    val surah: Int,
    val number: Int,
    val text: String,
    val fr: String,
    val en: String,
    /** نص بلا تشكيل، للبحث */
    val plain: String,
) {
    val key: String get() = "$surah:$number"
}

data class AyahRef(val surah: Int, val ayah: Int) {
    override fun toString() = "$surah:$ayah"

    companion object {
        fun parse(s: String?): AyahRef? {
            val p = s?.split(":") ?: return null
            if (p.size != 2) return null
            val a = p[0].toIntOrNull() ?: return null
            val b = p[1].toIntOrNull() ?: return null
            return AyahRef(a, b)
        }
    }
}

enum class Translation(val label: String) { NONE("بلا ترجمة"), FR("Français"), EN("English") }

enum class TafsirEdition(val apiId: String, val label: String) {
    MUYASSAR("ar.muyassar", "التفسير الميسر"),
    JALALAYN("ar.jalalayn", "تفسير الجلالين"),
}

data class Reciter(val id: String, val name: String, val folder: String) {
    /** صوت آية واحدة من everyayah.com */
    fun url(surah: Int, ayah: Int) =
        String.format(Locale.ROOT, "https://everyayah.com/data/%s/%03d%03d.mp3", folder, surah, ayah)
}

val RECITERS = listOf(
    Reciter("alafasy", "مشاري العفاسي", "Alafasy_128kbps"),
    Reciter("abdulbasit", "عبد الباسط عبد الصمد (مرتل)", "Abdul_Basit_Murattal_192kbps"),
    Reciter("husary", "محمود خليل الحصري", "Husary_128kbps"),
    Reciter("minshawy", "محمد صديق المنشاوي (مرتل)", "Minshawy_Murattal_128kbps"),
    Reciter("maher", "ماهر المعيقلي", "MaherAlMuaiqly128kbps"),
    Reciter("shuraym", "سعود الشريم", "Saood_ash-Shuraym_128kbps"),
)

fun Int.toArabicDigits(): String =
    toString().map { if (it.isDigit()) '٠' + (it - '0') else it }.joinToString("")
