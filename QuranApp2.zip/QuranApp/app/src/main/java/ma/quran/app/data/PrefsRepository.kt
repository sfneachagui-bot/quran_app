package ma.quran.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("settings")

data class Settings(
    val fontSize: Float = 26f,
    val translation: Translation = Translation.FR,
    val reciterId: String = RECITERS.first().id,
    val tafsir: TafsirEdition = TafsirEdition.MUYASSAR,
) {
    val reciter: Reciter get() = RECITERS.firstOrNull { it.id == reciterId } ?: RECITERS.first()
}

class PrefsRepository(private val context: Context) {
    private object K {
        val bookmarks = stringSetPreferencesKey("bookmarks")
        val lastRead = stringPreferencesKey("last_read")
        val fontSize = floatPreferencesKey("font_size")
        val translation = stringPreferencesKey("translation")
        val reciter = stringPreferencesKey("reciter")
        val tafsir = stringPreferencesKey("tafsir")
    }

    val bookmarks: Flow<List<AyahRef>> = context.dataStore.data.map { p ->
        (p[K.bookmarks] ?: emptySet()).mapNotNull { AyahRef.parse(it) }
            .sortedWith(compareBy({ it.surah }, { it.ayah }))
    }

    val lastRead: Flow<AyahRef?> = context.dataStore.data.map { AyahRef.parse(it[K.lastRead]) }

    val settings: Flow<Settings> = context.dataStore.data.map { p ->
        Settings(
            fontSize = p[K.fontSize] ?: 26f,
            translation = p[K.translation]?.let { runCatching { Translation.valueOf(it) }.getOrNull() } ?: Translation.FR,
            reciterId = p[K.reciter] ?: RECITERS.first().id,
            tafsir = p[K.tafsir]?.let { runCatching { TafsirEdition.valueOf(it) }.getOrNull() } ?: TafsirEdition.MUYASSAR,
        )
    }

    suspend fun toggleBookmark(ref: AyahRef) = context.dataStore.edit { p ->
        val cur = p[K.bookmarks] ?: emptySet()
        val k = ref.toString()
        p[K.bookmarks] = if (k in cur) cur - k else cur + k
    }

    suspend fun setLastRead(ref: AyahRef) = context.dataStore.edit { it[K.lastRead] = ref.toString() }
    suspend fun setFontSize(v: Float) = context.dataStore.edit { it[K.fontSize] = v }
    suspend fun setTranslation(t: Translation) = context.dataStore.edit { it[K.translation] = t.name }
    suspend fun setReciter(id: String) = context.dataStore.edit { it[K.reciter] = id }
    suspend fun setTafsir(t: TafsirEdition) = context.dataStore.edit { it[K.tafsir] = t.name }
}
