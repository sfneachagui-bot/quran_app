package ma.quran.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

class QuranRepository(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true }
    private val mutex = Mutex()
    private var cache: List<Surah>? = null
    private var skeletons: Map<String, String> = emptyMap()

    suspend fun surahs(): List<Surah> = mutex.withLock {
        cache ?: withContext(Dispatchers.IO) {
            val text = context.assets.open("quran.json").bufferedReader().use { it.readText() }
            val dtos = json.decodeFromString<List<SurahDto>>(text)
            dtos.map { s ->
                Surah(
                    id = s.id,
                    name = s.name,
                    transliteration = s.tr,
                    meaningFr = s.meaning,
                    meaningEn = s.meaningEn,
                    isMeccan = s.type == "meccan",
                    ayahs = s.verses.mapIndexed { i, v ->
                        Ayah(s.id, i + 1, v.ar, v.fr, v.en, ArabicText.normalize(v.ar))
                    },
                )
            }.also { list ->
                skeletons = list.flatMap { it.ayahs }.associate { it.key to ArabicText.skeleton(it.plain) }
                cache = list
            }
        }
    }

    suspend fun surah(id: Int): Surah? = surahs().getOrNull(id - 1)

    suspend fun ayah(ref: AyahRef): Ayah? = surah(ref.surah)?.ayahs?.getOrNull(ref.ayah - 1)

    /** البحث فالنص العربي (بلا تشكيل) وفالترجمات */
    suspend fun search(query: String, limit: Int = 300): List<Ayah> = withContext(Dispatchers.Default) {
        val q = query.trim()
        if (q.length < 2) return@withContext emptyList()
        val all = surahs()
        val isArabic = q.any { it in '؀'..'ۿ' }
        val results = ArrayList<Ayah>()
        if (isArabic) {
            val nq = ArabicText.normalize(q)
            val sq = ArabicText.skeleton(nq)
            for (s in all) for (a in s.ayahs) {
                if (a.plain.contains(nq) || (sq.length >= 2 && skeletons[a.key]?.contains(sq) == true)) {
                    results += a
                    if (results.size >= limit) return@withContext results
                }
            }
        } else {
            for (s in all) for (a in s.ayahs) {
                if (a.fr.contains(q, ignoreCase = true) || a.en.contains(q, ignoreCase = true)) {
                    results += a
                    if (results.size >= limit) return@withContext results
                }
            }
        }
        results
    }
}
