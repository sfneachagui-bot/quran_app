package ma.quran.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import ma.quran.app.ui.screens.BookmarksScreen
import ma.quran.app.ui.screens.HomeScreen
import ma.quran.app.ui.screens.MiniPlayer
import ma.quran.app.ui.screens.ReaderScreen
import ma.quran.app.ui.screens.SearchScreen
import ma.quran.app.ui.screens.SettingsScreen
import ma.quran.app.ui.screens.TafsirSheet

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", "الفهرس", Icons.AutoMirrored.Filled.MenuBook),
    Tab("search", "البحث", Icons.Filled.Search),
    Tab("bookmarks", "العلامات", Icons.Filled.Bookmarks),
    Tab("settings", "الإعدادات", Icons.Filled.Settings),
)

fun readerRoute(surah: Int, ayah: Int = 1) = "reader/$surah?ayah=$ayah"

@Composable
fun QuranNavHost() {
    val vm: QuranViewModel = viewModel()
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val onTab = tabs.any { it.route == route }
    val openReader: (Int, Int) -> Unit = { s, a -> nav.navigate(readerRoute(s, a)) }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            Column {
                MiniPlayer(vm = vm, onOpen = { ref -> openReader(ref.surah, ref.ayah) })
                if (onTab) {
                    NavigationBar {
                        tabs.forEach { t ->
                            NavigationBarItem(
                                selected = route == t.route,
                                onClick = {
                                    nav.navigate(t.route) {
                                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(t.icon, null) },
                                label = { Text(t.label) },
                            )
                        }
                    }
                } else {
                    Spacer(Modifier.navigationBarsPadding())
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = "home", modifier = Modifier.fillMaxSize().padding(padding)) {
            composable("home") { HomeScreen(vm, openReader) }
            composable("search") { SearchScreen(vm, openReader) }
            composable("bookmarks") { BookmarksScreen(vm, openReader) }
            composable("settings") { SettingsScreen(vm) }
            composable(
                "reader/{surah}?ayah={ayah}",
                arguments = listOf(
                    navArgument("surah") { type = NavType.IntType },
                    navArgument("ayah") { type = NavType.IntType; defaultValue = 1 },
                ),
            ) { e ->
                ReaderScreen(
                    vm = vm,
                    surahId = e.arguments?.getInt("surah") ?: 1,
                    startAyah = e.arguments?.getInt("ayah") ?: 1,
                    onBack = { nav.popBackStack() },
                    onOpenSurah = { s -> nav.navigate(readerRoute(s)) { popUpTo("reader/{surah}?ayah={ayah}") { inclusive = true } } },
                )
            }
        }
    }
    TafsirSheet(vm)
}
