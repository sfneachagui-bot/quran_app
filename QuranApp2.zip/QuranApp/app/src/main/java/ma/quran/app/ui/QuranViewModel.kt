package ma.quran.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import ma.quran.app.QuranApplication
import ma.quran.app.data.Ayah
import ma.quran.app.data.AyahRef
import ma.quran.app.data.Settings
import ma.quran.app.data.Surah
import ma.quran.app.data.TafsirEdition
import ma.quran.app.data.Translation

sealed interface TafsirState {
    data object Loading : TafsirState
    data class Loaded(val text: String) : TafsirState
    data class Failed(val message: String) : TafsirState
}

class QuranViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as QuranApplication
    val player = a.player

    private val _surahs = MutableStateFlow<List<Surah>>(emptyList())
    val surahs: StateFlow<List<Surah>> = _surahs.asStateFlow()

    val settings = a.prefs.settings.stateIn(viewModelScope, SharingStarted.Eagerly, Settings())
    val bookmarks = a.prefs.bookmarks.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val lastRead = a.prefs.lastRead.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _searchResults = MutableStateFlow<List<Ayah>>(emptyList())
    val searchResults = _searchResults.asStateFlow()
    private var searchJob: Job? = null

    private val _tafsir = MutableStateFlow<Pair<Ayah, TafsirState>?>(null)
    val tafsir = _tafsir.asStateFlow()

    init {
        viewModelScope.launch { _surahs.value = a.quran.surahs() }
        player.connect()
    }

    fun search(q: String) {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(300)
            _searchResults.value = a.quran.search(q)
        }
    }

    fun ayah(ref: AyahRef): Ayah? = _surahs.value.getOrNull(ref.surah - 1)?.ayahs?.getOrNull(ref.ayah - 1)

    fun toggleBookmark(ref: AyahRef) = viewModelScope.launch { a.prefs.toggleBookmark(ref) }
    fun saveLastRead(ref: AyahRef) = viewModelScope.launch { a.prefs.setLastRead(ref) }

    fun play(surah: Surah, fromAyah: Int) = player.playSurah(surah, fromAyah, settings.value.reciter)

    fun openTafsir(ayah: Ayah, edition: TafsirEdition = settings.value.tafsir) {
        _tafsir.value = ayah to TafsirState.Loading
        viewModelScope.launch {
            val r = a.tafsir.tafsir(edition, ayah.surah, ayah.number)
            if (_tafsir.value?.first == ayah) {
                _tafsir.value = ayah to r.fold(
                    { TafsirState.Loaded(it) },
                    { TafsirState.Failed("ما قدرناش نجيبو التفسير. تأكد من الأنترنيت (أول مرة فقط) وعاود.") },
                )
            }
        }
    }

    fun changeTafsirEdition(ayah: Ayah, e: TafsirEdition) {
        viewModelScope.launch { a.prefs.setTafsir(e) }
        openTafsir(ayah, e)
    }

    fun closeTafsir() { _tafsir.value = null }

    fun setFontSize(v: Float) = viewModelScope.launch { a.prefs.setFontSize(v) }
    fun setTranslation(t: Translation) = viewModelScope.launch { a.prefs.setTranslation(t) }
    fun setReciter(id: String) = viewModelScope.launch { a.prefs.setReciter(id) }
    fun setTafsir(t: TafsirEdition) = viewModelScope.launch { a.prefs.setTafsir(t) }
}
