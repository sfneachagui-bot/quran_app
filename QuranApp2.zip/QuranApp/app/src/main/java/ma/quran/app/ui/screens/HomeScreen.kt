package ma.quran.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ma.quran.app.data.toArabicDigits
import ma.quran.app.ui.QuranViewModel
import ma.quran.app.ui.theme.QuranFont

@Composable
fun HomeScreen(vm: QuranViewModel, openReader: (Int, Int) -> Unit) {
    val surahs by vm.surahs.collectAsStateWithLifecycle()
    val last by vm.lastRead.collectAsStateWithLifecycle()

    if (surahs.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        return
    }

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding()) {
        item {
            Text(
                "القرآن الكريم",
                fontFamily = QuranFont,
                fontSize = 34.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 8.dp),
            )
        }
        last?.let { ref ->
            val s = surahs.getOrNull(ref.surah - 1)
            if (s != null) item {
                Card(
                    onClick = { openReader(ref.surah, ref.ayah) },
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                    ),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Text("كمّل القراءة", style = MaterialTheme.typography.labelLarge)
                        Text(
                            "سورة ${s.name}",
                            fontFamily = QuranFont,
                            fontSize = 28.sp,
                        )
                        Text("الآية ${ref.ayah.toArabicDigits()}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        items(surahs, key = { it.id }) { s ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { openReader(s.id, 1) }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                NumberBadge(s.id)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.transliteration, fontWeight = FontWeight.SemiBold)
                    Text(
                        "${if (s.isMeccan) "مكية" else "مدنية"} • ${s.ayahs.size.toArabicDigits()} آية",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    )
                }
                Text(
                    s.name,
                    fontFamily = QuranFont,
                    fontSize = 24.sp,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            HorizontalDivider(Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
        }
    }
}
