package ma.quran.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import ma.quran.app.data.Ayah
import ma.quran.app.data.AyahRef
import ma.quran.app.data.Settings
import ma.quran.app.data.Surah
import ma.quran.app.data.Translation
import ma.quran.app.data.toArabicDigits
import ma.quran.app.ui.QuranViewModel
import ma.quran.app.ui.theme.QuranFont

private const val BASMALA = "بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ"

@OptIn(ExperimentalMaterial3Api::class, FlowPreview::class)
@Composable
fun ReaderScreen(
    vm: QuranViewModel,
    surahId: Int,
    startAyah: Int,
    onBack: () -> Unit,
    onOpenSurah: (Int) -> Unit,
) {
    val surahs by vm.surahs.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val bookmarks by vm.bookmarks.collectAsStateWithLifecycle()
    val player by vm.player.state.collectAsStateWithLifecycle()
    val surah = surahs.getOrNull(surahId - 1)
    val bookmarkSet = remember(bookmarks) { bookmarks.map { it.toString() }.toSet() }

    // العنصر 0 هو رأس السورة، الآيات كتبدا من 1
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = if (startAyah > 1) startAyah else 0)

    LaunchedEffect(surahId) {
        snapshotFlow { listState.firstVisibleItemIndex }
            .distinctUntilChanged()
            .debounce(800)
            .collect { i -> vm.saveLastRead(AyahRef(surahId, i.coerceAtLeast(1))) }
    }

    // تابع الآية اللي كتتقرا دابا
    LaunchedEffect(player.current) {
        val cur = player.current ?: return@LaunchedEffect
        if (cur.surah == surahId) listState.animateScrollToItem(cur.ayah)
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(surah?.let { "سورة ${it.name}" } ?: "", fontFamily = QuranFont, fontSize = 24.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") }
                },
                actions = {
                    if (surah != null) IconButton(onClick = { vm.play(surah, 1) }) {
                        Icon(Icons.Filled.PlayArrow, "استمع للسورة")
                    }
                },
            )
        },
    ) { padding ->
        if (surah == null) {
            Box(Modifier.fillMaxSize().padding(padding), Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }
        LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(padding)) {
            item(key = "header") { SurahHeader(surah) }
            itemsIndexed(surah.ayahs, key = { _, a -> a.key }) { _, a ->
                AyahItem(
                    ayah = a,
                    settings = settings,
                    isPlaying = player.current?.let { it.surah == a.surah && it.ayah == a.number } == true,
                    isBookmarked = a.key in bookmarkSet,
                    surahName = surah.name,
                    onPlay = { vm.play(surah, a.number) },
                    onBookmark = { vm.toggleBookmark(AyahRef(a.surah, a.number)) },
                    onTafsir = { vm.openTafsir(a) },
                )
            }
            item(key = "footer") {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    if (surahId > 1) TextButton(onClick = { onOpenSurah(surahId - 1) }) {
                        Text("السورة السابقة")
                    } else Spacer(Modifier)
                    if (surahId < 114) FilledTonalButton(onClick = { onOpenSurah(surahId + 1) }) {
                        Text("السورة التالية: ${surahs[surahId].name}")
                    }
                }
            }
        }
    }
}

@Composable
private fun SurahHeader(s: Surah) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(24.dp))
            .padding(vertical = 20.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("سورة ${s.name}", fontFamily = QuranFont, fontSize = 34.sp, color = MaterialTheme.colorScheme.primary)
        Text(
            "${s.transliteration} • ${s.meaningFr}",
            style = MaterialTheme.typography.bodyMedium,
        )
        Text(
            "${if (s.isMeccan) "مكية" else "مدنية"} • ${s.ayahs.size.toArabicDigits()} آية",
            style = MaterialTheme.typography.bodySmall,
        )
        // الفاتحة: البسملة هي الآية 1، والتوبة بلا بسملة
        if (s.id != 1 && s.id != 9) {
            Spacer(Modifier.height(14.dp))
            Text(BASMALA, fontFamily = QuranFont, fontSize = 26.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun AyahItem(
    ayah: Ayah,
    settings: Settings,
    isPlaying: Boolean,
    isBookmarked: Boolean,
    surahName: String,
    onPlay: () -> Unit,
    onBookmark: () -> Unit,
    onTafsir: () -> Unit,
) {
    val context = LocalContext.current
    val bg by animateColorAsState(
        if (isPlaying) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f) else Color.Transparent,
        label = "ayahBg",
    )
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .background(bg, RoundedCornerShape(16.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NumberBadge(ayah.number)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onPlay) { Icon(Icons.Filled.PlayArrow, "استمع") }
            IconButton(onClick = onTafsir) { Icon(Icons.AutoMirrored.Filled.MenuBook, "التفسير") }
            IconButton(onClick = onBookmark) {
                Icon(
                    if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                    "علامة",
                    tint = if (isBookmarked) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface,
                )
            }
            IconButton(onClick = { copy(context, ayah, surahName) }) { Icon(Icons.Filled.ContentCopy, "نسخ") }
            IconButton(onClick = { share(context, ayah, surahName) }) { Icon(Icons.Filled.Share, "مشاركة") }
        }
        Text(
            "${ayah.text} ﴿${ayah.number.toArabicDigits()}﴾",
            fontFamily = QuranFont,
            fontSize = settings.fontSize.sp,
            lineHeight = (settings.fontSize * 1.9f).sp,
            textAlign = TextAlign.Right,
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        )
        val tr = when (settings.translation) {
            Translation.FR -> ayah.fr
            Translation.EN -> ayah.en
            Translation.NONE -> null
        }
        if (tr != null) {
            Text(
                tr,
                style = MaterialTheme.typography.bodyMedium.copy(textDirection = TextDirection.Ltr),
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f),
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

private fun ayahShareText(a: Ayah, surahName: String) =
    "${a.text} ﴿${a.number.toArabicDigits()}﴾\n[سورة $surahName - الآية ${a.number.toArabicDigits()}]"

private fun copy(context: Context, a: Ayah, surahName: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("آية", ayahShareText(a, surahName)))
    Toast.makeText(context, "تنسخات الآية", Toast.LENGTH_SHORT).show()
}

private fun share(context: Context, a: Ayah, surahName: String) {
    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, ayahShareText(a, surahName))
    context.startActivity(Intent.createChooser(i, "مشاركة الآية"))
}
