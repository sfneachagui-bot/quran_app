package ma.quran.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.widget.Toast
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.ui.graphics.vector.ImageVector
import ma.quran.app.data.Ayah
import ma.quran.app.data.AyahRef
import ma.quran.app.data.TafsirEdition
import ma.quran.app.data.toArabicDigits
import ma.quran.app.ui.QuranViewModel
import ma.quran.app.ui.TafsirState
import ma.quran.app.ui.theme.QuranFont
import ma.quran.app.ui.theme.AnimatedStarPattern
import ma.quran.app.ui.theme.AudioBars
import ma.quran.app.ui.theme.DeepGreen
import ma.quran.app.ui.theme.Gold
import ma.quran.app.ui.theme.rememberPulse
import ma.quran.app.player.PlayerState
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** دائرة فيها رقم */
@Composable
fun NumberBadge(n: Int, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.secondaryContainer),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            n.toArabicDigits(),
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
        )
    }
}

@Composable
fun MiniPlayer(vm: QuranViewModel, onOpen: (AyahRef) -> Unit) {
    val st by vm.player.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    LaunchedEffect(st.error) {
        st.error?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            vm.player.clearError()
        }
    }
    val visible = st.current != null || st.duaId != null
    // كنحتافظو بآخر حالة باش الأنيميشن ديال الخروج يبان مزيان
    val held = remember { mutableStateOf(st) }
    if (visible) held.value = st
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn(),
        exit = slideOutVertically(tween(260)) { it } + fadeOut(tween(260)),
    ) {
        MiniPlayerContent(vm, held.value, onOpen)
    }
}

@Composable
private fun MiniPlayerContent(vm: QuranViewModel, st: PlayerState, onOpen: (AyahRef) -> Unit) {
    val cur = st.current
    val glow = rememberPulse(0.3f, 0.9f, 1400)
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .padding(top = 6.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF145C3A), DeepGreen, Color(0xFF0B3D26))))
            .border(1.dp, Gold.copy(alpha = if (st.isPlaying) glow else 0.3f), RoundedCornerShape(22.dp)),
    ) {
        AnimatedStarPattern(Modifier.matchParentSize(), color = Color.White.copy(alpha = 0.05f), cell = 30.dp)
        androidx.compose.runtime.CompositionLocalProvider(androidx.compose.material3.LocalContentColor provides Color.White) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { if (cur != null) onOpen(cur) }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AudioBars(st.isPlaying, Modifier.padding(horizontal = 6.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (cur != null) "سورة ${st.surahName} • الآية ${cur.ayah.toArabicDigits()}" else "🤲 ${st.title}",
                        fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        if (cur != null) st.reciterName else "حصن المسلم",
                        style = MaterialTheme.typography.bodySmall, maxLines = 1, color = Gold,
                    )
                }
                // الأيقونات ديال السابق/التالي معكوسة حيت الواجهة RTL
                IconButton(onClick = vm.player::toggleRepeatAyah) {
                    Icon(
                        Icons.Filled.RepeatOne, "تكرار الآية",
                        tint = if (st.repeatAyah) Gold else Color.White.copy(alpha = 0.4f),
                    )
                }
                IconButton(onClick = vm.player::previous) { Icon(Icons.Filled.SkipNext, "الآية السابقة") }
                Box(contentAlignment = Alignment.Center) {
                    if (st.isBuffering) CircularProgressIndicator(Modifier.size(44.dp), strokeWidth = 2.dp, color = Gold)
                    IconButton(
                        onClick = vm.player::togglePlay,
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Gold, contentColor = DeepGreen),
                    ) {
                        AnimatedContent(st.isPlaying, label = "playIcon", transitionSpec = {
                            (scaleIn(initialScale = 0.5f) + fadeIn()) togetherWith (scaleOut(targetScale = 0.5f) + fadeOut())
                        }) { playing ->
                            Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "تشغيل/إيقاف")
                        }
                    }
                }
                IconButton(onClick = vm.player::next) { Icon(Icons.Filled.SkipPrevious, "الآية التالية") }
                IconButton(onClick = vm.player::stop) { Icon(Icons.Filled.Close, "إغلاق") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TafsirSheet(vm: QuranViewModel) {
    val t by vm.tafsir.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val (ayah, state) = t ?: return
    ModalBottomSheet(
        onDismissRequest = vm::closeTafsir,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
        ) {
            val surahName = vm.surahs.value.getOrNull(ayah.surah - 1)?.name.orEmpty()
            Text(
                "تفسير سورة $surahName • الآية ${ayah.number.toArabicDigits()}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                TafsirEdition.entries.forEach { e ->
                    FilterChip(
                        selected = settings.tafsir == e,
                        onClick = { vm.changeTafsirEdition(ayah, e) },
                        label = { Text(e.label) },
                    )
                }
            }
            Text(
                ayah.text,
                fontFamily = QuranFont,
                fontSize = 24.sp,
                lineHeight = 46.sp,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            )
            Spacer(Modifier.height(8.dp))
            when (state) {
                TafsirState.Loading -> Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) {
                    CircularProgressIndicator()
                }
                is TafsirState.Loaded -> SelectionContainer {
                    Text(state.text, style = MaterialTheme.typography.bodyLarge, lineHeight = 30.sp)
                }
                is TafsirState.Failed -> Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(state.message, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { vm.openTafsir(ayah) }) { Text("عاود المحاولة") }
                }
            }
        }
    }
}

/** القائمة ديال الآية (ضغطة مطولة) */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AyahMenuSheet(vm: QuranViewModel) {
    val ayah by vm.ayahMenu.collectAsStateWithLifecycle()
    val bookmarks by vm.bookmarks.collectAsStateWithLifecycle()
    val a = ayah ?: return
    val context = LocalContext.current
    val surah = vm.surahs.value.getOrNull(a.surah - 1) ?: return
    val ref = AyahRef(a.surah, a.number)
    val marked = ref in bookmarks
    ModalBottomSheet(onDismissRequest = vm::closeAyahMenu) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Text(
                "سورة ${surah.name} • الآية ${a.number.toArabicDigits()}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp),
            )
            Text(
                a.text,
                fontFamily = QuranFont,
                fontSize = 22.sp,
                lineHeight = 40.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            )
            HorizontalDivider()
            MenuRow(Icons.Filled.PlayArrow, "استمع من هذه الآية") {
                vm.closeAyahMenu(); vm.requestPlay(surah, a.number)
            }
            MenuRow(Icons.AutoMirrored.Filled.MenuBook, "التفسير") {
                vm.closeAyahMenu(); vm.openTafsir(a)
            }
            MenuRow(
                if (marked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                if (marked) "حذف العلامة" else "إضافة علامة",
            ) {
                vm.toggleBookmark(ref); vm.closeAyahMenu()
            }
            MenuRow(Icons.Filled.ContentCopy, "نسخ الآية") {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("آية", shareText(a, surah.name)))
                Toast.makeText(context, "تنسخات الآية", Toast.LENGTH_SHORT).show()
                vm.closeAyahMenu()
            }
            MenuRow(Icons.Filled.Share, "مشاركة") {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, shareText(a, surah.name))
                context.startActivity(Intent.createChooser(i, "مشاركة الآية"))
                vm.closeAyahMenu()
            }
        }
    }
}

private fun shareText(a: Ayah, surahName: String) =
    "${a.text} ﴿${a.number.toArabicDigits()}﴾\n[سورة $surahName - الآية ${a.number.toArabicDigits()}]"

@Composable
private fun MenuRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(label) },
        leadingContent = { Icon(icon, null, tint = MaterialTheme.colorScheme.primary) },
        modifier = Modifier.clickable(onClick = onClick),
    )
}


/** اختيار المقرئ قبل التشغيل */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReciterPickerSheet(vm: QuranViewModel) {
    val pending by vm.pickReciter.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val (surah, from) = pending ?: return
    var query by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    ModalBottomSheet(
        onDismissRequest = vm::cancelPick,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
            Text(
                "اختار المقرئ",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp),
            )
            Text(
                "سورة ${surah.name} • من الآية ${from.toArabicDigits()}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
            androidx.compose.material3.OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("ابحث عن مقرئ…") },
                singleLine = true,
                shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            )
            val current = settings.reciter
            val list = ma.quran.app.data.RECITERS
                .filter { query.isBlank() || it.name.contains(query.trim()) }
                .sortedByDescending { it.id == current.id }
            androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxWidth().height(420.dp)) {
                items(list.size) { i ->
                    val r = list[i]
                    val selected = r.id == current.id
                    ListItem(
                        headlineContent = {
                            Text(
                                if (selected) "${r.name}  ✓" else r.name,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            )
                        },
                        leadingContent = {
                            Icon(
                                Icons.Filled.PlayArrow, null,
                                tint = if (selected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                            )
                        },
                        modifier = Modifier.clickable { vm.playWith(r.id) },
                    )
                }
            }
        }
    }
}
