package ma.quran.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ma.quran.app.data.RECITERS
import ma.quran.app.data.TafsirEdition
import ma.quran.app.data.Translation
import ma.quran.app.ui.QuranViewModel
import ma.quran.app.ui.theme.QuranFont

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: QuranViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
    ) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineSmall)

        Section("حجم خط المصحف")
        Text(
            "ٱلۡحَمۡدُ لِلَّهِ رَبِّ ٱلۡعَٰلَمِينَ",
            fontFamily = QuranFont,
            fontSize = s.fontSize.sp,
            lineHeight = (s.fontSize * 1.9f).sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Slider(value = s.fontSize, onValueChange = { vm.setFontSize(it) }, valueRange = 18f..44f)

        Section("وضع القراءة")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !s.cardMode, onClick = { vm.setCardMode(false) }, label = { Text("مصحف (شاشة كاملة)") })
            FilterChip(selected = s.cardMode, onClick = { vm.setCardMode(true) }, label = { Text("آية بآية مع الترجمة") })
        }
        Text(
            "💡 ضغطة وحدة على الشاشة كتبين/تخبي الأزرار، وضغطة مطولة على أي آية كتحل القائمة ديالها (استماع، تفسير، علامة، نسخ، مشاركة).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            modifier = Modifier.padding(top = 6.dp),
        )

        Section("الترجمة (فوضع آية بآية)")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Translation.entries.forEach { t ->
                FilterChip(selected = s.translation == t, onClick = { vm.setTranslation(t) }, label = { Text(t.label) })
            }
        }

        Section("التفسير")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TafsirEdition.entries.forEach { t ->
                FilterChip(selected = s.tafsir == t, onClick = { vm.setTafsir(t) }, label = { Text(t.label) })
            }
        }

        Section("القارئ")
        RECITERS.forEach { r ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .selectable(selected = s.reciterId == r.id, onClick = { vm.setReciter(r.id) }, role = Role.RadioButton)
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = s.reciterId == r.id, onClick = null)
                Text(r.name, modifier = Modifier.padding(start = 12.dp))
            }
        }

        HorizontalDivider(Modifier.padding(vertical = 20.dp))
        Text(
            "مصادر: نص المصحف (الرسم العثماني) من موسوعة القرآن الكريم quranenc.com • الترجمات من tanzil.net • " +
                "التفسير من api.alquran.cloud • التلاوات من everyayah.com • الأحاديث من hadith-api (fawazahmed0) • الأجزاء والأحزاب من quran-meta • الأدعية والأذكار من حصن المسلم (hisnmuslim.com) • خط Amiri Quran (OFL).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
        )
    }
}

@Composable
private fun Section(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 24.dp, bottom = 8.dp),
    )
}
