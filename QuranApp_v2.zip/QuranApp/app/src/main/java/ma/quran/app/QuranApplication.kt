package ma.quran.app

import android.app.Application
import ma.quran.app.data.PrefsRepository
import ma.quran.app.data.QuranRepository
import ma.quran.app.data.TafsirRepository
import ma.quran.app.player.PlayerController

class QuranApplication : Application() {
    val quran by lazy { QuranRepository(this) }
    val tafsir by lazy { TafsirRepository(this) }
    val prefs by lazy { PrefsRepository(this) }
    val player by lazy { PlayerController(this) }
}
