package ma.quran.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import ma.quran.app.ui.QuranNavHost
import ma.quran.app.ui.screens.SplashScreen
import androidx.compose.runtime.saveable.rememberSaveable
import ma.quran.app.ui.theme.QuranTheme

class MainActivity : ComponentActivity() {
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            QuranTheme {
                // إلا طاح التطبيق المرة اللي فاتت، كنبينو السبب
                var crash by remember { mutableStateOf(CrashReporter.read(this)) }
                val c = crash
                if (c != null) {
                    CrashScreen(c) {
                        CrashReporter.clear(this)
                        crash = null
                    }
                } else {
                    // الواجهة كلها من اليمين لليسار
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        // شاشة البداية المتحركة مرة وحدة فكل فتحة
                        var splash by rememberSaveable { mutableStateOf(true) }
                        androidx.compose.foundation.layout.Box(androidx.compose.ui.Modifier.fillMaxSize()) {
                            QuranNavHost()
                            if (splash) SplashScreen { splash = false }
                        }
                    }
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun CrashScreen(text: String, onContinue: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.material3.Surface(androidx.compose.ui.Modifier.fillMaxSize()) {
        androidx.compose.foundation.layout.Column(
            androidx.compose.ui.Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(16.dp),
        ) {
            androidx.compose.material3.Text(
                "التطبيق طاح المرة اللي فاتت. صيفط هاد التقرير للمطور:",
                style = androidx.compose.material3.MaterialTheme.typography.titleMedium,
            )
            androidx.compose.foundation.layout.Row(androidx.compose.ui.Modifier.padding(vertical = 8.dp)) {
                androidx.compose.material3.Button(onClick = {
                    val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("crash", text))
                    android.widget.Toast.makeText(context, "تنسخ التقرير", android.widget.Toast.LENGTH_SHORT).show()
                }) { androidx.compose.material3.Text("نسخ التقرير") }
                androidx.compose.foundation.layout.Spacer(androidx.compose.ui.Modifier.padding(4.dp))
                androidx.compose.material3.OutlinedButton(onClick = onContinue) { androidx.compose.material3.Text("كمل للتطبيق") }
            }
            androidx.compose.material3.Text(
                text,
                fontSize = 11.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                modifier = androidx.compose.ui.Modifier
                    .fillMaxSize()
                    .verticalScroll(androidx.compose.foundation.rememberScrollState()),
            )
        }
    }
}
