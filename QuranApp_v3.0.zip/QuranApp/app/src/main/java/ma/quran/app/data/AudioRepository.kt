package ma.quran.app.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** حالة التحميل ديال سورة */
data class DownloadState(val progress: Float = 0f, val running: Boolean = false, val error: String? = null)

/**
 * الصوت:
 * - مقرئين ورش من mp3quran.net (API v3) — السورة كاملة فملف واحد، اللائحة كتتخبا فالتلفون.
 * - التحميل للاستماع بلا أنترنيت: حفص آية بآية (everyayah) ولا ورش سورة كاملة.
 *   الملفات كتتحط فـ filesDir/audio/… والمشغل كيستعمل الملف المحلي إلا كان موجود.
 */
class AudioRepository(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = java.util.concurrent.ConcurrentHashMap<String, Job>()

    private val _downloads = MutableStateFlow<Map<String, DownloadState>>(emptyMap())
    val downloads: StateFlow<Map<String, DownloadState>> = _downloads.asStateFlow()

    /** كيتبدل ملي كيتزاد ولا يتحيد شي ملف، باش الواجهة تعاود تحسب */
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version.asStateFlow()

    private val root get() = File(context.filesDir, "audio")

    // ───────────── حفص (آية بآية) ─────────────

    fun ayahFile(reciter: Reciter, surah: Int, ayah: Int) =
        File(root, "${reciter.folder}/" + String.format(Locale.ROOT, "%03d%03d.mp3", surah, ayah))

    fun isSurahDownloaded(reciter: Reciter, surah: Int, ayahCount: Int): Boolean =
        (1..ayahCount).all { ayahFile(reciter, surah, it).exists() }

    fun hafsKey(reciter: Reciter, surah: Int) = "h:${reciter.id}:$surah"

    fun downloadHafs(reciter: Reciter, surah: Int, ayahCount: Int) {
        val key = hafsKey(reciter, surah)
        start(key) {
            for (a in 1..ayahCount) {
                if (!isActive) break
                val f = ayahFile(reciter, surah, a)
                if (!f.exists()) fetch(reciter.url(surah, a), f)
                set(key, DownloadState(a / ayahCount.toFloat(), running = a < ayahCount))
            }
        }
    }

    fun deleteHafs(reciter: Reciter, surah: Int, ayahCount: Int) {
        cancel(hafsKey(reciter, surah))
        (1..ayahCount).forEach { ayahFile(reciter, surah, it).delete() }
        _version.update { it + 1 }
    }

    // ───────────── ورش (السورة كاملة) ─────────────

    fun surahFile(r: SurahReciter, surah: Int) =
        File(root, "full/${r.id}/" + String.format(Locale.ROOT, "%03d.mp3", surah))

    fun warshKey(r: SurahReciter, surah: Int) = "w:${r.id}:$surah"

    fun downloadSurah(r: SurahReciter, surah: Int) {
        val key = warshKey(r, surah)
        start(key) {
            fetch(r.url(surah), surahFile(r, surah)) { p -> set(key, DownloadState(p, running = true)) }
        }
    }

    fun deleteSurah(r: SurahReciter, surah: Int) {
        cancel(warshKey(r, surah))
        surahFile(r, surah).delete()
        _version.update { it + 1 }
    }

    /** المساحة المستعملة بالميغا */
    fun usedMb(): Float = root.walkTopDown().filter { it.isFile }.sumOf { it.length() } / 1_048_576f

    fun deleteAll() {
        jobs.values.forEach { it.cancel() }
        jobs.clear()
        root.deleteRecursively()
        _downloads.value = emptyMap()
        _version.update { it + 1 }
    }

    fun cancel(key: String) {
        jobs.remove(key)?.cancel()
        _downloads.update { it - key }
    }

    private fun start(key: String, block: suspend CoroutineScope.() -> Unit) {
        if (jobs[key]?.isActive == true) return
        set(key, DownloadState(0f, running = true))
        jobs[key] = scope.launch {
            try {
                block()
                set(key, DownloadState(1f, running = false))
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                set(key, DownloadState(0f, running = false, error = "ما تكملش التحميل، تأكد من الأنترنيت"))
            } finally {
                jobs.remove(key)
                _version.update { it + 1 }
            }
        }
    }

    private fun set(key: String, s: DownloadState) = _downloads.update { it + (key to s) }

    /** كيحمل لملف مؤقت ومن بعد كيسميه، باش ما يبقاش ملف ناقص */
    private fun fetch(url: String, dest: File, onProgress: ((Float) -> Unit)? = null) {
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".part")
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        conn.instanceFollowRedirects = true
        try {
            if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            conn.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(32 * 1024)
                    var done = 0L
                    var lastReport = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (onProgress != null && total > 0 && done - lastReport > 256 * 1024) {
                            lastReport = done
                            onProgress(done / total.toFloat())
                        }
                    }
                }
            }
            if (!tmp.renameTo(dest)) error("rename failed")
        } finally {
            conn.disconnect()
            tmp.delete()
        }
    }

    // ───────────── لائحة مقرئين ورش ─────────────

    private var warshCache: List<SurahReciter>? = null

    suspend fun warshReciters(forceRefresh: Boolean = false): Result<List<SurahReciter>> = runCatching {
        warshCache?.takeIf { !forceRefresh }?.let { return@runCatching it }
        val file = File(context.filesDir, "mp3quran_reciters.json")
        val raw = withContext(Dispatchers.IO) {
            if (file.exists() && !forceRefresh) file.readText()
            else download("https://mp3quran.net/api/v3/reciters?language=ar").also { file.writeText(it) }
        }
        val list = ArrayList<SurahReciter>()
        for (r in json.parseToJsonElement(raw).jsonObject["reciters"]!!.jsonArray) {
            val ro = r.jsonObject
            val name = ro["name"]?.jsonPrimitive?.content ?: continue
            val rid = ro["id"]?.jsonPrimitive?.content ?: name
            for (m in ro["moshaf"]?.jsonArray ?: continue) {
                val mo = m.jsonObject
                val mName = mo["name"]?.jsonPrimitive?.content.orEmpty()
                if (!mName.contains("ورش")) continue
                val server = mo["server"]?.jsonPrimitive?.content ?: continue
                val surahs = mo["surah_list"]?.jsonPrimitive?.content.orEmpty()
                    .split(',').mapNotNull { it.trim().toIntOrNull() }.toSet()
                val mid = mo["id"]?.jsonPrimitive?.content ?: mName
                val label = mName.substringAfter("-", "").trim().let { if (it.isBlank()) name else "$name ($it)" }
                list += SurahReciter("$rid-$mid", label, server, surahs)
            }
        }
        if (list.isEmpty()) error("ما لقيناش مقرئين بورش")
        list.sortedBy { it.name }.also { warshCache = it }
    }

    private fun download(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 20_000
        try {
            if (conn.responseCode != 200) error("مشكل فالسيرفر (${conn.responseCode})")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
