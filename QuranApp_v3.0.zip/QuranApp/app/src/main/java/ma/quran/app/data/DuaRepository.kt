package ma.quran.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class DuaChapter(val id: Int, val title: String, val audioUrl: String, val textUrl: String)

data class Dua(
    val id: Int,
    val chapter: Int,
    val text: String,
    val repeat: Int,
    val audioUrl: String,
)

/**
 * الأدعية والأذكار من "حصن المسلم" (hisnmuslim.com): النص + الصوت ديال كل ذكر.
 * كيتجابو من الأنترنيت أول مرة وكيتخباو فالتلفون.
 */
class DuaRepository(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private var chapters: List<DuaChapter>? = null
    private val cache = HashMap<Int, List<Dua>>()

    private fun dir() = File(context.filesDir, "duas").apply { mkdirs() }

    private fun JsonElement.str(key: String) = (this as? JsonObject)?.get(key)?.jsonPrimitive?.content.orEmpty()

    /** حصن المسلم كيعطي روابط http، كنجربو https أولا */
    private fun https(url: String) = url.trim().replaceFirst("http://", "https://")

    suspend fun chapters(): Result<List<DuaChapter>> = runCatching {
        chapters?.let { return@runCatching it }
        val raw = cachedOrDownload(File(dir(), "chapters.json"), "https://www.hisnmuslim.com/api/ar/husn_ar.json")
        val root = json.parseToJsonElement(raw).jsonObject
        val arr = root.values.first().jsonArray
        arr.map {
            DuaChapter(
                id = it.str("ID").toIntOrNull() ?: 0,
                title = it.str("TITLE").trim(),
                audioUrl = https(it.str("AUDIO_URL")),
                textUrl = https(it.str("TEXT")),
            )
        }.filter { it.id > 0 }
            .distinctBy { it.id }
            .sortedBy { it.id }
            .also { chapters = it }
    }

    suspend fun chapter(c: DuaChapter): Result<List<Dua>> = runCatching {
        cache[c.id]?.let { return@runCatching it }
        val raw = cachedOrDownload(File(dir(), "c${c.id}.json"), c.textUrl)
        val root = json.parseToJsonElement(raw).jsonObject
        val list = root.values.first().jsonArray.mapNotNull {
            val text = it.str("ARABIC_TEXT").trim()
            if (text.isEmpty()) return@mapNotNull null
            val id = it.str("ID").toIntOrNull() ?: 0
            Dua(
                id = id,
                chapter = c.id,
                text = text,
                repeat = it.str("REPEAT").toIntOrNull()?.coerceAtLeast(1) ?: 1,
                audioUrl = https(it.str("AUDIO").ifBlank { "https://www.hisnmuslim.com/audio/ar/$id.mp3" }),
            )
        }
        cache[c.id] = list
        list
    }

    fun isCached(id: Int) = File(dir(), "c$id.json").exists()

    /** تحميل كلشي للاستعمال بلا أنترنيت (النصوص فقط) */
    suspend fun downloadAll(onProgress: (Int, Int) -> Unit): Result<Unit> = runCatching {
        val all = chapters().getOrThrow()
        all.forEachIndexed { i, c ->
            runCatching { chapter(c).getOrThrow() }
            onProgress(i + 1, all.size)
        }
    }

    private suspend fun cachedOrDownload(file: File, url: String): String = withContext(Dispatchers.IO) {
        if (file.exists() && file.length() > 0) return@withContext file.readText()
        val text = runCatching { download(url) }.getOrElse { download(url.replaceFirst("https://", "http://")) }
        file.writeText(text)
        text
    }

    private fun download(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 20_000
        conn.instanceFollowRedirects = true
        try {
            if (conn.responseCode != 200) error("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }.removePrefix("﻿")
        } finally {
            conn.disconnect()
        }
    }
}
