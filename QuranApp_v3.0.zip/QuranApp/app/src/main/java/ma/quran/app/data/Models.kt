package ma.quran.app.data

import kotlinx.serialization.Serializable
import java.util.Locale

@Serializable
data class SurahDto(
    val id: Int,
    val name: String,
    val tr: String,
    val meaning: String,
    val meaningEn: String,
    val type: String,
    val verses: List<VerseDto>,
)

@Serializable
data class VerseDto(val ar: String, val fr: String, val en: String)

data class Surah(
    val id: Int,
    val name: String,
    val transliteration: String,
    val meaningFr: String,
    val meaningEn: String,
    val isMeccan: Boolean,
    val ayahs: List<Ayah>,
)

data class Ayah(
    val surah: Int,
    val number: Int,
    val text: String,
    val fr: String,
    val en: String,
    /** نص بلا تشكيل، للبحث */
    val plain: String,
) {
    val key: String get() = "$surah:$number"
}

data class AyahRef(val surah: Int, val ayah: Int) : Comparable<AyahRef> {
    override fun toString() = "$surah:$ayah"
    override fun compareTo(other: AyahRef) = compareValuesBy(this, other, { it.surah }, { it.ayah })

    companion object {
        fun parse(s: String?): AyahRef? {
            val p = s?.split(":") ?: return null
            if (p.size != 2) return null
            val a = p[0].toIntOrNull() ?: return null
            val b = p[1].toIntOrNull() ?: return null
            return AyahRef(a, b)
        }
    }
}

enum class Translation(val label: String) { NONE("بلا ترجمة"), FR("Français"), EN("English") }

enum class TafsirEdition(val apiId: String, val label: String, val isFrench: Boolean = false) {
    MUYASSAR("ar.muyassar", "التفسير الميسر"),
    JALALAYN("ar.jalalayn", "تفسير الجلالين"),
    /** المختصر فالتفسير بالفرنسية (Al-Mukhtasar) */
    FR_MOKHTASAR("fr.mokhtasar", "Tafsir (Français)", isFrench = true),
}

/** الرواية ديال المصحف */
enum class Riwaya(val label: String) { HAFS("حفص عن عاصم"), WARSH("ورش عن نافع") }

/** آية فصفحة من المصحف */
data class PageAyah(val surah: Int, val ayah: Int, val text: String)

/** صفحة من المصحف (1..604) */
data class MushafPage(val number: Int, val ayahs: List<PageAyah>)

/** مقرئ برواية ورش (من mp3quran.net): السورة كاملة فملف واحد */
data class SurahReciter(val id: String, val name: String, val server: String, val surahs: Set<Int>) {
    fun url(surah: Int) = server.trimEnd('/') + "/" + String.format(Locale.ROOT, "%03d.mp3", surah)
}

data class Reciter(val id: String, val name: String, val folder: String) {
    /** صوت آية واحدة من everyayah.com */
    fun url(surah: Int, ayah: Int) =
        String.format(Locale.ROOT, "https://everyayah.com/data/%s/%03d%03d.mp3", folder, surah, ayah)
}

val RECITERS = listOf(
    Reciter("alafasy", "مشاري راشد العفاسي", "Alafasy_128kbps"),
    Reciter("abdulbasit", "عبد الباسط عبد الصمد (مرتل)", "Abdul_Basit_Murattal_192kbps"),
    Reciter("abdulbasit_mj", "عبد الباسط عبد الصمد (مجود)", "Abdul_Basit_Mujawwad_128kbps"),
    Reciter("husary", "محمود خليل الحصري", "Husary_128kbps"),
    Reciter("husary_mj", "محمود خليل الحصري (مجود)", "Husary_128kbps_Mujawwad"),
    Reciter("husary_mu", "محمود خليل الحصري (المصحف المعلم)", "Husary_Muallim_128kbps"),
    Reciter("minshawy", "محمد صديق المنشاوي (مرتل)", "Minshawy_Murattal_128kbps"),
    Reciter("minshawy_mj", "محمد صديق المنشاوي (مجود)", "Minshawy_Mujawwad_192kbps"),
    Reciter("minshawy_t", "محمد صديق المنشاوي (المصحف المعلم)", "Minshawy_Teacher_128kbps"),
    Reciter("maher", "ماهر المعيقلي", "MaherAlMuaiqly128kbps"),
    Reciter("sudais", "عبد الرحمن السديس", "Abdurrahmaan_As-Sudais_192kbps"),
    Reciter("shuraym", "سعود الشريم", "Saood_ash-Shuraym_128kbps"),
    Reciter("ghamadi", "سعد الغامدي", "Ghamadi_40kbps"),
    Reciter("shatri", "أبو بكر الشاطري", "Abu_Bakr_Ash-Shaatree_128kbps"),
    Reciter("ajamy", "أحمد بن علي العجمي", "Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaballah.net"),
    Reciter("dussary", "ياسر الدوسري", "Yasser_Ad-Dussary_128kbps"),
    Reciter("qatami", "ناصر القطامي", "Nasser_Alqatami_128kbps"),
    Reciter("hudhaify", "علي بن عبد الرحمن الحذيفي", "Hudhaify_128kbps"),
    Reciter("budair", "صلاح البدير", "Salah_Al_Budair_128kbps"),
    Reciter("juhany", "عبد الله عواد الجهني", "Abdullaah_3awwaad_Al-Juhaynee_128kbps"),
    Reciter("basfar", "عبد الله بصفر", "Abdullah_Basfar_192kbps"),
    Reciter("qahtani", "خالد القحطاني", "Khaalid_Abdullaah_al-Qahtaanee_192kbps"),
    Reciter("rifai", "هاني الرفاعي", "Hani_Rifai_192kbps"),
    Reciter("ayyoub", "محمد أيوب", "Muhammad_Ayyoub_128kbps"),
    Reciter("jibreel", "محمد جبريل", "Muhammad_Jibreel_128kbps"),
    Reciter("tablawi", "محمد محمود الطبلاوي", "Mohammad_al_Tablaway_128kbps"),
    Reciter("bukhatir", "صلاح بوخاطر", "Salaah_AbdulRahman_Bukhatir_128kbps"),
    Reciter("muhsin", "محسن القاسم", "Muhsin_Al_Qasim_192kbps"),
    Reciter("fares", "فارس عباد", "Fares_Abbad_64kbps"),
    Reciter("alijaber", "علي جابر", "Ali_Jaber_64kbps"),
    Reciter("mustafa", "مصطفى إسماعيل", "Mustafa_Ismail_48kbps"),
    Reciter("banna", "محمود علي البنا", "mahmoud_ali_al_banna_32kbps"),
    Reciter("neana", "أحمد نعينع", "Ahmed_Neana_128kbps"),
    Reciter("akhdar", "إبراهيم الأخضر", "Ibrahim_Akhdar_64kbps"),
    Reciter("alili", "عزيز عليلي", "aziz_alili_128kbps"),
)

fun Int.toArabicDigits(): String =
    toString().map { if (it.isDigit()) '٠' + (it - '0') else it }.joinToString("")

@Serializable
data class PartsDto(val juz: List<List<Int>>, val rub: List<List<Int>>)

/** بدايات الأجزاء (30) وأرباع الأحزاب (240) */
class Parts(val juz: List<AyahRef>, val rub: List<AyahRef>) {
    private fun indexOf(list: List<AyahRef>, ref: AyahRef): Int {
        var i = list.binarySearch(ref)
        if (i < 0) i = -i - 2
        return i.coerceIn(0, list.lastIndex)
    }

    /** رقم الجزء 1..30 */
    fun juzOf(ref: AyahRef) = indexOf(juz, ref) + 1

    /** رقم الربع 1..240 */
    fun rubOf(ref: AyahRef) = indexOf(rub, ref) + 1

    fun hizbOf(ref: AyahRef) = (rubOf(ref) - 1) / 4 + 1

    /** "الحزب ١٢" أو "¼ الحزب ١٢" ... */
    fun hizbLabel(ref: AyahRef): String {
        val r = rubOf(ref) - 1
        val h = (r / 4 + 1).toArabicDigits()
        return when (r % 4) {
            0 -> "الحزب $h"
            1 -> "ربع الحزب $h"
            2 -> "نصف الحزب $h"
            else -> "ثلاثة أرباع الحزب $h"
        }
    }

    fun isQuarterStart(ref: AyahRef) = rub.binarySearch(ref) >= 0
}

val QUARTER_NAMES = listOf("بداية الحزب", "الربع", "النصف", "ثلاثة أرباع")
