package ma.quran.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * المصحف بالصفحات (604 صفحة):
 * - حفص: النص من quran.json وبدايات الصفحات من assets/pages_hafs.json (quran-meta، MIT)
 * - ورش: النص والصفحات من assets/warsh.json (مجمع الملك فهد، KFGQPC) وكيتعرض بخط ورش
 */
class MushafRepository(private val context: Context, private val quran: QuranRepository) {
    private val json = Json { ignoreUnknownKeys = true }
    private val mutex = Mutex()
    private var hafs: List<MushafPage>? = null
    private var warsh: List<MushafPage>? = null
    private var warshNames: List<String> = emptyList()
    private var warshCounts: List<Int> = emptyList()

    suspend fun pages(r: Riwaya): List<MushafPage> = if (r == Riwaya.HAFS) hafsPages() else warshPages()

    /** سمية السورة بالعربية (ورش كيستعمل نفس الأسماء) */
    suspend fun surahName(r: Riwaya, surah: Int): String =
        if (r == Riwaya.WARSH) warshPages().let { warshNames.getOrNull(surah - 1).orEmpty() }
        else quran.surah(surah)?.name.orEmpty()

    /** عدد الآيات فالسورة حسب الرواية */
    suspend fun ayahCount(r: Riwaya, surah: Int): Int =
        if (r == Riwaya.WARSH) warshPages().let { warshCounts.getOrElse(surah - 1) { 0 } }
        else quran.surah(surah)?.ayahs?.size ?: 0

    /** الصفحة اللي فيها بداية السورة */
    suspend fun pageOfSurah(r: Riwaya, surah: Int): Int =
        pages(r).firstOrNull { p -> p.ayahs.any { it.surah == surah } }?.number ?: 1

    suspend fun pageOf(r: Riwaya, surah: Int, ayah: Int): Int =
        pages(r).firstOrNull { p -> p.ayahs.any { it.surah == surah && it.ayah == ayah } }?.number
            ?: pageOfSurah(r, surah)

    private suspend fun hafsPages(): List<MushafPage> = mutex.withLock {
        hafs ?: withContext(Dispatchers.Default) {
            val raw = context.assets.open("pages_hafs.json").bufferedReader().use { it.readText() }
            val starts = json.parseToJsonElement(raw).jsonArray.map {
                val a = it.jsonArray
                AyahRef(a[0].jsonPrimitive.int, a[1].jsonPrimitive.int)
            }
            val buckets = List(starts.size) { ArrayList<PageAyah>() }
            var page = 0
            for (s in quran.surahs()) for (a in s.ayahs) {
                val ref = AyahRef(s.id, a.number)
                while (page + 1 < starts.size && ref >= starts[page + 1]) page++
                buckets[page] += PageAyah(s.id, a.number, a.text)
            }
            buckets.mapIndexed { i, l -> MushafPage(i + 1, l) }.also { hafs = it }
        }
    }

    private suspend fun warshPages(): List<MushafPage> = mutex.withLock {
        warsh ?: withContext(Dispatchers.IO) {
            val raw = context.assets.open("warsh.json").bufferedReader().use { it.readText() }
            val surahs = json.parseToJsonElement(raw).jsonArray
            val byPage = sortedMapOf<Int, ArrayList<PageAyah>>()
            val names = ArrayList<String>()
            val counts = ArrayList<Int>()
            surahs.forEachIndexed { si, el ->
                val o = el.jsonObject
                names += o["n"]!!.jsonPrimitive.content
                val ayahs = o["a"]!!.jsonArray
                counts += ayahs.size
                ayahs.forEachIndexed { ai, a ->
                    val arr = a.jsonArray
                    val text = arr[0].jsonPrimitive.content
                    val pg = arr[1].jsonPrimitive.int
                    byPage.getOrPut(pg) { ArrayList() } += PageAyah(si + 1, ai + 1, text)
                }
            }
            warshNames = names
            warshCounts = counts
            byPage.map { (n, l) -> MushafPage(n, l) }.also { warsh = it }
        }
    }
}
