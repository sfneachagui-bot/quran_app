package ma.quran.app.data

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

/**
 * حساب مواقيت الصلاة بلا أنترنيت (الطريقة الفلكية المعروفة ديال PrayTimes).
 * ⚠️ التوقيت الرسمي (مثلا ديال وزارة الأوقاف) يقدر يختالف بشي دقائق.
 */
enum class CalcMethod(val label: String, val fajr: Double, val isha: Double, val ishaMinutes: Int = 0) {
    MOROCCO("المغرب (وزارة الأوقاف ١٩°/١٧°)", 19.0, 17.0),
    MWL("رابطة العالم الإسلامي (١٨°/١٧°)", 18.0, 17.0),
    UMM_AL_QURA("أم القرى (مكة)", 18.5, 0.0, ishaMinutes = 90),
    EGYPT("الهيئة المصرية (١٩٫٥°/١٧٫٥°)", 19.5, 17.5),
    FRANCE("فرنسا UOIF (١٢°/١٢°)", 12.0, 12.0),
    ISNA("أمريكا الشمالية ISNA (١٥°/١٥°)", 15.0, 15.0),
}

enum class Prayer(val label: String, val emoji: String) {
    FAJR("الفجر", "🌙"), SUNRISE("الشروق", "🌅"), DHUHR("الظهر", "☀️"),
    ASR("العصر", "🌤️"), MAGHRIB("المغرب", "🌇"), ISHA("العشاء", "🌌"),
}

data class PrayerDay(val date: LocalDate, val times: Map<Prayer, LocalTime>)

data class City(val name: String, val lat: Double, val lon: Double, val zone: String)

val CITIES = listOf(
    City("الدار البيضاء", 33.5731, -7.5898, "Africa/Casablanca"),
    City("الرباط", 34.0209, -6.8416, "Africa/Casablanca"),
    City("فاس", 34.0181, -5.0078, "Africa/Casablanca"),
    City("مراكش", 31.6295, -7.9811, "Africa/Casablanca"),
    City("طنجة", 35.7595, -5.8340, "Africa/Casablanca"),
    City("أكادير", 30.4278, -9.5981, "Africa/Casablanca"),
    City("مكناس", 33.8935, -5.5473, "Africa/Casablanca"),
    City("وجدة", 34.6814, -1.9086, "Africa/Casablanca"),
    City("القنيطرة", 34.2610, -6.5802, "Africa/Casablanca"),
    City("تطوان", 35.5785, -5.3684, "Africa/Casablanca"),
    City("الناظور", 35.1681, -2.9335, "Africa/Casablanca"),
    City("الحسيمة", 35.2517, -3.9372, "Africa/Casablanca"),
    City("الجديدة", 33.2316, -8.5007, "Africa/Casablanca"),
    City("آسفي", 32.2994, -9.2372, "Africa/Casablanca"),
    City("الصويرة", 31.5085, -9.7595, "Africa/Casablanca"),
    City("بني ملال", 32.3373, -6.3498, "Africa/Casablanca"),
    City("الرشيدية", 31.9314, -4.4248, "Africa/Casablanca"),
    City("ورزازات", 30.9189, -6.8934, "Africa/Casablanca"),
    City("العيون", 27.1253, -13.1625, "Africa/Casablanca"),
    City("الداخلة", 23.6848, -15.9580, "Africa/Casablanca"),
    City("باريس", 48.8566, 2.3522, "Europe/Paris"),
    City("ليون", 45.7640, 4.8357, "Europe/Paris"),
    City("مارسيليا", 43.2965, 5.3698, "Europe/Paris"),
    City("بروكسيل", 50.8503, 4.3517, "Europe/Brussels"),
    City("أمستردام", 52.3676, 4.9041, "Europe/Amsterdam"),
    City("مدريد", 40.4168, -3.7038, "Europe/Madrid"),
    City("برشلونة", 41.3874, 2.1686, "Europe/Madrid"),
    City("ميلانو", 45.4642, 9.1900, "Europe/Rome"),
    City("مونتريال", 45.5017, -73.5673, "America/Toronto"),
    City("مكة المكرمة", 21.4225, 39.8262, "Asia/Riyadh"),
)

object PrayerCalc {
    private const val KAABA_LAT = 21.4225
    private const val KAABA_LON = 39.8262

    private fun dsin(d: Double) = sin(Math.toRadians(d))
    private fun dcos(d: Double) = cos(Math.toRadians(d))
    private fun dtan(d: Double) = tan(Math.toRadians(d))
    private fun darcsin(x: Double) = Math.toDegrees(asin(x))
    private fun darccos(x: Double) = Math.toDegrees(acos(x))
    private fun darctan2(y: Double, x: Double) = Math.toDegrees(atan2(y, x))
    private fun darccot(x: Double) = Math.toDegrees(atan(1 / x))
    private fun fix(a: Double, b: Double): Double { val r = a - b * floor(a / b); return if (r < 0) r + b else r }
    private fun fixAngle(a: Double) = fix(a, 360.0)
    private fun fixHour(a: Double) = fix(a, 24.0)

    private fun julian(y: Int, m: Int, d: Int): Double {
        var yy = y; var mm = m
        if (mm <= 2) { yy -= 1; mm += 12 }
        val a = floor(yy / 100.0)
        val b = 2 - a + floor(a / 4)
        return floor(365.25 * (yy + 4716)) + floor(30.6001 * (mm + 1)) + d + b - 1524.5
    }

    /** [الميل، معادلة الوقت] */
    private fun sun(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g))
        val e = 23.439 - 0.00000036 * d
        val ra = darctan2(dcos(e) * dsin(l), dcos(l)) / 15
        val eqt = q / 15 - fixHour(ra)
        val decl = darcsin(dsin(e) * dsin(l))
        return decl to eqt
    }

    fun compute(
        date: LocalDate,
        lat: Double,
        lon: Double,
        zone: ZoneId,
        method: CalcMethod,
        hanafiAsr: Boolean = false,
    ): PrayerDay {
        val jDate = julian(date.year, date.monthValue, date.dayOfMonth) - lon / (15 * 24.0)

        fun midDay(t: Double) = fixHour(12 - sun(jDate + t).second)
        fun angleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sun(jDate + t).first
            val noon = midDay(t)
            val v = darccos((-dsin(angle) - dsin(decl) * dsin(lat)) / (dcos(decl) * dcos(lat))) / 15
            return noon + if (ccw) -v else v
        }
        fun asrTime(factor: Int, t: Double): Double {
            val decl = sun(jDate + t).first
            val angle = -darccot(factor + dtan(abs(lat - decl)))
            return angleTime(angle, t, false)
        }

        // تقريب أولي (بالساعات) ومن بعد حساب مزيان
        var fajr = 5.0; var sunrise = 6.0; var dhuhr = 12.0; var asr = 13.0; var sunset = 18.0; var isha = 18.0
        repeat(2) {
            fajr = angleTime(method.fajr, fajr / 24, true)
            sunrise = angleTime(0.833, sunrise / 24, true)
            dhuhr = midDay(dhuhr / 24)
            asr = asrTime(if (hanafiAsr) 2 else 1, asr / 24)
            sunset = angleTime(0.833, sunset / 24, false)
            isha = if (method.ishaMinutes > 0) sunset else angleTime(method.isha, isha / 24, false)
        }
        if (method.ishaMinutes > 0) isha = sunset + method.ishaMinutes / 60.0

        // خطوط العرض العالية: إلا ما تحسبش الفجر ولا العشاء، كنستعملو جزء من الليل
        val night = fixHour(sunrise - sunset + 24)
        val fajrPortion = method.fajr / 60.0 * night
        if (fajr.isNaN() || fixHour(sunrise - fajr) > fajrPortion) fajr = sunrise - fajrPortion
        if (method.ishaMinutes == 0) {
            val ishaPortion = method.isha / 60.0 * night
            if (isha.isNaN() || fixHour(isha - sunset) > ishaPortion) isha = sunset + ishaPortion
        }

        val offset = zone.rules.getOffset(date.atTime(12, 0)).totalSeconds / 3600.0
        fun toTime(h: Double): LocalTime {
            val v = fixHour(h + offset - lon / 15)
            var mins = Math.round(v * 60).toInt()
            mins = ((mins % 1440) + 1440) % 1440
            return LocalTime.of(mins / 60, mins % 60)
        }
        return PrayerDay(
            date,
            linkedMapOf(
                Prayer.FAJR to toTime(fajr),
                Prayer.SUNRISE to toTime(sunrise),
                Prayer.DHUHR to toTime(dhuhr),
                Prayer.ASR to toTime(asr),
                Prayer.MAGHRIB to toTime(sunset),
                Prayer.ISHA to toTime(isha),
            ),
        )
    }

    /** اتجاه القبلة بالدرجات من الشمال (مع عقارب الساعة) */
    fun qibla(lat: Double, lon: Double): Double {
        val dl = Math.toRadians(KAABA_LON - lon)
        val p1 = Math.toRadians(lat)
        val p2 = Math.toRadians(KAABA_LAT)
        val b = Math.toDegrees(atan2(sin(dl), cos(p1) * tan(p2) - sin(p1) * cos(dl)))
        return (b + 360) % 360
    }

    /** المسافة للكعبة بالكيلومتر */
    fun distanceToKaaba(lat: Double, lon: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(KAABA_LAT - lat)
        val dLon = Math.toRadians(KAABA_LON - lon)
        val a = sin(dLat / 2) * sin(dLat / 2) + cos(Math.toRadians(lat)) * cos(Math.toRadians(KAABA_LAT)) * sin(dLon / 2) * sin(dLon / 2)
        return 2 * r * atan2(Math.sqrt(a), Math.sqrt(1 - a))
    }
}

private val HIJRI_MONTHS = listOf(
    "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
    "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة",
)

/** التاريخ الهجري (أم القرى، حسب java.time) — يقدر يختالف بنهار على رؤية الهلال */
fun hijriLabel(date: LocalDate): String = runCatching {
    val h = java.time.chrono.HijrahDate.from(date)
    val d = h.get(java.time.temporal.ChronoField.DAY_OF_MONTH)
    val m = h.get(java.time.temporal.ChronoField.MONTH_OF_YEAR)
    val y = h.get(java.time.temporal.ChronoField.YEAR)
    "${d.toArabicDigits()} ${HIJRI_MONTHS[m - 1]} ${y.toArabicDigits()} هـ"
}.getOrDefault("")
