package ma.quran.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * كيجيب التفسير من api.alquran.cloud (بالعربية) ولا من spa5k/tafsir_api (المختصر بالفرنسية)، سورة كاملة فمرة وحدة
 * وكيخبيه فالتلفون باش يخدم من بعد بلا أنترنيت.
 */
class TafsirRepository(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true }
    private val memory = HashMap<String, Map<Int, String>>()

    suspend fun tafsir(edition: TafsirEdition, surah: Int, ayah: Int): Result<String> = runCatching {
        val map = surahTafsir(edition, surah)
        map[ayah] ?: error("ما لقيناش التفسير ديال هاد الآية")
    }

    private suspend fun surahTafsir(edition: TafsirEdition, surah: Int): Map<Int, String> {
        val key = "${edition.apiId}_$surah"
        memory[key]?.let { return it }
        val file = File(context.filesDir, "tafsir/$key.json")
        val url = if (edition.isFrench) {
            // المختصر فالتفسير بالفرنسية: [{surah, ayah, text}, …]
            "https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/french-mokhtasar/$surah.json"
        } else {
            "https://api.alquran.cloud/v1/surah/$surah/${edition.apiId}"
        }
        val raw = withContext(Dispatchers.IO) {
            if (file.exists()) file.readText()
            else download(url).also {
                file.parentFile?.mkdirs()
                file.writeText(it)
            }
        }
        val map = if (edition.isFrench) {
            json.parseToJsonElement(raw).jsonArray.associate {
                val o = it.jsonObject
                o["ayah"]!!.jsonPrimitive.int to o["text"]!!.jsonPrimitive.content
            }
        } else {
            val ayahs = json.parseToJsonElement(raw).jsonObject["data"]!!.jsonObject["ayahs"]!!.jsonArray
            ayahs.associate {
                val o = it.jsonObject
                o["numberInSurah"]!!.jsonPrimitive.int to o["text"]!!.jsonPrimitive.content
            }
        }
        memory[key] = map
        return map
    }

    private fun download(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 20_000
        try {
            if (conn.responseCode != 200) error("مشكل فالسيرفر (${conn.responseCode})")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
