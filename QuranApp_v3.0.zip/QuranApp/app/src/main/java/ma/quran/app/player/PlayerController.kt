package ma.quran.app.player

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import ma.quran.app.data.AyahRef
import ma.quran.app.data.Reciter
import ma.quran.app.data.Surah

data class PlayerState(
    val current: AyahRef? = null,
    val surahName: String = "",
    val reciterName: String = "",
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val repeatAyah: Boolean = false,
    val error: String? = null,
    /** إلا كان كيتشغل دعاء: الرقم ديالو */
    val duaId: Int? = null,
    val title: String = "",
    /** إلا كانت كتشغل سورة كاملة فملف واحد (ورش): الرقم ديالها */
    val fullSurah: Int? = null,
)

/** كيتواصل مع PlaybackService عبر MediaController */
class PlayerController(context: Context) {
    private val appContext = context.applicationContext
    private var controller: MediaController? = null
    private var connecting = false
    private val pending = ArrayList<(MediaController) -> Unit>()

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = update(player)
        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
            _state.value = _state.value.copy(error = "ما قدرناش نشغلو الصوت، تأكد من الأنترنيت")
        }
    }

    private fun withController(action: (MediaController) -> Unit) {
        controller?.let { action(it); return }
        pending += action
        if (connecting) return
        connecting = true
        val token = SessionToken(appContext, ComponentName(appContext, PlaybackService::class.java))
        val future = MediaController.Builder(appContext, token).buildAsync()
        future.addListener({
            connecting = false
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            controller = c
            c.addListener(listener)
            update(c)
            pending.toList().forEach { it(c) }
            pending.clear()
        }, ContextCompat.getMainExecutor(appContext))
    }

    fun connect() = withController { }

    /** إلا كانت الآية محملة فالتلفون كنشغلو الملف المحلي (بلا أنترنيت) */
    private fun ayahUri(reciter: Reciter, surah: Int, ayah: Int): String {
        val f = java.io.File(appContext.filesDir, "audio/${reciter.folder}/" + String.format(java.util.Locale.ROOT, "%03d%03d.mp3", surah, ayah))
        return if (f.exists()) android.net.Uri.fromFile(f).toString() else reciter.url(surah, ayah)
    }

    /** تشغيل سورة كاملة من ملف واحد (رواية ورش) */
    fun playFullSurah(surahId: Int, surahName: String, reciter: ma.quran.app.data.SurahReciter) = withController { c ->
        val f = java.io.File(appContext.filesDir, "audio/full/${reciter.id}/" + String.format(java.util.Locale.ROOT, "%03d.mp3", surahId))
        val uri = if (f.exists()) android.net.Uri.fromFile(f).toString() else reciter.url(surahId)
        val item = MediaItem.Builder()
            .setMediaId("full:$surahId")
            .setUri(uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle("سورة $surahName (ورش)")
                    .setArtist(reciter.name)
                    .setAlbumTitle("سورة $surahName")
                    .build()
            )
            .build()
        _state.value = _state.value.copy(surahName = surahName, reciterName = reciter.name, error = null)
        c.repeatMode = Player.REPEAT_MODE_OFF
        c.setMediaItems(listOf(item), 0, 0L)
        c.prepare()
        c.play()
    }

    fun playSurah(surah: Surah, fromAyah: Int, reciter: Reciter) = withController { c ->
        val items = surah.ayahs.map { a ->
            MediaItem.Builder()
                .setMediaId("${surah.id}:${a.number}")
                .setUri(ayahUri(reciter, surah.id, a.number))
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle("سورة ${surah.name} - الآية ${a.number}")
                        .setArtist(reciter.name)
                        .setAlbumTitle("سورة ${surah.name}")
                        .build()
                )
                .build()
        }
        _state.value = _state.value.copy(surahName = surah.name, reciterName = reciter.name, error = null)
        c.setMediaItems(items, (fromAyah - 1).coerceIn(0, items.lastIndex), 0L)
        c.prepare()
        c.play()
    }

    /** للأطفال: كل آية كتعاود [times] مرات */
    fun playKids(surah: Surah, fromAyah: Int, toAyah: Int, reciter: Reciter, times: Int) = withController { c ->
        val items = ArrayList<MediaItem>()
        for (a in surah.ayahs) {
            if (a.number < fromAyah || a.number > toAyah) continue
            repeat(times.coerceAtLeast(1)) {
                items += MediaItem.Builder()
                    .setMediaId("${surah.id}:${a.number}")
                    .setUri(ayahUri(reciter, surah.id, a.number))
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle("سورة ${surah.name} - الآية ${a.number}")
                            .setArtist(reciter.name)
                            .setAlbumTitle("سورة ${surah.name}")
                            .build()
                    )
                    .build()
            }
        }
        if (items.isEmpty()) return@withController
        _state.value = _state.value.copy(surahName = surah.name, reciterName = reciter.name, error = null)
        c.repeatMode = Player.REPEAT_MODE_OFF
        c.setMediaItems(items, 0, 0L)
        c.prepare()
        c.play()
    }

    /** تشغيل أدعية (حصن المسلم) */
    fun playDuas(chapterTitle: String, duas: List<ma.quran.app.data.Dua>, startIndex: Int, single: Boolean) = withController { c ->
        val list = if (single) listOf(duas[startIndex]) else duas
        val items = list.mapIndexed { i, d ->
            MediaItem.Builder()
                .setMediaId("dua:${d.id}")
                .setUri(d.audioUrl)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle("$chapterTitle (${i + 1})")
                        .setArtist("حصن المسلم")
                        .setAlbumTitle(chapterTitle)
                        .build()
                )
                .build()
        }
        _state.value = _state.value.copy(error = null)
        c.repeatMode = Player.REPEAT_MODE_OFF
        c.setMediaItems(items, if (single) 0 else startIndex, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() = withController { c -> if (c.isPlaying) c.pause() else c.play() }
    fun next() = withController { it.seekToNextMediaItem() }
    fun previous() = withController { it.seekToPreviousMediaItem() }

    fun toggleRepeatAyah() = withController { c ->
        c.repeatMode = if (c.repeatMode == Player.REPEAT_MODE_ONE) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ONE
    }

    fun stop() = withController { c ->
        c.stop()
        c.clearMediaItems()
    }

    fun clearError() { _state.value = _state.value.copy(error = null) }

    private fun update(p: Player) {
        val item = p.currentMediaItem
        val title = item?.mediaMetadata?.albumTitle?.toString()?.removePrefix("سورة ")
        val mid = item?.mediaId
        _state.value = _state.value.copy(
            duaId = mid?.takeIf { it.startsWith("dua:") }?.removePrefix("dua:")?.toIntOrNull(),
            title = item?.mediaMetadata?.title?.toString().orEmpty(),
            current = if (mid?.startsWith("dua:") == true || mid?.startsWith("full:") == true) null else AyahRef.parse(mid),
            fullSurah = mid?.takeIf { it.startsWith("full:") }?.removePrefix("full:")?.toIntOrNull(),
            surahName = title ?: _state.value.surahName,
            reciterName = item?.mediaMetadata?.artist?.toString() ?: _state.value.reciterName,
            isPlaying = p.isPlaying,
            isBuffering = p.playbackState == Player.STATE_BUFFERING,
            repeatAyah = p.repeatMode == Player.REPEAT_MODE_ONE,
        )
    }
}
