package ma.quran.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import ma.quran.app.QuranApplication
import ma.quran.app.data.Dua
import ma.quran.app.data.DuaChapter

data class ChaptersUi(val loading: Boolean = true, val list: List<DuaChapter> = emptyList(), val error: String? = null)
data class DuasUi(val loading: Boolean = true, val list: List<Dua> = emptyList(), val error: String? = null)

class DuaViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as QuranApplication
    private val repo = a.duas
    val player = a.player

    private val _chapters = MutableStateFlow(ChaptersUi())
    val chapters = _chapters.asStateFlow()

    private val _duas = MutableStateFlow(DuasUi())
    val duas = _duas.asStateFlow()

    /** تقدم التحميل الكامل: (المحمل، المجموع) */
    private val _download = MutableStateFlow<Pair<Int, Int>?>(null)
    val download = _download.asStateFlow()

    private val err = "ما قدرناش نجيبو الأدعية. تأكد من الأنترنيت (أول مرة فقط) وعاود."

    init { loadChapters() }

    fun loadChapters() {
        _chapters.value = ChaptersUi(loading = true)
        viewModelScope.launch {
            _chapters.value = repo.chapters().fold({ ChaptersUi(false, it) }, { ChaptersUi(false, error = err) })
        }
    }

    fun chapter(id: Int): DuaChapter? = _chapters.value.list.firstOrNull { it.id == id }

    fun loadDuas(id: Int) {
        _duas.value = DuasUi(loading = true)
        viewModelScope.launch {
            val c = chapter(id) ?: repo.chapters().getOrNull()?.firstOrNull { it.id == id }
            if (c == null) { _duas.value = DuasUi(false, error = err); return@launch }
            _duas.value = repo.chapter(c).fold({ DuasUi(false, it) }, { DuasUi(false, error = err) })
        }
    }

    fun isCached(id: Int) = repo.isCached(id)

    fun downloadAll() {
        if (_download.value != null) return
        _download.value = 0 to 1
        viewModelScope.launch {
            repo.downloadAll { done, total -> _download.value = done to total }
            _download.value = null
            loadChapters()
        }
    }

    fun play(title: String, list: List<Dua>, index: Int, single: Boolean) = player.playDuas(title, list, index, single)
}
