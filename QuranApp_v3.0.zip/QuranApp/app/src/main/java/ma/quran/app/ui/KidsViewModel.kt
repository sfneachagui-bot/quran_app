package ma.quran.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import ma.quran.app.QuranApplication
import ma.quran.app.data.Reciter
import ma.quran.app.data.Surah
import ma.quran.app.data.TEACHER_RECITERS

class KidsViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as QuranApplication
    val player = a.player

    val memorized = a.prefs.kidsMemorized.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())
    val scores = a.prefs.kidsScores.stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    fun toggleMemorized(id: Int) = viewModelScope.launch { a.prefs.toggleMemorized(id) }
    fun saveScore(id: String, correct: Int, total: Int) = viewModelScope.launch {
        a.prefs.saveScore(id, starsFor(correct, total))
    }

    fun play(s: Surah, from: Int, to: Int, reciter: Reciter = TEACHER_RECITERS.first(), times: Int) =
        player.playKids(s, from, to, reciter, times)

    companion object {
        fun starsFor(correct: Int, total: Int): Int {
            if (total == 0) return 0
            val r = correct.toFloat() / total
            return when {
                r >= 0.99f -> 3
                r >= 0.7f -> 2
                r >= 0.4f -> 1
                else -> 0
            }
        }
    }
}
