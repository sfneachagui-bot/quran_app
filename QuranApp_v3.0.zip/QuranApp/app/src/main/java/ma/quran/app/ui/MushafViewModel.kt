package ma.quran.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import ma.quran.app.QuranApplication
import ma.quran.app.data.MushafPage
import ma.quran.app.data.Riwaya
import ma.quran.app.data.SurahReciter

/** المصحف بالصفحات + مقرئين ورش + التحميلات */
@OptIn(ExperimentalCoroutinesApi::class)
class MushafViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as QuranApplication
    val audio = a.audio

    val riwaya: StateFlow<Riwaya> = a.prefs.settings.map { it.riwaya }
        .stateIn(viewModelScope, SharingStarted.Eagerly, Riwaya.HAFS)

    private val _pages = MutableStateFlow<List<MushafPage>>(emptyList())
    val pages = _pages.asStateFlow()

    /** أسماء السور حسب الرواية (للعناوين) */
    private val _names = MutableStateFlow<List<String>>(emptyList())
    val names = _names.asStateFlow()

    val lastPage: StateFlow<Int> = a.prefs.settings.map { it.riwaya }
        .flatMapLatest { a.prefs.mushafPage(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, 1)

    private var loaded: Riwaya? = null

    init {
        viewModelScope.launch {
            riwaya.collect { r -> load(r) }
        }
    }

    private suspend fun load(r: Riwaya) {
        if (loaded == r && _pages.value.isNotEmpty()) return
        _pages.value = emptyList()
        val pages = a.mushaf.pages(r)
        _names.value = (1..114).map { a.mushaf.surahName(r, it) }
        _pages.value = pages
        loaded = r
    }

    fun setRiwaya(r: Riwaya) = viewModelScope.launch { a.prefs.setRiwaya(r) }
    fun savePage(page: Int) = viewModelScope.launch { a.prefs.setMushafPage(riwaya.value, page) }

    suspend fun pageOfSurah(surah: Int): Int = a.mushaf.pageOfSurah(riwaya.value, surah)

    // ───────────── مقرئين ورش ─────────────
    private val _warsh = MutableStateFlow<List<SurahReciter>>(emptyList())
    val warshReciters = _warsh.asStateFlow()
    private val _warshError = MutableStateFlow<String?>(null)
    val warshError = _warshError.asStateFlow()
    private val _warshLoading = MutableStateFlow(false)
    val warshLoading = _warshLoading.asStateFlow()

    val warshReciterId: StateFlow<String> = a.prefs.settings.map { it.warshReciterId }
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")

    fun loadWarshReciters(force: Boolean = false) {
        if (_warshLoading.value || (_warsh.value.isNotEmpty() && !force)) return
        _warshLoading.value = true
        _warshError.value = null
        viewModelScope.launch {
            a.audio.warshReciters(force).fold(
                { _warsh.value = it },
                { _warshError.value = "ما قدرناش نجيبو لائحة القراء. تأكد من الأنترنيت وعاود." },
            )
            _warshLoading.value = false
        }
    }

    /** السورة اللي كنتسناو نختارو ليها مقرئ ورش */
    private val _pickWarsh = MutableStateFlow<Int?>(null)
    val pickWarsh = _pickWarsh.asStateFlow()
    fun requestWarshPlay(surah: Int) { _pickWarsh.value = surah; loadWarshReciters() }
    fun cancelWarshPick() { _pickWarsh.value = null }

    fun playWarsh(r: SurahReciter, surah: Int? = _pickWarsh.value) {
        val s = surah ?: return
        _pickWarsh.value = null
        viewModelScope.launch {
            a.prefs.setWarshReciter(r.id)
            a.player.playFullSurah(s, a.mushaf.surahName(Riwaya.WARSH, s), r)
        }
    }
}
