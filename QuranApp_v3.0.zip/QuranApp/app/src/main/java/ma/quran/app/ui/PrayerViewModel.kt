package ma.quran.app.ui

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import ma.quran.app.QuranApplication
import ma.quran.app.data.CalcMethod
import ma.quran.app.data.City
import ma.quran.app.data.Prayer
import ma.quran.app.data.PrayerCalc
import ma.quran.app.data.PrayerDay
import ma.quran.app.data.PrayerSettings
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId

data class PrayerUi(
    val settings: PrayerSettings,
    val now: LocalDateTime,
    val today: PrayerDay,
    /** الصلاة الجاية (الشروق ما كيتحسبش) ووقتها */
    val next: Prayer,
    val nextAt: LocalDateTime,
    /** الصلاة اللي فاتت (باش نحسبو نسبة الوقت اللي دازت) */
    val prevAt: LocalDateTime,
    val qibla: Double,
    val distanceKm: Double,
) {
    val remaining: Duration get() = Duration.between(now, nextAt).coerceAtLeastZero()
    val progress: Float get() {
        val total = Duration.between(prevAt, nextAt).seconds.toFloat()
        return if (total <= 0) 0f else (Duration.between(prevAt, now).seconds / total).coerceIn(0f, 1f)
    }
}

private fun Duration.coerceAtLeastZero(): Duration = if (isNegative) Duration.ZERO else this

class PrayerViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as QuranApplication

    private val ticker = flow {
        while (true) {
            emit(Unit)
            delay(1000)
        }
    }

    val ui: StateFlow<PrayerUi?> = combine(a.prefs.prayerSettings, ticker) { s, _ -> compute(s) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _locating = MutableStateFlow(false)
    val locating = _locating.asStateFlow()
    private val _message = MutableStateFlow<String?>(null)
    val message = _message.asStateFlow()
    fun clearMessage() { _message.value = null }

    private fun compute(s: PrayerSettings): PrayerUi {
        val zone = runCatching { ZoneId.of(s.zone) }.getOrDefault(ZoneId.systemDefault())
        val now = LocalDateTime.now(zone)
        val today = PrayerCalc.compute(now.toLocalDate(), s.lat, s.lon, zone, s.method, s.hanafiAsr)
        val order = listOf(Prayer.FAJR, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA)
        val todayAt = order.map { it to now.toLocalDate().atTime(today.times.getValue(it)) }
        val upcoming = todayAt.firstOrNull { it.second.isAfter(now) }
        val (next, nextAt) = upcoming ?: run {
            val tomorrow = PrayerCalc.compute(now.toLocalDate().plusDays(1), s.lat, s.lon, zone, s.method, s.hanafiAsr)
            Prayer.FAJR to now.toLocalDate().plusDays(1).atTime(tomorrow.times.getValue(Prayer.FAJR))
        }
        val idx = order.indexOf(next)
        val prevAt = if (idx > 0) todayAt[idx - 1].second
        else if (upcoming == null) todayAt.last().second
        else {
            val yesterday = PrayerCalc.compute(now.toLocalDate().minusDays(1), s.lat, s.lon, zone, s.method, s.hanafiAsr)
            now.toLocalDate().minusDays(1).atTime(yesterday.times.getValue(Prayer.ISHA))
        }
        return PrayerUi(
            s, now, today, next, nextAt, prevAt,
            PrayerCalc.qibla(s.lat, s.lon), PrayerCalc.distanceToKaaba(s.lat, s.lon),
        )
    }

    fun pickCity(c: City) = viewModelScope.launch { a.prefs.setPrayerLocation(c.name, c.lat, c.lon, c.zone) }
    fun setMethod(m: CalcMethod) = viewModelScope.launch { a.prefs.setPrayerMethod(m) }
    fun setHanafi(v: Boolean) = viewModelScope.launch { a.prefs.setHanafiAsr(v) }

    /** الموقع ديال التلفون (خاص الإذن يكون معطى قبل) */
    @SuppressLint("MissingPermission")
    fun locate() {
        val ctx = getApplication<Application>()
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        _locating.value = true
        val save: (Location?) -> Unit = { loc ->
            _locating.value = false
            if (loc == null) {
                _message.value = "ما قدرناش نلقاو الموقع. شعل الـ GPS ولا اختار المدينة من اللائحة."
            } else {
                viewModelScope.launch {
                    a.prefs.setPrayerLocation("📍 موقعي", loc.latitude, loc.longitude, ZoneId.systemDefault().id)
                    _message.value = "تم تحديد موقعك ✓"
                }
            }
        }
        try {
            val last = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)
                .mapNotNull { p -> runCatching { lm.getLastKnownLocation(p) }.getOrNull() }
                .maxByOrNull { it.time }
            if (last != null && System.currentTimeMillis() - last.time < 6 * 3600_000L) {
                save(last); return
            }
            val provider = when {
                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                else -> null
            }
            if (provider == null) { save(last); return }
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                lm.getCurrentLocation(provider, null, ContextCompat.getMainExecutor(ctx)) { loc -> save(loc ?: last) }
            } else {
                @Suppress("DEPRECATION")
                lm.requestSingleUpdate(provider, android.location.LocationListener { loc -> save(loc) }, android.os.Looper.getMainLooper())
            }
        } catch (e: SecurityException) {
            _locating.value = false
            _message.value = "خاص الإذن ديال الموقع"
        }
    }
}
