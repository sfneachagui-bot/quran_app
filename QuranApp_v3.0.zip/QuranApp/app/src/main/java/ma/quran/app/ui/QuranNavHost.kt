package ma.quran.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material.icons.filled.LocalLibrary
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import ma.quran.app.ui.screens.AyahMenuSheet
import ma.quran.app.ui.screens.ReciterPickerSheet
import ma.quran.app.ui.screens.BookmarksScreen
import ma.quran.app.ui.screens.DuaChapterScreen
import ma.quran.app.ui.screens.DuasHomeScreen
import ma.quran.app.ui.screens.KidsHomeScreen
import ma.quran.app.ui.screens.KidsLessonScreen
import ma.quran.app.ui.screens.KidsQuizListScreen
import ma.quran.app.ui.screens.KidsQuizScreen
import ma.quran.app.ui.screens.KidsSurahListScreen
import ma.quran.app.ui.screens.KidsSurahScreen
import ma.quran.app.ui.screens.HadithCollectionScreen
import ma.quran.app.ui.screens.HadithFavoritesScreen
import ma.quran.app.ui.screens.HadithHomeScreen
import ma.quran.app.ui.screens.HadithSectionScreen
import ma.quran.app.ui.screens.HomeScreen
import ma.quran.app.ui.screens.MiniPlayer
import ma.quran.app.ui.screens.MushafScreen
import ma.quran.app.ui.screens.DownloadsScreen
import ma.quran.app.ui.screens.PrayerScreen
import ma.quran.app.ui.screens.WarshReciterSheet
import ma.quran.app.ui.screens.MotionNavBar
import ma.quran.app.ui.screens.NavTab
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import ma.quran.app.ui.screens.ReaderScreen
import ma.quran.app.ui.screens.SearchScreen
import ma.quran.app.ui.screens.SettingsScreen
import ma.quran.app.ui.screens.TafsirSheet

private val tabs = listOf(
    NavTab("home", "القرآن", Icons.AutoMirrored.Filled.MenuBook),
    NavTab("hadith", "الحديث", Icons.Filled.LocalLibrary),
    NavTab("duas", "الأدعية", Icons.Filled.VolunteerActivism),
    NavTab("kids", "الأطفال", Icons.Filled.ChildCare),
    NavTab("prayer", "الصلاة", Icons.Filled.Mosque),
)

fun readerRoute(surah: Int, ayah: Int = 1) = "reader/$surah?ayah=$ayah"

@Composable
fun QuranNavHost() {
    val vm: QuranViewModel = viewModel()
    val hvm: HadithViewModel = viewModel()
    val kvm: KidsViewModel = viewModel()
    val dvm: DuaViewModel = viewModel()
    val mvm: MushafViewModel = viewModel()
    val pvm: PrayerViewModel = viewModel()
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val onTab = tabs.any { it.route == route }
    val openReader: (Int, Int) -> Unit = { s, a -> nav.navigate(readerRoute(s, a)) }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            if (onTab) Column {
                MiniPlayer(vm = vm, onOpen = { ref -> openReader(ref.surah, ref.ayah) })
                MotionNavBar(tabs, route) { t ->
                    nav.navigate(t.route) {
                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            }
        },
    ) { padding ->
        NavHost(
            nav,
            startDestination = "home",
            modifier = Modifier.fillMaxSize().padding(padding),
            // انتقالات ناعمة بين الشاشات: تلاشي + تكبير خفيف
            enterTransition = { fadeIn(tween(340)) + scaleIn(tween(340), initialScale = 0.94f) },
            exitTransition = { fadeOut(tween(220)) + scaleOut(tween(340), targetScale = 1.04f) },
            popEnterTransition = { fadeIn(tween(340)) + scaleIn(tween(340), initialScale = 1.04f) },
            popExitTransition = { fadeOut(tween(220)) + scaleOut(tween(340), targetScale = 0.94f) },
        ) {
            composable("home") {
                HomeScreen(
                    vm, openReader,
                    onSearch = { nav.navigate("search") },
                    onBookmarks = { nav.navigate("bookmarks") },
                    onMushaf = { nav.navigate("mushaf") },
                    onDownloads = { nav.navigate("downloads") },
                    onSettings = { nav.navigate("settings") },
                )
            }
            composable("duas") { DuasHomeScreen(dvm) { nav.navigate(it) } }
            composable("dua/{id}", arguments = listOf(navArgument("id") { type = NavType.IntType })) { e ->
                DuaChapterScreen(dvm, e.arguments?.getInt("id") ?: 1) { nav.popBackStack() }
            }
            composable("kids") { KidsHomeScreen(kvm) { nav.navigate(it) } }
            composable("kids_surahs") { KidsSurahListScreen(kvm, vm, { nav.popBackStack() }) { nav.navigate(it) } }
            composable("kids_surah/{id}", arguments = listOf(navArgument("id") { type = NavType.IntType })) { e ->
                KidsSurahScreen(kvm, vm, e.arguments?.getInt("id") ?: 1, { nav.popBackStack() }) { nav.navigate(it) }
            }
            composable("kids_lesson/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                KidsLessonScreen(e.arguments?.getString("id").orEmpty(), { nav.popBackStack() }) { nav.navigate(it) }
            }
            composable("kids_quizzes") { KidsQuizListScreen(kvm, vm, { nav.popBackStack() }) { nav.navigate(it) } }
            composable("kids_quiz/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                KidsQuizScreen(kvm, vm, e.arguments?.getString("id").orEmpty()) { nav.popBackStack() }
            }
            composable("hadith") { HadithHomeScreen(hvm) { nav.navigate(it) } }
            composable(
                "hadith/{c}?n={n}",
                arguments = listOf(
                    navArgument("c") { type = NavType.StringType },
                    navArgument("n") { type = NavType.IntType; defaultValue = 0 },
                ),
            ) { e ->
                val c = e.arguments?.getString("c").orEmpty()
                HadithCollectionScreen(
                    hvm, c, e.arguments?.getInt("n") ?: 0,
                    onBack = { nav.popBackStack() },
                    openSection = { s -> nav.navigate("hadith_section/$c/$s") },
                )
            }
            composable(
                "hadith_section/{c}/{s}",
                arguments = listOf(
                    navArgument("c") { type = NavType.StringType },
                    navArgument("s") { type = NavType.IntType },
                ),
            ) { e ->
                HadithSectionScreen(hvm, e.arguments?.getString("c").orEmpty(), e.arguments?.getInt("s") ?: 1) { nav.popBackStack() }
            }
            composable("hadith_favs") { HadithFavoritesScreen(hvm) { nav.popBackStack() } }
            composable("search") { SearchScreen(vm, openReader) }
            composable("bookmarks") { BookmarksScreen(vm, openReader) }
            composable("settings") { SettingsScreen(vm, onDownloads = { nav.navigate("downloads") }) }
            composable("prayer") { PrayerScreen(pvm) }
            composable("downloads") { DownloadsScreen(vm, mvm) { nav.popBackStack() } }
            composable(
                "mushaf?surah={surah}",
                arguments = listOf(navArgument("surah") { type = NavType.IntType; defaultValue = 0 }),
            ) { e ->
                MushafScreen(vm, mvm, e.arguments?.getInt("surah") ?: 0) { nav.popBackStack() }
            }
            composable(
                "reader/{surah}?ayah={ayah}",
                arguments = listOf(
                    navArgument("surah") { type = NavType.IntType },
                    navArgument("ayah") { type = NavType.IntType; defaultValue = 1 },
                ),
            ) { e ->
                ReaderScreen(
                    vm = vm,
                    surahId = e.arguments?.getInt("surah") ?: 1,
                    startAyah = e.arguments?.getInt("ayah") ?: 1,
                    onBack = { nav.popBackStack() },
                    onOpenSurah = { s -> nav.navigate(readerRoute(s)) { popUpTo("reader/{surah}?ayah={ayah}") { inclusive = true } } },
                )
            }
        }
    }
    TafsirSheet(vm)
    AyahMenuSheet(vm)
    ReciterPickerSheet(vm)

    // لون أيقونات شريط الحالة: فاتح فوق الأخضر (الرئيسية والقراءة)، غامق فالباقي
    val view = LocalView.current
    val dark = isSystemInDarkTheme()
    LaunchedEffect(route, dark) {
        val window = (view.context as? Activity)?.window ?: return@LaunchedEffect
        val onGreen = route == "home" || route == "prayer" || route == "downloads" || route?.startsWith("mushaf") == true || route?.startsWith("reader") == true || route?.startsWith("hadith") == true || route?.startsWith("kids") == true || route?.startsWith("dua") == true
        WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !onGreen && !dark
    }
}
