package ma.quran.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import ma.quran.app.QuranApplication
import ma.quran.app.data.Ayah
import ma.quran.app.data.AyahRef
import ma.quran.app.data.Parts
import ma.quran.app.data.Settings
import ma.quran.app.data.Surah
import ma.quran.app.data.TafsirEdition
import ma.quran.app.data.Translation

sealed interface TafsirState {
    data object Loading : TafsirState
    data class Loaded(val text: String) : TafsirState
    data class Failed(val message: String) : TafsirState
}

class QuranViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as QuranApplication
    val player = a.player

    private val _surahs = MutableStateFlow<List<Surah>>(emptyList())
    val surahs: StateFlow<List<Surah>> = _surahs.asStateFlow()

    private val _parts = MutableStateFlow<Parts?>(null)
    val parts: StateFlow<Parts?> = _parts.asStateFlow()

    val settings = a.prefs.settings.stateIn(viewModelScope, SharingStarted.Eagerly, Settings())
    val bookmarks = a.prefs.bookmarks.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val lastRead = a.prefs.lastRead.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val readingLog = a.prefs.readingLog.stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    /** بداية كل سورة فالترقيم العام (0..6235) */
    private var offsets: IntArray = IntArray(0)
    val totalAyahs: Int get() = _surahs.value.sumOf { it.ayahs.size }

    /** الترتيب ديال الآية فالمصحف كامل (0..6235) */
    fun globalIndex(ref: AyahRef): Int {
        val o = offsets.getOrNull(ref.surah - 1) ?: return 0
        return o + (ref.ayah - 1).coerceAtLeast(0)
    }

    /** نسبة التقدم فالمصحف حسب آخر آية تقرات */
    fun progressOf(ref: AyahRef?): Float {
        val total = totalAyahs
        if (ref == null || total == 0) return 0f
        return (globalIndex(ref) + 1).toFloat() / total
    }

    private val _searchResults = MutableStateFlow<List<Ayah>>(emptyList())
    val searchResults = _searchResults.asStateFlow()
    private var searchJob: Job? = null

    private val _tafsir = MutableStateFlow<Pair<Ayah, TafsirState>?>(null)
    val tafsir = _tafsir.asStateFlow()

    init {
        viewModelScope.launch {
            val list = a.quran.surahs()
            offsets = IntArray(list.size).also { arr ->
                var acc = 0
                list.forEachIndexed { i, su -> arr[i] = acc; acc += su.ayahs.size }
            }
            _surahs.value = list
            _parts.value = a.quran.parts()
        }
        player.connect()
    }

    fun search(q: String) {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(300)
            _searchResults.value = a.quran.search(q)
        }
    }

    fun ayah(ref: AyahRef): Ayah? = _surahs.value.getOrNull(ref.surah - 1)?.ayahs?.getOrNull(ref.ayah - 1)

    fun toggleBookmark(ref: AyahRef) = viewModelScope.launch { a.prefs.toggleBookmark(ref) }
    fun saveLastRead(ref: AyahRef) = viewModelScope.launch {
        // كنحسبو شحال من آية تقرات (الفرق بين الآية الجديدة والقديمة، بحد أقصى 40 فالمرة)
        val prev = lastRead.value
        if (prev != null && prev != ref && offsets.isNotEmpty()) {
            val delta = kotlin.math.abs(globalIndex(ref) - globalIndex(prev)).coerceAtMost(40)
            if (delta > 0) a.prefs.logReading(java.time.LocalDate.now().toString(), delta)
        } else if (prev == null) {
            a.prefs.logReading(java.time.LocalDate.now().toString(), 1)
        }
        a.prefs.setLastRead(ref)
    }

    fun play(surah: Surah, fromAyah: Int) = player.playSurah(surah, fromAyah, settings.value.reciter)

    /** قبل التشغيل كنطلبو من المستعمل يختار المقرئ */
    private val _pickReciter = MutableStateFlow<Pair<Surah, Int>?>(null)
    val pickReciter = _pickReciter.asStateFlow()
    fun requestPlay(surah: Surah, fromAyah: Int) { _pickReciter.value = surah to fromAyah }
    fun cancelPick() { _pickReciter.value = null }
    fun playWith(reciterId: String) {
        val (surah, from) = _pickReciter.value ?: return
        _pickReciter.value = null
        val r = ma.quran.app.data.RECITERS.firstOrNull { it.id == reciterId } ?: settings.value.reciter
        viewModelScope.launch { a.prefs.setReciter(r.id) }
        player.playSurah(surah, from, r)
    }

    fun openTafsir(ayah: Ayah, edition: TafsirEdition = settings.value.tafsir) {
        _tafsir.value = ayah to TafsirState.Loading
        viewModelScope.launch {
            val r = a.tafsir.tafsir(edition, ayah.surah, ayah.number)
            if (_tafsir.value?.first == ayah) {
                _tafsir.value = ayah to r.fold(
                    { TafsirState.Loaded(it) },
                    { TafsirState.Failed("ما قدرناش نجيبو التفسير. تأكد من الأنترنيت (أول مرة فقط) وعاود.") },
                )
            }
        }
    }

    fun changeTafsirEdition(ayah: Ayah, e: TafsirEdition) {
        viewModelScope.launch { a.prefs.setTafsir(e) }
        openTafsir(ayah, e)
    }

    fun closeTafsir() { _tafsir.value = null }

    /** القائمة اللي كتبان ملي تضغط مطولا على آية */
    private val _ayahMenu = MutableStateFlow<Ayah?>(null)
    val ayahMenu = _ayahMenu.asStateFlow()
    fun openAyahMenu(a: Ayah) { _ayahMenu.value = a }
    fun closeAyahMenu() { _ayahMenu.value = null }

    fun setFontSize(v: Float) = viewModelScope.launch { a.prefs.setFontSize(v) }
    fun setTranslation(t: Translation) = viewModelScope.launch { a.prefs.setTranslation(t) }
    fun setReciter(id: String) = viewModelScope.launch { a.prefs.setReciter(id) }
    fun setCardMode(v: Boolean) = viewModelScope.launch { a.prefs.setCardMode(v) }
    fun setTafsir(t: TafsirEdition) = viewModelScope.launch { a.prefs.setTafsir(t) }
}
