package ma.quran.app.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ma.quran.app.data.DownloadState
import ma.quran.app.data.Riwaya
import ma.quran.app.data.toArabicDigits
import ma.quran.app.ui.MushafViewModel
import ma.quran.app.ui.QuranViewModel
import ma.quran.app.ui.theme.DeepGreen
import ma.quran.app.ui.theme.Gold
import ma.quran.app.ui.theme.QuranFont
import ma.quran.app.ui.theme.StarBadge
import ma.quran.app.ui.theme.StarPattern
import ma.quran.app.ui.theme.staggeredEntrance

/** تحميل السور للاستماع بلا أنترنيت (حفص آية بآية، ورش السورة كاملة) */
@Composable
fun DownloadsScreen(vm: QuranViewModel, mvm: MushafViewModel, onBack: () -> Unit) {
    val surahs by vm.surahs.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val downloads by mvm.audio.downloads.collectAsStateWithLifecycle()
    val version by mvm.audio.version.collectAsStateWithLifecycle()
    val warsh by mvm.warshReciters.collectAsStateWithLifecycle()
    val warshId by mvm.warshReciterId.collectAsStateWithLifecycle()
    val warshLoading by mvm.warshLoading.collectAsStateWithLifecycle()
    val warshError by mvm.warshError.collectAsStateWithLifecycle()
    var riwaya by rememberSaveable { mutableStateOf(Riwaya.HAFS) }
    var pickedWarsh by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(riwaya) { if (riwaya == Riwaya.WARSH) mvm.loadWarshReciters() }

    val hafsReciter = settings.reciter
    val warshReciter = warsh.firstOrNull { it.id == pickedWarsh } ?: warsh.firstOrNull { it.id == warshId } ?: warsh.firstOrNull()
    val used = remember(version, downloads.size) { mvm.audio.usedMb() }

    Column(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF0B3D26), DeepGreen, Color(0xFF1C7A4D)))),
        ) {
            StarPattern(Modifier.matchParentSize())
            Column(Modifier.statusBarsPadding().padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = Color.White) }
                    Column(Modifier.weight(1f)) {
                        Text("الاستماع بلا أنترنيت", color = Gold, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        Text(
                            "المساحة المستعملة: ${String.format(java.util.Locale.ROOT, "%.1f", used)} MB",
                            color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    if (used > 0f) TextButton(onClick = { mvm.audio.deleteAll() }) { Text("مسح الكل", color = Color.White) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Riwaya.entries.forEach { r ->
                        FilterChip(selected = riwaya == r, onClick = { riwaya = r }, label = { Text(r.label, color = if (riwaya == r) DeepGreen else Color.White) })
                    }
                }
                Text(
                    if (riwaya == Riwaya.HAFS) "المقرئ: ${hafsReciter.name} (بدلو من الإعدادات)" else "المقرئ: ${warshReciter?.name ?: "…"}",
                    color = Color.White, style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                if (riwaya == Riwaya.WARSH && warsh.isNotEmpty()) {
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        warsh.forEach { r ->
                            FilterChip(
                                selected = r.id == warshReciter?.id,
                                onClick = { pickedWarsh = r.id },
                                label = { Text(r.name, fontSize = 12.sp, color = if (r.id == warshReciter?.id) DeepGreen else Color.White) },
                            )
                        }
                    }
                }
            }
        }

        if (riwaya == Riwaya.WARSH && warsh.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) {
                if (warshLoading) CircularProgressIndicator()
                else Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(warshError ?: "")
                    TextButton(onClick = { mvm.loadWarshReciters(force = true) }) { Icon(Icons.Filled.Refresh, null); Text(" عاود") }
                }
            }
            return@Column
        }

        LazyColumn(Modifier.fillMaxSize()) {
            items(114) { i ->
                val id = i + 1
                val name = surahs.getOrNull(i)?.name.orEmpty()
                val count = surahs.getOrNull(i)?.ayahs?.size ?: 0
                val key: String
                val done: Boolean
                val available: Boolean
                if (riwaya == Riwaya.HAFS) {
                    key = mvm.audio.hafsKey(hafsReciter, id)
                    done = remember(version, hafsReciter.id) { count > 0 && mvm.audio.isSurahDownloaded(hafsReciter, id, count) }
                    available = true
                } else {
                    val r = warshReciter!!
                    key = mvm.audio.warshKey(r, id)
                    done = remember(version, r.id) { mvm.audio.surahFile(r, id).exists() }
                    available = r.surahs.isEmpty() || id in r.surahs
                }
                DownloadRow(
                    index = i, number = id, name = name,
                    subtitle = if (riwaya == Riwaya.HAFS) "${count.toArabicDigits()} آية" else if (available) "ملف واحد" else "ما متوفراش عند هاد المقرئ",
                    state = downloads[key], done = done, enabled = available,
                    onDownload = {
                        if (riwaya == Riwaya.HAFS) mvm.audio.downloadHafs(hafsReciter, id, count)
                        else warshReciter?.let { mvm.audio.downloadSurah(it, id) }
                    },
                    onCancel = { mvm.audio.cancel(key) },
                    onDelete = {
                        if (riwaya == Riwaya.HAFS) mvm.audio.deleteHafs(hafsReciter, id, count)
                        else warshReciter?.let { mvm.audio.deleteSurah(it, id) }
                    },
                )
            }
        }
    }
}

@Composable
private fun DownloadRow(
    index: Int,
    number: Int,
    name: String,
    subtitle: String,
    state: DownloadState?,
    done: Boolean,
    enabled: Boolean,
    onDownload: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
) {
    val running = state?.running == true
    val p by animateFloatAsState(state?.progress ?: 0f, label = "dl")
    Row(
        Modifier
            .fillMaxWidth()
            .staggeredEntrance(index)
            .padding(horizontal = 12.dp, vertical = 3.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StarBadge(number, size = 38.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("سورة $name", fontFamily = QuranFont, fontSize = 20.sp)
            Text(
                state?.error ?: subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = if (state?.error != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            )
            if (running) {
                Spacer(Modifier.height(4.dp))
                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Gold.copy(alpha = 0.2f))) {
                    Box(Modifier.fillMaxWidth(p).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Gold))
                }
            }
        }
        when {
            running -> IconButton(onClick = onCancel) { Icon(Icons.Filled.Close, "إلغاء") }
            done -> Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.CheckCircle, "محملة", tint = Color(0xFF10AC84), modifier = Modifier.size(22.dp))
                IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "حذف", tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)) }
            }
            enabled -> IconButton(onClick = onDownload) { Icon(Icons.Filled.Download, "تحميل", tint = MaterialTheme.colorScheme.primary) }
        }
    }
}
