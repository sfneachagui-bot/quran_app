package ma.quran.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ma.quran.app.data.ArabicText
import ma.quran.app.data.Dua
import ma.quran.app.data.DuaChapter
import ma.quran.app.data.toArabicDigits
import ma.quran.app.ui.DuaViewModel
import ma.quran.app.ui.theme.Gold
import ma.quran.app.ui.theme.OrnamentDivider
import ma.quran.app.ui.theme.QuranFont
import ma.quran.app.ui.theme.StarBadge
import ma.quran.app.ui.theme.StarPattern

private val DuaBrush = Brush.linearGradient(listOf(Color(0xFF0B3A4A), Color(0xFF0E6B6B), Color(0xFF1C8C7A)))
private val Teal = Color(0xFF0E6B6B)

/** أهم الأذكار اللي كتبان لفوق */
private val FEATURED = listOf(
    "الصباح" to "☀️", "النوم" to "🌙", "الاستيقاظ" to "🌅", "الصلاة" to "🕌",
    "المسجد" to "🕋", "الطعام" to "🍽️", "السفر" to "✈️", "الكرب" to "💚",
)

// ------------------------------------------------------------------
// الصفحة الرئيسية ديال الأدعية
// ------------------------------------------------------------------
@Composable
fun DuasHomeScreen(dvm: DuaViewModel, open: (String) -> Unit) {
    val ui by dvm.chapters.collectAsStateWithLifecycle()
    val dl by dvm.download.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                    .background(DuaBrush),
            ) {
                StarPattern(Modifier.matchParentSize())
                Column(
                    Modifier
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp)
                        .padding(top = 12.dp, bottom = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("الأدعية والأذكار", fontFamily = QuranFont, fontSize = 34.sp, color = Gold)
                    Text("من حصن المسلم • مقروءة بالصوت", color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.labelLarge)
                    OrnamentDivider(Modifier.width(180.dp).height(14.dp))
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("ابحث: السفر، المطر، المريض…", color = Color.White.copy(alpha = 0.7f)) },
                        leadingIcon = { Icon(Icons.Filled.Search, null, tint = Color.White) },
                        singleLine = true,
                        shape = RoundedCornerShape(28.dp),
                        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Gold,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.4f),
                            cursorColor = Gold,
                        ),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }

        when {
            ui.loading -> item {
                Box(Modifier.fillMaxWidth().padding(40.dp), Alignment.Center) { CircularProgressIndicator() }
            }
            ui.error != null -> item {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("📶", fontSize = 48.sp)
                    Text(ui.error!!, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = dvm::loadChapters) { Text("عاود المحاولة") }
                }
            }
            else -> {
                val q = ArabicText.normalize(query)
                val filtered = if (q.isBlank()) ui.list else ui.list.filter { ArabicText.normalize(it.title).contains(q) }

                if (q.isBlank()) {
                    val featured = FEATURED.mapNotNull { (kw, emoji) ->
                        ui.list.firstOrNull { it.title.contains(kw) }?.let { it to emoji }
                    }.distinctBy { it.first.id }
                    if (featured.isNotEmpty()) {
                        item { DuaSectionTitle("الأذكار اليومية") }
                        item {
                            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(featured, key = { it.first.id }) { (c, emoji) ->
                                    Column(
                                        Modifier
                                            .width(120.dp)
                                            .height(130.dp)
                                            .clip(RoundedCornerShape(22.dp))
                                            .background(Teal.copy(alpha = 0.14f))
                                            .clickable { open("dua/${c.id}") }
                                            .padding(10.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center,
                                    ) {
                                        Text(emoji, fontSize = 38.sp)
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            c.title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            textAlign = TextAlign.Center,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    }
                                }
                            }
                        }
                    }
                    item {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            val d = dl
                            if (d != null) {
                                Column(Modifier.weight(1f)) {
                                    Text("كنحملو الأدعية… ${d.first.toArabicDigits()}/${d.second.toArabicDigits()}", style = MaterialTheme.typography.labelMedium)
                                    LinearProgressIndicator(
                                        progress = { if (d.second == 0) 0f else d.first / d.second.toFloat() },
                                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                    )
                                }
                            } else {
                                OutlinedButton(onClick = dvm::downloadAll, shape = RoundedCornerShape(50), modifier = Modifier.fillMaxWidth()) {
                                    Icon(Icons.Filled.CloudDownload, null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("حمّل النصوص كاملين للاستعمال بلا أنترنيت")
                                }
                            }
                        }
                    }
                    item { DuaSectionTitle("كل الأبواب (${ui.list.size.toArabicDigits()})") }
                }

                items(filtered, key = { it.id }) { c ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 3.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainer)
                            .clickable { open("dua/${c.id}") }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        StarBadge(c.id)
                        Spacer(Modifier.width(12.dp))
                        Text(c.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        if (dvm.isCached(c.id)) Icon(Icons.Filled.CloudDone, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                    }
                }
                if (filtered.isEmpty()) item {
                    Text("ما لقينا حتى باب بهاد الكلمة", modifier = Modifier.fillMaxWidth().padding(24.dp), textAlign = TextAlign.Center)
                }
            }
        }
    }
}

@Composable
private fun DuaSectionTitle(t: String) {
    Text(
        t,
        style = MaterialTheme.typography.titleMedium,
        color = Teal,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 6.dp),
    )
}

// ------------------------------------------------------------------
// باب: لائحة الأذكار مع الصوت والعداد
// ------------------------------------------------------------------
@Composable
fun DuaChapterScreen(dvm: DuaViewModel, id: Int, onBack: () -> Unit) {
    val ui by dvm.duas.collectAsStateWithLifecycle()
    val chapters by dvm.chapters.collectAsStateWithLifecycle()
    val player by dvm.player.state.collectAsStateWithLifecycle()
    val chapter: DuaChapter? = chapters.list.firstOrNull { it.id == id }
    val title = chapter?.title ?: ""
    LaunchedEffect(id) { dvm.loadDuas(id) }

    // العداد ديال كل ذكر
    val counts = remember(id) { mutableStateMapOf<Int, Int>() }
    val listState = rememberLazyListState()
    val playingId = player.duaId
    LaunchedEffect(playingId, ui.list) {
        val i = ui.list.indexOfFirst { it.id == playingId }
        if (i >= 0) listState.animateScrollToItem(i + 1)
    }
    val chapterPlaying = playingId != null && ui.list.any { it.id == playingId }

    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        GreenTopBar(title, if (ui.list.isNotEmpty()) "${ui.list.size.toArabicDigits()} ذكر" else null, onBack) {
            IconButton(onClick = { counts.clear() }) { Icon(Icons.Filled.Refresh, "صفر العداد", tint = Color.White) }
        }
        when {
            ui.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            ui.error != null -> Box(Modifier.fillMaxSize().padding(24.dp), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(ui.error!!, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { dvm.loadDuas(id) }) { Text("عاود المحاولة") }
                }
            }
            else -> LazyColumn(state = listState, contentPadding = PaddingValues(bottom = 16.dp)) {
                item {
                    Button(
                        onClick = {
                            if (chapterPlaying) dvm.player.togglePlay()
                            else dvm.play(title, ui.list, 0, single = false)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Teal),
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.fillMaxWidth().padding(12.dp).height(52.dp),
                    ) {
                        Icon(if (chapterPlaying && player.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            when {
                                chapterPlaying && player.isPlaying -> "وقف"
                                chapterPlaying -> "كمل"
                                else -> "استمع لكل الأذكار"
                            },
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
                itemsIndexed(ui.list, key = { _, d -> d.id }) { i, d ->
                    DuaCard(
                        d = d,
                        index = i,
                        title = title,
                        playing = d.id == playingId,
                        isPlaying = player.isPlaying,
                        count = counts[d.id] ?: 0,
                        onCount = { counts[d.id] = ((counts[d.id] ?: 0) + 1).coerceAtMost(d.repeat) },
                        onPlay = {
                            if (d.id == playingId) dvm.player.togglePlay()
                            else dvm.play(title, ui.list, i, single = true)
                        },
                    )
                }
                item {
                    Text(
                        "المصدر: حصن المسلم (hisnmuslim.com)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        textAlign = TextAlign.Center,
                    )
                }
            }
        }
    }
}

@Composable
private fun DuaCard(
    d: Dua,
    index: Int,
    title: String,
    playing: Boolean,
    isPlaying: Boolean,
    count: Int,
    onCount: () -> Unit,
    onPlay: () -> Unit,
) {
    val context = LocalContext.current
    val done = count >= d.repeat
    val bg by animateColorAsState(
        when {
            playing -> MaterialTheme.colorScheme.secondaryContainer
            done -> Teal.copy(alpha = 0.12f)
            else -> MaterialTheme.colorScheme.surfaceContainer
        },
        label = "duaBg",
    )
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .then(if (playing) Modifier.border(1.5.dp, Gold, RoundedCornerShape(20.dp)) else Modifier)
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StarBadge(index + 1, size = 36.dp)
            Spacer(Modifier.width(8.dp))
            if (d.repeat > 1) {
                Surface(shape = RoundedCornerShape(50), color = Gold.copy(alpha = 0.25f)) {
                    Text(
                        "🔁 ${d.repeat.toArabicDigits()} مرات",
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                    )
                }
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onPlay) {
                Icon(if (playing && isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "استمع", tint = Teal)
            }
            IconButton(onClick = { copyDua(context, d, title) }) { Icon(Icons.Filled.ContentCopy, "نسخ") }
            IconButton(onClick = { shareDua(context, d, title) }) { Icon(Icons.Filled.Share, "مشاركة") }
        }
        SelectionContainer {
            Text(d.text, fontFamily = QuranFont, fontSize = 21.sp, lineHeight = 40.sp, modifier = Modifier.padding(vertical = 6.dp))
        }
        // العداد: ضغط حتى توصل للعدد
        Surface(
            onClick = onCount,
            shape = RoundedCornerShape(50),
            color = if (done) Teal else Teal.copy(alpha = 0.15f),
            contentColor = if (done) Color.White else Teal,
            modifier = Modifier.fillMaxWidth().height(46.dp),
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    if (done) "✓ تم (${d.repeat.toArabicDigits()})" else "اضغط للعد: ${count.toArabicDigits()} / ${d.repeat.toArabicDigits()}",
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

private fun duaShareText(d: Dua, title: String) = "${d.text}\n[$title - حصن المسلم]"

private fun copyDua(context: Context, d: Dua, title: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("دعاء", duaShareText(d, title)))
    Toast.makeText(context, "تنسخ الدعاء", Toast.LENGTH_SHORT).show()
}

private fun shareDua(context: Context, d: Dua, title: String) {
    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, duaShareText(d, title))
    context.startActivity(Intent.createChooser(i, "مشاركة الدعاء"))
}
