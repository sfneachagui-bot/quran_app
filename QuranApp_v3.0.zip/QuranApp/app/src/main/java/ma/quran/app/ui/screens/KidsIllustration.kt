package ma.quran.app.ui.screens

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import ma.quran.app.data.LessonStep
import ma.quran.app.data.toArabicDigits

/**
 * الرسم التوضيحي ديال الخطوة: كيدخل بنقزة ملي كتوصل للصفحة،
 * كيعوم بشوية، وكيكبر ببطء (Ken Burns)، مع شارة الإيموجي فالقنت.
 */
@Composable
fun StepIllustration(
    @DrawableRes image: Int,
    emoji: String,
    color: Color,
    active: Boolean,
    modifier: Modifier = Modifier,
) {
    val enter = remember { Animatable(0.82f) }
    val tilt = remember { Animatable(-6f) }
    LaunchedEffect(active) {
        if (active) {
            enter.snapTo(0.82f); tilt.snapTo(-6f)
            launch { enter.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 220f)) }
            tilt.animateTo(0f, spring(dampingRatio = 0.35f, stiffness = 120f))
        }
    }
    val t = rememberInfiniteTransition(label = "illus")
    val float by t.animateFloat(-5f, 5f, infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "float")
    val zoom by t.animateFloat(1f, 1.06f, infiniteRepeatable(tween(5000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "zoom")
    val badge by t.animateFloat(0.9f, 1.12f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "badge")

    Box(modifier.widthIn(max = 320.dp).fillMaxWidth().aspectRatio(1f)) {
        Box(
            Modifier
                .fillMaxSize()
                .padding(8.dp)
                .graphicsLayer {
                    scaleX = enter.value; scaleY = enter.value
                    rotationZ = tilt.value
                    translationY = float * density
                }
                .shadow(16.dp, RoundedCornerShape(36.dp), ambientColor = color, spotColor = color)
                .clip(RoundedCornerShape(36.dp))
                .border(4.dp, color.copy(alpha = 0.55f), RoundedCornerShape(36.dp)),
        ) {
            Image(
                painterResource(image),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { scaleX = zoom; scaleY = zoom },
            )
        }
        // شارة الإيموجي
        Box(
            Modifier
                .align(Alignment.TopStart)
                .size(58.dp)
                .graphicsLayer { scaleX = badge; scaleY = badge }
                .shadow(8.dp, CircleShape)
                .clip(CircleShape)
                .background(Color.White)
                .border(3.dp, color, CircleShape),
            contentAlignment = Alignment.Center,
        ) { Text(emoji, fontSize = 28.sp) }
    }
}

/** شريط صغير فيه كل الخطوات مصورين: كتشوف فين وصلتي وتقدر تقفز لأي خطوة */
@Composable
fun StepsStrip(steps: List<LessonStep>, current: Int, color: Color, onPick: (Int) -> Unit) {
    val state = rememberLazyListState()
    LaunchedEffect(current) { if (current >= 0) state.animateScrollToItem((current - 2).coerceAtLeast(0)) }
    LazyRow(
        state = state,
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
    ) {
        itemsIndexed(steps) { i, s ->
            val sel = i == current
            val done = i < current
            val scale by animateFloatAsState(if (sel) 1.12f else 1f, spring(dampingRatio = 0.5f), label = "thumb")
            Box(
                Modifier
                    .padding(vertical = 6.dp)
                    .size(52.dp)
                    .graphicsLayer { scaleX = scale; scaleY = scale; alpha = if (sel || done) 1f else 0.55f }
                    .clip(RoundedCornerShape(14.dp))
                    .border(if (sel) 3.dp else 1.dp, if (sel) color else Color.Black.copy(alpha = 0.1f), RoundedCornerShape(14.dp))
                    .clickable { onPick(i) },
            ) {
                val img = s.image
                if (img != null) {
                    Image(painterResource(img), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                } else {
                    Text(s.emoji, fontSize = 24.sp, modifier = Modifier.align(Alignment.Center))
                }
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .padding(2.dp)
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(if (done) Color(0xFF10AC84) else color),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(if (done) "✓" else (i + 1).toArabicDigits(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
