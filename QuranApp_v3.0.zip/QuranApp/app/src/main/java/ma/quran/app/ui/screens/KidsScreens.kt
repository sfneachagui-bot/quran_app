package ma.quran.app.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import ma.quran.app.data.KIDS_SURAHS
import ma.quran.app.data.KidsContent
import ma.quran.app.data.Lesson
import ma.quran.app.data.Quiz
import ma.quran.app.data.TEACHER_RECITERS
import ma.quran.app.data.toArabicDigits
import ma.quran.app.ui.KidsViewModel
import ma.quran.app.ui.QuranViewModel
import ma.quran.app.ui.theme.QuranFont

private val KidOrange = Color(0xFFFF9F43)
private val KidBlue = Color(0xFF54A0FF)
private val KidPurple = Color(0xFF8E7CFF)
private val KidGreen = Color(0xFF10AC84)
private val KidPink = Color(0xFFFF6B9D)
private val KidYellow = Color(0xFFFECA57)

private fun stars(n: Int) = "⭐".repeat(n) + "☆".repeat((3 - n).coerceAtLeast(0))

// ------------------------------------------------------------------
// رأس ملون
// ------------------------------------------------------------------
@Composable
private fun KidsHeader(title: String, subtitle: String?, colors: List<Color>, onBack: (() -> Unit)?) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(Brush.linearGradient(colors)),
    ) {
        // فقاعات للزينة
        Box(Modifier.align(Alignment.TopEnd).padding(top = 10.dp, end = 30.dp).size(60.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.15f)))
        Box(Modifier.align(Alignment.BottomStart).padding(start = 40.dp, bottom = 6.dp).size(34.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f)))
        Row(
            Modifier
                .statusBarsPadding()
                .padding(horizontal = 6.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (onBack != null) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = Color.White) }
            } else Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                if (subtitle != null) Text(subtitle, color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

// ------------------------------------------------------------------
// ركن الأطفال
// ------------------------------------------------------------------
@Composable
fun KidsHomeScreen(kvm: KidsViewModel, open: (String) -> Unit) {
    val memorized by kvm.memorized.collectAsStateWithLifecycle()
    val scores by kvm.scores.collectAsStateWithLifecycle()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        KidsHeader("ركن الأطفال 🌟", "نتعلمو القرآن والوضوء والصلاة ونلعبو!", listOf(KidPurple, KidBlue), null)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BigCard(
                "📖", "حفظ قصار السور", "المصحف المعلم • ${memorized.size.toArabicDigits()}/${KIDS_SURAHS.size.toArabicDigits()} ⭐",
                listOf(KidGreen, Color(0xFF1DD1A1)), Modifier.weight(1f),
            ) { open("kids_surahs") }
            BigCard(
                "💧", "تعلّم الوضوء", scores["wudu"]?.let { stars(it) } ?: "١١ خطوة",
                listOf(KidBlue, Color(0xFF48DBFB)), Modifier.weight(1f), image = KidsContent.wudu.cover,
            ) { open("kids_lesson/wudu") }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BigCard(
                "🕌", "تعلّم الصلاة", scores["salah"]?.let { stars(it) } ?: "١٣ خطوة",
                listOf(KidOrange, KidYellow), Modifier.weight(1f), image = KidsContent.salah.cover,
            ) { open("kids_lesson/salah") }
            BigCard(
                "🏆", "الاختبارات", "${scores.values.sum().toArabicDigits()} ⭐ مجموع النجوم",
                listOf(KidPink, Color(0xFFFF9FF3)), Modifier.weight(1f),
            ) { open("kids_quizzes") }
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "💡 للوالدين: المصحف المعلم كيخلي القارئ يقرا بشوية والطفل يعاود من وراه. تقدرو تكررو كل آية 3 ولا 5 ديال المرات.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        )
    }
}

@Composable
private fun BigCard(
    emoji: String,
    title: String,
    subtitle: String,
    colors: List<Color>,
    modifier: Modifier,
    @androidx.annotation.DrawableRes image: Int? = null,
    onClick: () -> Unit,
) {
    Column(
        modifier
            .aspectRatio(0.9f)
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(colors))
            .clickable(onClick = onClick)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        if (image != null) {
            androidx.compose.foundation.Image(
                androidx.compose.ui.res.painterResource(image), null,
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier
                    .size(78.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .border(3.dp, Color.White.copy(alpha = 0.8f), RoundedCornerShape(22.dp)),
            )
        } else {
            Text(emoji, fontSize = 56.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, textAlign = TextAlign.Center)
        Text(subtitle, color = Color.White.copy(alpha = 0.92f), fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

// ------------------------------------------------------------------
// لائحة قصار السور
// ------------------------------------------------------------------
@Composable
fun KidsSurahListScreen(kvm: KidsViewModel, qvm: QuranViewModel, onBack: () -> Unit, open: (String) -> Unit) {
    val surahs by qvm.surahs.collectAsStateWithLifecycle()
    val memorized by kvm.memorized.collectAsStateWithLifecycle()
    val scores by kvm.scores.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        KidsHeader(
            "حفظ قصار السور 📖",
            "حفظتي ${memorized.size.toArabicDigits()} من ${KIDS_SURAHS.size.toArabicDigits()} سورة",
            listOf(KidGreen, Color(0xFF1DD1A1)), onBack,
        )
        LinearProgressIndicator(
            progress = { memorized.size / KIDS_SURAHS.size.toFloat() },
            color = KidYellow,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp).height(10.dp).clip(RoundedCornerShape(50)),
        )
        LazyColumn(contentPadding = PaddingValues(vertical = 4.dp)) {
            items(KIDS_SURAHS, key = { it }) { id ->
                val s = surahs.getOrNull(id - 1) ?: return@items
                val done = id in memorized
                val colors = listOf(KidGreen, KidBlue, KidOrange, KidPurple, KidPink)
                val c = colors[id % colors.size]
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(c.copy(alpha = if (done) 0.28f else 0.13f))
                        .clickable { open("kids_surah/$id") }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(46.dp).clip(CircleShape).background(c), contentAlignment = Alignment.Center) {
                        Text(if (done) "⭐" else id.toArabicDigits(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("سورة ${s.name}", fontFamily = QuranFont, fontSize = 24.sp)
                        Text(
                            "${s.ayahs.size.toArabicDigits()} آيات" + (scores["surah_$id"]?.let { "  •  ${stars(it)}" } ?: ""),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    if (done) Text("حفظتها ✓", color = KidGreen, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ------------------------------------------------------------------
// سورة: المصحف المعلم مع التكرار
// ------------------------------------------------------------------
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun KidsSurahScreen(kvm: KidsViewModel, qvm: QuranViewModel, id: Int, onBack: () -> Unit, open: (String) -> Unit) {
    val surahs by qvm.surahs.collectAsStateWithLifecycle()
    val memorized by kvm.memorized.collectAsStateWithLifecycle()
    val player by kvm.player.state.collectAsStateWithLifecycle()
    val s = surahs.getOrNull(id - 1) ?: return
    var reciterIdx by rememberSaveable { mutableIntStateOf(0) }
    var times by rememberSaveable { mutableIntStateOf(3) }
    val reciter = TEACHER_RECITERS[reciterIdx]
    val playing = player.current?.takeIf { it.surah == id }?.ayah ?: 0
    val listState = rememberLazyListState()
    LaunchedEffect(playing) { if (playing > 0) listState.animateScrollToItem(playing) }

    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        KidsHeader("سورة ${s.name}", "${s.ayahs.size.toArabicDigits()} آيات • ${if (s.isMeccan) "مكية" else "مدنية"}", listOf(KidGreen, KidBlue), onBack)
        LazyColumn(state = listState, modifier = Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
            item {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainer)
                        .padding(14.dp),
                ) {
                    Text("🎙️ القارئ", fontWeight = FontWeight.Bold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TEACHER_RECITERS.forEachIndexed { i, r ->
                            FilterChip(selected = i == reciterIdx, onClick = { reciterIdx = i }, label = { Text(r.name) })
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("🔁 شحال من مرة نعاودو كل آية؟", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(1, 3, 5, 10).forEach { n ->
                            FilterChip(selected = times == n, onClick = { times = n }, label = { Text("${n.toArabicDigits()} مرات") })
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = {
                                if (playing > 0) kvm.player.togglePlay()
                                else kvm.play(s, 1, s.ayahs.size, reciter, times)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = KidOrange),
                            shape = RoundedCornerShape(50),
                        ) {
                            Icon(if (playing > 0 && player.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
                            Spacer(Modifier.width(6.dp))
                            Text(if (playing > 0) (if (player.isPlaying) "وقف" else "كمل") else "استمع للسورة كاملة")
                        }
                        if (playing > 0) OutlinedButton(onClick = kvm.player::stop, shape = RoundedCornerShape(50)) { Text("حبس") }
                    }
                }
            }
            items(s.ayahs, key = { it.key }) { a ->
                val active = a.number == playing
                val bg by animateColorAsState(
                    if (active) KidYellow.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.6f),
                    label = "kidAyah",
                )
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 5.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(bg)
                        .then(if (active) Modifier.border(2.dp, KidOrange, RoundedCornerShape(22.dp)) else Modifier)
                        .padding(14.dp),
                ) {
                    Text(
                        "${a.text} ۝${a.number.toArabicDigits()}",
                        fontFamily = QuranFont,
                        fontSize = 30.sp,
                        lineHeight = 58.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                        Surface(
                            onClick = { kvm.play(s, a.number, a.number, reciter, times) },
                            shape = RoundedCornerShape(50),
                            color = KidBlue,
                            contentColor = Color.White,
                        ) {
                            Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.PlayArrow, null, Modifier.size(18.dp))
                                Text(" استمع × ${times.toArabicDigits()}", fontWeight = FontWeight.Bold)
                            }
                        }
                        Surface(
                            onClick = { qvm.openTafsir(a) },
                            shape = RoundedCornerShape(50),
                            color = KidPurple,
                            contentColor = Color.White,
                        ) {
                            Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.AutoMirrored.Filled.MenuBook, null, Modifier.size(18.dp))
                                Text(" شنو معناها؟", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    val done = id in memorized
                    Button(
                        onClick = { kvm.toggleMemorized(id) },
                        colors = ButtonDefaults.buttonColors(containerColor = if (done) KidGreen else KidOrange),
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                    ) { Text(if (done) "⭐ حفظت هاد السورة! (ضغط باش تلغي)" else "✅ حفظت هاد السورة", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { open("kids_quiz/surah_$id") },
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                    ) { Text("🏆 اختبر راسك فهاد السورة", fontSize = 17.sp) }
                }
            }
        }
    }
}

// ------------------------------------------------------------------
// درس مصور (الوضوء / الصلاة)
// ------------------------------------------------------------------
@Composable
fun KidsLessonScreen(lessonId: String, onBack: () -> Unit, open: (String) -> Unit) {
    val lesson: Lesson = KidsContent.lessons.firstOrNull { it.id == lessonId } ?: return
    val colors = if (lessonId == "wudu") listOf(KidBlue, Color(0xFF48DBFB)) else listOf(KidOrange, KidYellow)
    val main = colors.first()
    // الصفحة 0 = المقدمة، من بعد الخطوات، والصفحة الأخيرة = النهاية
    val pages = lesson.steps.size + 2
    val pager = rememberPagerState(pageCount = { pages })
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        KidsHeader("${lesson.title} ${lesson.emoji}", null, colors, onBack)
        LinearProgressIndicator(
            progress = { (pager.currentPage + 1) / pages.toFloat() },
            color = main,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp).height(10.dp).clip(RoundedCornerShape(50)),
        )
        // كل الخطوات مصورين: ضغط على وحدة باش تمشي ليها
        StepsStrip(lesson.steps, pager.currentPage - 1, main) { i ->
            scope.launch { pager.animateScrollToPage(i + 1) }
        }
        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                when (page) {
                    0 -> {
                        val cover = lesson.cover
                        if (cover != null) StepIllustration(cover, lesson.emoji, main, active = pager.currentPage == 0)
                        else EmojiCircle(lesson.emoji, main)
                        Spacer(Modifier.height(16.dp))
                        Text(lesson.title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = main)
                        Spacer(Modifier.height(10.dp))
                        Text(lesson.intro, fontSize = 19.sp, lineHeight = 32.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(10.dp))
                        Text("👉 سحب ولا ضغط على \"التالي\"", style = MaterialTheme.typography.bodyMedium)
                    }
                    pages - 1 -> {
                        EmojiCircle("🎉", KidGreen)
                        Spacer(Modifier.height(16.dp))
                        Text("برافو عليك!", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = KidGreen)
                        Text("كملتي ${lesson.title}", fontSize = 19.sp)
                        if (lesson.note != null) {
                            Spacer(Modifier.height(14.dp))
                            Text(
                                lesson.note,
                                fontSize = 16.sp,
                                lineHeight = 28.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(KidYellow.copy(alpha = 0.25f))
                                    .padding(14.dp),
                            )
                        }
                        Spacer(Modifier.height(18.dp))
                        Button(
                            onClick = { open("kids_quiz/$lessonId") },
                            colors = ButtonDefaults.buttonColors(containerColor = KidPink),
                            shape = RoundedCornerShape(50),
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                        ) { Text("🏆 اختبر راسك", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                    }
                    else -> {
                        val step = lesson.steps[page - 1]
                        Text(
                            "الخطوة ${page.toArabicDigits()} من ${lesson.steps.size.toArabicDigits()}",
                            color = main, fontWeight = FontWeight.Bold,
                        )
                        Spacer(Modifier.height(10.dp))
                        val img = step.image
                        if (img != null) StepIllustration(img, step.emoji, main, active = pager.currentPage == page)
                        else EmojiCircle(step.emoji, main)
                        Spacer(Modifier.height(16.dp))
                        Text(step.title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                        if (step.times != null) {
                            Spacer(Modifier.height(6.dp))
                            Surface(shape = RoundedCornerShape(50), color = KidYellow) {
                                Text("🔁 ${step.times}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp), color = Color.Black)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(step.text, fontSize = 20.sp, lineHeight = 34.sp, textAlign = TextAlign.Center)
                        if (step.say != null) {
                            Spacer(Modifier.height(14.dp))
                            Text(
                                step.say,
                                fontFamily = QuranFont,
                                fontSize = 24.sp,
                                lineHeight = 46.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(main.copy(alpha = 0.15f))
                                    .padding(14.dp),
                            )
                        }
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedButton(
                onClick = { scope.launch { pager.animateScrollToPage((pager.currentPage - 1).coerceAtLeast(0)) } },
                enabled = pager.currentPage > 0,
                shape = RoundedCornerShape(50),
                modifier = Modifier.weight(1f).height(52.dp),
            ) { Text("السابق", fontSize = 17.sp) }
            Button(
                onClick = { scope.launch { pager.animateScrollToPage((pager.currentPage + 1).coerceAtMost(pages - 1)) } },
                enabled = pager.currentPage < pages - 1,
                colors = ButtonDefaults.buttonColors(containerColor = main),
                shape = RoundedCornerShape(50),
                modifier = Modifier.weight(1f).height(52.dp),
            ) { Text("التالي", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun EmojiCircle(emoji: String, color: Color) {
    Box(
        Modifier
            .size(170.dp)
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(color.copy(alpha = 0.35f), color.copy(alpha = 0.1f)))),
        contentAlignment = Alignment.Center,
    ) {
        Text(emoji, fontSize = 90.sp)
    }
}

// ------------------------------------------------------------------
// لائحة الاختبارات
// ------------------------------------------------------------------
@Composable
fun KidsQuizListScreen(kvm: KidsViewModel, qvm: QuranViewModel, onBack: () -> Unit, open: (String) -> Unit) {
    val scores by kvm.scores.collectAsStateWithLifecycle()
    val surahs by qvm.surahs.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        KidsHeader("الاختبارات 🏆", "جاوب وربح النجوم!", listOf(KidPink, Color(0xFFFF9FF3)), onBack)
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { QuizRow("💧", "اختبار الوضوء", scores["wudu"], KidBlue) { open("kids_quiz/wudu") } }
            item { QuizRow("🕌", "اختبار الصلاة", scores["salah"], KidOrange) { open("kids_quiz/salah") } }
            item { Text("📖 اختبارات السور", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp, start = 6.dp)) }
            items(KIDS_SURAHS, key = { it }) { id ->
                val s = surahs.getOrNull(id - 1) ?: return@items
                QuizRow("📖", "سورة ${s.name}", scores["surah_$id"], KidGreen) { open("kids_quiz/surah_$id") }
            }
        }
    }
}

@Composable
private fun QuizRow(emoji: String, title: String, stars: Int?, color: Color, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(color.copy(alpha = 0.15f))
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(emoji, fontSize = 28.sp)
        Spacer(Modifier.width(12.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
        Text(if (stars != null) stars(stars) else "ابدأ ▶", color = color, fontWeight = FontWeight.Bold)
    }
}

// ------------------------------------------------------------------
// الاختبار
// ------------------------------------------------------------------
@Composable
fun KidsQuizScreen(kvm: KidsViewModel, qvm: QuranViewModel, quizId: String, onBack: () -> Unit) {
    val surahs by qvm.surahs.collectAsStateWithLifecycle()
    val quiz: Quiz = remember(quizId, surahs.size) {
        KidsContent.quiz(quizId)
            ?: quizId.removePrefix("surah_").toIntOrNull()?.let { surahs.getOrNull(it - 1) }?.let { KidsContent.surahQuiz(it) }
    } ?: return

    var index by rememberSaveable { mutableIntStateOf(0) }
    var correct by rememberSaveable { mutableIntStateOf(0) }
    var picked by rememberSaveable { mutableIntStateOf(-1) }
    var finished by rememberSaveable { mutableStateOf(false) }
    val isSurah = quizId.startsWith("surah_")

    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        KidsHeader(quiz.title, if (finished) null else "السؤال ${(index + 1).toArabicDigits()} من ${quiz.questions.size.toArabicDigits()}", listOf(KidPink, KidPurple), onBack)
        if (finished) {
            val st = KidsViewModel.starsFor(correct, quiz.questions.size)
            LaunchedEffect(Unit) { kvm.saveScore(quiz.id, correct, quiz.questions.size) }
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(if (st == 3) "🏆" else if (st >= 1) "🎉" else "💪", fontSize = 90.sp)
                Text(stars(st), fontSize = 40.sp)
                Spacer(Modifier.height(10.dp))
                Text(
                    "جاوبتي صحيح على ${correct.toArabicDigits()} من ${quiz.questions.size.toArabicDigits()}",
                    fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                )
                Text(
                    when (st) {
                        3 -> "ماشاء الله! نتا بطل 🌟"
                        2 -> "مزيان بزاف! زيد شوية وتوصل للـ 3 نجوم"
                        1 -> "مزيان! عاود الدرس وجرب مرة أخرى"
                        else -> "ما كاين مشكل، عاود الدرس وغادي تنجح إن شاء الله"
                    },
                    fontSize = 18.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp),
                )
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = { index = 0; correct = 0; picked = -1; finished = false },
                    colors = ButtonDefaults.buttonColors(containerColor = KidOrange),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                ) { Text("🔁 عاود الاختبار", fontSize = 18.sp) }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = onBack, shape = RoundedCornerShape(50), modifier = Modifier.fillMaxWidth().height(54.dp)) {
                    Text("رجوع", fontSize = 18.sp)
                }
            }
            return@Column
        }

        val q = quiz.questions[index]
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(q.emoji, fontSize = 64.sp)
            Spacer(Modifier.height(10.dp))
            Text(
                q.question,
                fontSize = if (isSurah) 20.sp else 22.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                lineHeight = 36.sp,
                fontFamily = if (isSurah) QuranFont else null,
            )
            Spacer(Modifier.height(18.dp))
            q.options.forEachIndexed { i, opt ->
                val color = when {
                    picked < 0 -> KidBlue
                    i == q.answer -> KidGreen
                    i == picked -> Color(0xFFEE5253)
                    else -> Color.Gray
                }
                Surface(
                    onClick = {
                        if (picked < 0) {
                            picked = i
                            if (i == q.answer) correct++
                        }
                    },
                    shape = RoundedCornerShape(22.dp),
                    color = color.copy(alpha = if (picked < 0) 0.15f else 0.3f),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(34.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
                            Text(
                                when {
                                    picked >= 0 && i == q.answer -> "✓"
                                    picked == i -> "✗"
                                    else -> listOf("أ", "ب", "ج", "د")[i % 4]
                                },
                                color = Color.White, fontWeight = FontWeight.Bold,
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(
                            opt,
                            fontSize = if (isSurah) 20.sp else 19.sp,
                            lineHeight = if (isSurah) 38.sp else 28.sp,
                            fontFamily = if (isSurah) QuranFont else null,
                        )
                    }
                }
            }
            if (picked >= 0) {
                Spacer(Modifier.height(10.dp))
                Text(
                    if (picked == q.answer) "صحيح! 🎉" else "ماشي هي، الجواب الصحيح بالأخضر 👍",
                    fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    color = if (picked == q.answer) KidGreen else Color(0xFFEE5253),
                )
            }
        }
        Button(
            onClick = {
                if (index < quiz.questions.size - 1) { index++; picked = -1 } else finished = true
            },
            enabled = picked >= 0,
            colors = ButtonDefaults.buttonColors(containerColor = KidPurple),
            shape = RoundedCornerShape(50),
            modifier = Modifier.fillMaxWidth().padding(16.dp).height(54.dp),
        ) {
            Text(if (index < quiz.questions.size - 1) "السؤال التالي" else "شوف النتيجة 🏆", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}
