package ma.quran.app.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ma.quran.app.ui.theme.DeepGreen
import ma.quran.app.ui.theme.Gold
import ma.quran.app.ui.theme.drawStar

data class NavTab(val route: String, val label: String, val icon: ImageVector)

/**
 * شريط التنقل المتحرك: كبسولة خضرا عائمة، مؤشر ذهبي كيزلق للتبويب المختار
 * بنابض (spring)، والأيقونة كتنقز وكتبان من وراها نجمة كدور.
 */
@Composable
fun MotionNavBar(tabs: List<NavTab>, selectedRoute: String?, onSelect: (NavTab) -> Unit) {
    val selected = tabs.indexOfFirst { it.route == selectedRoute }.coerceAtLeast(0)
    Box(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .height(66.dp)
                .shadow(14.dp, RoundedCornerShape(33.dp), ambientColor = DeepGreen, spotColor = DeepGreen)
                .clip(RoundedCornerShape(33.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF0B3D26), DeepGreen, Color(0xFF0B3D26)))),
        ) {
            val itemW = maxWidth / tabs.size
            // offset و CenterStart كيحترمو الاتجاه: فـ RTL كنبداو من اليمين
            val x by animateDpAsState(
                itemW * selected,
                spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMediumLow),
                label = "indicator",
            )
            // المؤشر الذهبي
            Box(
                Modifier
                    .align(Alignment.CenterStart)
                    .offset(x = x)
                    .width(itemW)
                    .fillMaxHeight()
                    .padding(6.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.verticalGradient(listOf(Gold.copy(alpha = 0.35f), Gold.copy(alpha = 0.12f)))),
            )
            Row(Modifier.fillMaxWidth().fillMaxHeight()) {
                tabs.forEachIndexed { i, t ->
                    NavItem(t, i == selected, Modifier.weight(1f)) { onSelect(t) }
                }
            }
        }
    }
}

@Composable
private fun NavItem(tab: NavTab, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val scale by animateFloatAsState(
        if (selected) 1.18f else 1f,
        spring(dampingRatio = Spring.DampingRatioHighBouncy, stiffness = Spring.StiffnessLow),
        label = "scale",
    )
    val lift by animateDpAsState(if (selected) (-3).dp else 0.dp, spring(dampingRatio = 0.5f), label = "lift")
    val starAngle by animateFloatAsState(if (selected) 0f else -90f, spring(dampingRatio = 0.6f, stiffness = 90f), label = "star")
    val starAlpha by animateFloatAsState(if (selected) 1f else 0f, label = "starA")
    val tint by animateColorAsState(if (selected) Gold else Color.White.copy(alpha = 0.65f), label = "tint")
    Column(
        modifier
            .fillMaxHeight()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
    ) {
        Box(Modifier.size(30.dp).offset(y = lift), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(30.dp).graphicsLayer { alpha = starAlpha }) {
                rotate(starAngle) { drawStar(center, size.minDimension / 2, Gold.copy(alpha = 0.25f)) }
            }
            Icon(
                tab.icon, tab.label, tint = tint,
                modifier = Modifier.size(22.dp).graphicsLayer { scaleX = scale; scaleY = scale },
            )
        }
        Spacer(Modifier.height(2.dp))
        Text(
            tab.label,
            color = tint,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1,
        )
    }
}
