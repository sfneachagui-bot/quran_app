package ma.quran.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import ma.quran.app.R
import ma.quran.app.data.MushafPage
import ma.quran.app.data.PageAyah
import ma.quran.app.data.Riwaya
import ma.quran.app.data.toArabicDigits
import ma.quran.app.ui.MushafViewModel
import ma.quran.app.ui.QuranViewModel
import ma.quran.app.ui.theme.DeepGreen
import ma.quran.app.ui.theme.Gold
import ma.quran.app.ui.theme.QuranFont
import ma.quran.app.ui.theme.SpinningStar
import ma.quran.app.ui.theme.StarBadge
import ma.quran.app.ui.theme.StarPattern
import ma.quran.app.ui.theme.drawStar
import kotlin.math.absoluteValue

val WarshFont = FontFamily(Font(R.font.warsh_uthmani))

private const val BASMALA_HAFS = "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ"
private const val BASMALA_WARSH = "بِسْمِ اِ۬للَّهِ اِ۬لرَّحْمَٰنِ اِ۬لرَّحِيمِ"

/** أجزاء الصفحة: عنوان سورة، بسملة، ولا نص */
private sealed interface PageBlock {
    data class Banner(val surah: Int) : PageBlock
    data object Basmala : PageBlock
    data class Text(val ayahs: List<PageAyah>) : PageBlock
}

private fun blocksOf(page: MushafPage, riwaya: Riwaya): List<PageBlock> {
    val out = ArrayList<PageBlock>()
    var run = ArrayList<PageAyah>()
    for (a in page.ayahs) {
        if (a.ayah == 1) {
            if (run.isNotEmpty()) { out += PageBlock.Text(run); run = ArrayList() }
            out += PageBlock.Banner(a.surah)
            // فحفص البسملة هي الآية 1 ديال الفاتحة؛ فورش ماشي آية. التوبة بلا بسملة.
            val basmala = a.surah != 9 && !(riwaya == Riwaya.HAFS && a.surah == 1)
            if (basmala) out += PageBlock.Basmala
        }
        run += a
    }
    if (run.isNotEmpty()) out += PageBlock.Text(run)
    return out
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MushafScreen(vm: QuranViewModel, mvm: MushafViewModel, startSurah: Int, onBack: () -> Unit) {
    val riwaya by mvm.riwaya.collectAsStateWithLifecycle()
    val pages by mvm.pages.collectAsStateWithLifecycle()
    val names by mvm.names.collectAsStateWithLifecycle()
    val parts by vm.parts.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val last by mvm.lastPage.collectAsStateWithLifecycle()
    var chrome by remember { mutableStateOf(true) }
    var index by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    if (pages.isEmpty() || names.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { SpinningStar(size = 72.dp) }
        return
    }

    // كنفتحو على السورة المطلوبة ولا على آخر صفحة
    val pager = rememberPagerState(initialPage = (last - 1).coerceIn(0, pages.lastIndex)) { pages.size }
    LaunchedEffect(riwaya, startSurah) {
        if (startSurah > 0) pager.scrollToPage(mvm.pageOfSurah(startSurah) - 1)
        else pager.scrollToPage((last - 1).coerceIn(0, pages.lastIndex))
    }
    LaunchedEffect(pager, riwaya) {
        snapshotFlow { pager.settledPage }.distinctUntilChanged().collect { mvm.savePage(it + 1) }
    }

    val font = if (riwaya == Riwaya.WARSH) WarshFont else QuranFont
    val paper = MaterialTheme.colorScheme.background

    Box(Modifier.fillMaxSize().background(paper)) {
        HorizontalPager(
            state = pager,
            beyondViewportPageCount = 1,
            key = { "${riwaya.name}-$it" },
            modifier = Modifier.fillMaxSize(),
        ) { i ->
            val page = pages[i]
            // تأثير قلبان الصفحة: دوران خفيف + تصغير + ظل
            val offset = ((pager.currentPage - i) + pager.currentPageOffsetFraction)
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val f = offset.coerceIn(-1f, 1f)
                        rotationY = f * -14f
                        cameraDistance = 14f * density
                        val s = lerp(1f, 0.9f, f.absoluteValue)
                        scaleX = s; scaleY = s
                        alpha = lerp(1f, 0.55f, f.absoluteValue)
                    }
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { chrome = !chrome },
            ) {
                MushafPageView(
                    page = page,
                    riwaya = riwaya,
                    names = names,
                    juz = if (riwaya == Riwaya.HAFS) parts?.juzOf(ma.quran.app.data.AyahRef(page.ayahs.first().surah, page.ayahs.first().ayah)) else null,
                    font = font,
                    fontSize = (settings.fontSize * 0.86f),
                )
            }
        }

        // الشريط الفوقاني
        AnimatedVisibility(
            visible = chrome,
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter),
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF0B3D26), DeepGreen))),
            ) {
                StarPattern(Modifier.matchParentSize())
                Column(Modifier.statusBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = Color.White) }
                        Text(
                            "المصحف • ${riwaya.label}",
                            color = Gold, fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f),
                        )
                        IconButton(onClick = { index = true }) { Icon(Icons.AutoMirrored.Filled.List, "فهرس السور", tint = Color.White) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(horizontal = 8.dp)) {
                        Riwaya.entries.forEach { r ->
                            FilterChip(
                                selected = riwaya == r,
                                onClick = { mvm.setRiwaya(r) },
                                label = { Text(r.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = Color.White.copy(alpha = 0.1f),
                                    labelColor = Color.White,
                                    selectedContainerColor = Gold,
                                    selectedLabelColor = DeepGreen,
                                ),
                            )
                        }
                    }
                }
            }
        }

        // الشريط التحتاني: رقم الصفحة + السلايدر + الاستماع
        AnimatedVisibility(
            visible = chrome,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            val current = pages.getOrNull(pager.currentPage)
            var drag by remember { mutableFloatStateOf(-1f) }
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .background(Brush.verticalGradient(listOf(DeepGreen, Color(0xFF0B3D26))))
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val shown = if (drag >= 0) drag.toInt() + 1 else pager.currentPage + 1
                    Text(
                        "صفحة ${shown.toArabicDigits()} من ${pages.size.toArabicDigits()}",
                        color = Color.White, modifier = Modifier.weight(1f),
                    )
                    if (current != null) {
                        val first = current.ayahs.first()
                        TextButton(onClick = {
                            if (riwaya == Riwaya.HAFS) {
                                vm.surahs.value.getOrNull(first.surah - 1)?.let { vm.requestPlay(it, first.ayah) }
                            } else {
                                mvm.requestWarshPlay(first.surah)
                            }
                        }) {
                            Icon(Icons.Filled.PlayArrow, null, tint = Gold)
                            Spacer(Modifier.width(4.dp))
                            Text("استمع • ${names.getOrNull(first.surah - 1).orEmpty()}", color = Gold)
                        }
                    }
                }
                Slider(
                    value = if (drag >= 0) drag else pager.currentPage.toFloat(),
                    onValueChange = { drag = it },
                    onValueChangeFinished = {
                        val target = drag.toInt()
                        drag = -1f
                        scope.launch { pager.animateScrollToPage(target) }
                    },
                    valueRange = 0f..(pages.size - 1).toFloat(),
                    colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold, inactiveTrackColor = Color.White.copy(alpha = 0.25f)),
                )
            }
        }
    }

    if (index) {
        ModalBottomSheet(onDismissRequest = { index = false }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
            Text(
                "فهرس السور",
                style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
            LazyColumn(Modifier.fillMaxWidth().height(480.dp)) {
                items(114) { k ->
                    ListItem(
                        leadingContent = { StarBadge(k + 1, size = 36.dp) },
                        headlineContent = { Text("سورة ${names.getOrNull(k).orEmpty()}", fontFamily = QuranFont, fontSize = 20.sp) },
                        modifier = Modifier.clickable {
                            index = false
                            scope.launch { pager.animateScrollToPage(mvm.pageOfSurah(k + 1) - 1) }
                        },
                    )
                }
            }
        }
    }
    WarshReciterSheet(mvm)
}

@Composable
private fun MushafPageView(
    page: MushafPage,
    riwaya: Riwaya,
    names: List<String>,
    juz: Int?,
    font: FontFamily,
    fontSize: Float,
) {
    val gold = Gold
    val frame = MaterialTheme.colorScheme.secondary
    val markColor = MaterialTheme.colorScheme.primary
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 10.dp, vertical = 8.dp)
            // إطار مزخرف بحال المصحف: جوج خطوط ذهبية ونجوم فالقناطر
            .drawBehind {
                val r = 18.dp.toPx()
                drawRoundRect(frame.copy(alpha = 0.9f), cornerRadius = CornerRadius(r), style = Stroke(2.5.dp.toPx()))
                val inset = 6.dp.toPx()
                drawRoundRect(
                    gold.copy(alpha = 0.6f),
                    topLeft = Offset(inset, inset),
                    size = Size(size.width - 2 * inset, size.height - 2 * inset),
                    cornerRadius = CornerRadius(r * 0.7f),
                    style = Stroke(1.dp.toPx()),
                )
                val c = 14.dp.toPx()
                listOf(Offset(c, c), Offset(size.width - c, c), Offset(c, size.height - c), Offset(size.width - c, size.height - c))
                    .forEach { drawStar(it, 7.dp.toPx(), gold) }
            }
            .padding(horizontal = 18.dp, vertical = 14.dp),
    ) {
        // رأس الصفحة: السورة والجزء
        val first = page.ayahs.first()
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("سورة ${names.getOrNull(first.surah - 1).orEmpty()}", fontFamily = QuranFont, fontSize = 17.sp, color = frame, modifier = Modifier.weight(1f))
            Text(
                if (juz != null) "الجزء ${juz.toArabicDigits()}" else riwaya.label,
                fontSize = 13.sp, color = frame,
            )
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(gold.copy(alpha = 0.5f)))
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            for (b in blocksOf(page, riwaya)) {
                when (b) {
                    is PageBlock.Banner -> SurahBanner(names.getOrNull(b.surah - 1).orEmpty())
                    PageBlock.Basmala -> Text(
                        if (riwaya == Riwaya.WARSH) BASMALA_WARSH else BASMALA_HAFS,
                        fontFamily = font, fontSize = (fontSize * 0.95f).sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                    )
                    is PageBlock.Text -> Text(
                        buildAnnotatedString {
                            b.ayahs.forEachIndexed { i, a ->
                                if (riwaya == Riwaya.WARSH) {
                                    // نص ورش فيه رقم الآية (الخط كيرسمو فدائرة)
                                    append(a.text)
                                } else {
                                    append(a.text)
                                    append(" ")
                                    pushStyle(SpanStyle(color = markColor))
                                    append("۝" + a.ayah.toArabicDigits())
                                    pop()
                                }
                                if (i < b.ayahs.lastIndex) append(" ")
                            }
                        },
                        fontFamily = font,
                        fontSize = fontSize.sp,
                        lineHeight = (fontSize * 1.85f).sp,
                        textAlign = TextAlign.Justify,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
        // رقم الصفحة
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { StarBadge(page.number, size = 38.dp) }
    }
}

/** عنوان السورة فإطار مزخرف */
@Composable
private fun SurahBanner(name: String) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(50))
            .background(Brush.horizontalGradient(listOf(Color(0xFF0B3D26), DeepGreen, Color(0xFF0B3D26))))
            .border(1.5.dp, Gold, RoundedCornerShape(50))
            .padding(vertical = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text("سُورَةُ $name", fontFamily = QuranFont, fontSize = 22.sp, color = Gold)
    }
}

/** اختيار مقرئ برواية ورش (من mp3quran.net) */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WarshReciterSheet(mvm: MushafViewModel) {
    val surah by mvm.pickWarsh.collectAsStateWithLifecycle()
    val reciters by mvm.warshReciters.collectAsStateWithLifecycle()
    val loading by mvm.warshLoading.collectAsStateWithLifecycle()
    val error by mvm.warshError.collectAsStateWithLifecycle()
    val selected by mvm.warshReciterId.collectAsStateWithLifecycle()
    val s = surah ?: return
    ModalBottomSheet(onDismissRequest = mvm::cancelWarshPick, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Text(
            "اختار مقرئ برواية ورش",
            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Text(
            "السورة كاملة • الآية اللي كتتقرا ما كتتلونش فورش",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
        )
        when {
            loading -> Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) { CircularProgressIndicator() }
            error != null -> Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(error.orEmpty(), textAlign = TextAlign.Center)
                TextButton(onClick = { mvm.loadWarshReciters(force = true) }) { Text("عاود المحاولة") }
            }
            else -> LazyColumn(Modifier.fillMaxWidth().height(440.dp)) {
                val list = reciters.filter { s in it.surahs || it.surahs.isEmpty() }
                    .sortedByDescending { it.id == selected }
                items(list.size) { i ->
                    val r = list[i]
                    ListItem(
                        headlineContent = {
                            Text(if (r.id == selected) "${r.name}  ✓" else r.name, fontWeight = if (r.id == selected) FontWeight.Bold else FontWeight.Normal)
                        },
                        leadingContent = { Icon(Icons.Filled.PlayArrow, null, tint = MaterialTheme.colorScheme.primary) },
                        modifier = Modifier.clickable { mvm.playWarsh(r, s) },
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
