package ma.quran.app.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ma.quran.app.data.CITIES
import ma.quran.app.data.CalcMethod
import ma.quran.app.data.Prayer
import ma.quran.app.data.hijriLabel
import ma.quran.app.data.toArabicDigits
import ma.quran.app.ui.PrayerUi
import ma.quran.app.ui.PrayerViewModel
import ma.quran.app.ui.theme.Gold
import ma.quran.app.ui.theme.GoldParticles
import ma.quran.app.ui.theme.ProgressRing
import ma.quran.app.ui.theme.SpinningStar
import ma.quran.app.ui.theme.drawStar
import ma.quran.app.ui.theme.rememberPulse
import ma.quran.app.ui.theme.staggeredEntrance
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.cos
import kotlin.math.sin

/** ألوان السما حسب الصلاة الجاية */
private fun skyFor(p: Prayer): List<Color> = when (p) {
    Prayer.FAJR -> listOf(Color(0xFF0B1033), Color(0xFF2B2F77), Color(0xFF5B4B8A))
    Prayer.SUNRISE, Prayer.DHUHR -> listOf(Color(0xFF1E6FB8), Color(0xFF3FA9F5), Color(0xFF9ED8FF))
    Prayer.ASR -> listOf(Color(0xFF2B7BB9), Color(0xFFF2B35B), Color(0xFFFFD98E))
    Prayer.MAGHRIB -> listOf(Color(0xFF3B2667), Color(0xFFBC4E9C), Color(0xFFF8A26B))
    Prayer.ISHA -> listOf(Color(0xFF050A1F), Color(0xFF0F1A3D), Color(0xFF1F2B5C))
}

private fun fmt(t: LocalTime) = t.format(DateTimeFormatter.ofPattern("HH:mm")).map { if (it.isDigit()) '٠' + (it - '0') else it }.joinToString("")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrayerScreen(pvm: PrayerViewModel) {
    val ui by pvm.ui.collectAsStateWithLifecycle()
    val locating by pvm.locating.collectAsStateWithLifecycle()
    val message by pvm.message.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var cities by remember { mutableStateOf(false) }
    var options by remember { mutableStateOf(false) }

    LaunchedEffect(message) {
        message?.let { Toast.makeText(context, it, Toast.LENGTH_SHORT).show(); pvm.clearMessage() }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) pvm.locate() else Toast.makeText(context, "بلا إذن الموقع، اختار المدينة من اللائحة", Toast.LENGTH_LONG).show()
    }
    val askLocation = {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) pvm.locate()
        else permission.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
    }

    val u = ui
    if (u == null) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { SpinningStar(size = 72.dp) }
        return
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        SkyHeader(u, locating, onLocate = askLocation, onCities = { cities = true }, onOptions = { options = true })
        Spacer(Modifier.height(12.dp))
        val order = listOf(Prayer.FAJR, Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA)
        order.forEachIndexed { i, p -> PrayerRow(i, p, u.today.times[p] ?: LocalTime.MIDNIGHT, p == u.next) }
        Spacer(Modifier.height(12.dp))
        QiblaCard(u)
        Text(
            "⚠️ المواقيت محسوبة فلكيا (${u.settings.method.label}). التوقيت الرسمي يقدر يختالف بدقيقة ولا جوج.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
        )
        Spacer(Modifier.height(16.dp))
    }

    if (cities) {
        ModalBottomSheet(onDismissRequest = { cities = false }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
            Text("اختار المدينة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
            ListItem(
                headlineContent = { Text("📍 استعمل موقعي (GPS)") },
                modifier = Modifier.clickable { cities = false; askLocation() },
            )
            LazyColumn(Modifier.fillMaxWidth().height(460.dp)) {
                items(CITIES.size) { i ->
                    val c = CITIES[i]
                    ListItem(
                        headlineContent = { Text(c.name, fontWeight = if (c.name == u.settings.cityName) FontWeight.Bold else FontWeight.Normal) },
                        leadingContent = { Icon(Icons.Filled.LocationCity, null, tint = MaterialTheme.colorScheme.primary) },
                        modifier = Modifier.clickable { pvm.pickCity(c); cities = false },
                    )
                }
            }
        }
    }
    if (options) {
        ModalBottomSheet(onDismissRequest = { options = false }) {
            Column(Modifier.padding(bottom = 24.dp)) {
                Text("طريقة الحساب", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
                CalcMethod.entries.forEach { m ->
                    ListItem(
                        headlineContent = { Text(m.label) },
                        leadingContent = { RadioButton(selected = u.settings.method == m, onClick = { pvm.setMethod(m) }) },
                        modifier = Modifier.clickable { pvm.setMethod(m) },
                    )
                }
                ListItem(
                    headlineContent = { Text("العصر حسب المذهب الحنفي") },
                    supportingContent = { Text("المالكي والشافعي والحنبلي: ظل الشيء مثله") },
                    trailingContent = { Switch(checked = u.settings.hanafiAsr, onCheckedChange = { pvm.setHanafi(it) }) },
                )
            }
        }
    }
}

@Composable
private fun SkyHeader(u: PrayerUi, locating: Boolean, onLocate: () -> Unit, onCities: () -> Unit, onOptions: () -> Unit) {
    val sky = skyFor(u.next)
    val c0 by animateColorAsState(sky[0], tween(1200), label = "c0")
    val c1 by animateColorAsState(sky[1], tween(1200), label = "c1")
    val c2 by animateColorAsState(sky[2], tween(1200), label = "c2")
    val night = u.next == Prayer.FAJR || u.next == Prayer.ISHA
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
            .background(Brush.verticalGradient(listOf(c0, c1, c2))),
    ) {
        GoldParticles(Modifier.matchParentSize(), count = if (night) 40 else 14, color = if (night) Color.White else Gold)
        SunArc(u, Modifier.matchParentSize())
        Column(
            Modifier.statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable(onClick = onCities)) {
                    Text(u.settings.cityName + " ▾", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("${hijriLabel(u.now.toLocalDate())}  •  ${u.now.toLocalDate()}", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                }
                IconButton(onClick = onLocate) {
                    if (locating) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                    else Icon(Icons.Filled.MyLocation, "موقعي", tint = Color.White)
                }
                IconButton(onClick = onOptions) { Icon(Icons.Filled.Tune, "طريقة الحساب", tint = Color.White) }
            }
            Spacer(Modifier.height(10.dp))
            ProgressRing(u.progress, Modifier.size(190.dp), stroke = 10.dp) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${u.next.emoji} ${u.next.label}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    val r = u.remaining
                    val secs = r.seconds
                    val txt = String.format(java.util.Locale.ROOT, "%02d:%02d:%02d", secs / 3600, (secs % 3600) / 60, secs % 60)
                        .map { if (it.isDigit()) '٠' + (it - '0') else it }.joinToString("")
                    Text(txt, color = Gold, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("على ${fmt(u.nextAt.toLocalTime())}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
        }
    }
}

/** قوس الشمس: الشمس (ولا القمر) كتمشي من الشروق للغروب */
@Composable
private fun SunArc(u: PrayerUi, modifier: Modifier) {
    val rise = u.today.times[Prayer.SUNRISE] ?: LocalTime.of(6, 0)
    val set = u.today.times[Prayer.MAGHRIB] ?: LocalTime.of(18, 0)
    val now = u.now.toLocalTime()
    val day = now.isAfter(rise) && now.isBefore(set)
    val frac = if (day) (now.toSecondOfDay() - rise.toSecondOfDay()).toFloat() / (set.toSecondOfDay() - rise.toSecondOfDay()) else 0.5f
    val t by animateFloatAsState(frac, spring(stiffness = Spring.StiffnessVeryLow), label = "sun")
    val glow = rememberPulse(0.5f, 1f, 1600)
    Canvas(modifier) {
        val cx = size.width / 2
        val baseY = size.height * 0.92f
        val r = size.width * 0.46f
        // القوس
        val path = Path().apply {
            for (k in 0..60) {
                val a = Math.PI * (1 - k / 60.0)
                val x = cx + r * cos(a).toFloat()
                val y = baseY - r * 0.55f * sin(a).toFloat()
                if (k == 0) moveTo(x, y) else lineTo(x, y)
            }
        }
        drawPath(path, Color.White.copy(alpha = 0.18f), style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
        // فـ RTL الشروق على اليمين
        val a = Math.PI * t
        val pos = Offset(cx + r * cos(a).toFloat(), baseY - r * 0.55f * sin(a).toFloat())
        if (day) {
            drawCircle(Gold.copy(alpha = 0.25f * glow), 26.dp.toPx(), pos)
            drawCircle(Color(0xFFFFE27A), 11.dp.toPx(), pos)
        } else {
            val m = Offset(size.width * 0.82f, size.height * 0.2f)
            drawCircle(Color.White.copy(alpha = 0.15f * glow), 22.dp.toPx(), m)
            drawCircle(Color(0xFFF5F3CE), 12.dp.toPx(), m)
            drawCircle(Color(0xFF0F1A3D).copy(alpha = 0.9f), 10.dp.toPx(), m + Offset(6.dp.toPx(), -3.dp.toPx()))
        }
    }
}

@Composable
private fun PrayerRow(index: Int, p: Prayer, time: LocalTime, isNext: Boolean) {
    val glow = if (isNext) rememberPulse(0.3f, 1f, 1200) else 0f
    val bg by animateColorAsState(
        if (isNext) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainer,
        label = "rowBg",
    )
    Row(
        Modifier
            .fillMaxWidth()
            .staggeredEntrance(index)
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(bg)
            .border(if (isNext) 1.5.dp else 0.dp, Gold.copy(alpha = glow), RoundedCornerShape(18.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(p.emoji, fontSize = 22.sp)
        Spacer(Modifier.width(12.dp))
        Text(p.label, fontWeight = if (isNext) FontWeight.ExtraBold else FontWeight.SemiBold, fontSize = 18.sp, modifier = Modifier.weight(1f))
        if (isNext) {
            Text("الجاية", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 8.dp))
        }
        Text(fmt(time), fontWeight = FontWeight.Bold, fontSize = 20.sp, color = if (isNext) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
    }
}

/** البوصلة ديال القبلة (حساس الدوران ديال التلفون) */
@Composable
private fun QiblaCard(u: PrayerUi) {
    val context = LocalContext.current
    var heading by remember { mutableFloatStateOf(0f) }
    var hasSensor by remember { mutableStateOf(true) }
    DisposableEffect(Unit) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (sensor == null) {
            hasSensor = false
            onDispose { }
        } else {
            val rot = FloatArray(9)
            val ori = FloatArray(3)
            val l = object : SensorEventListener {
                override fun onSensorChanged(e: SensorEvent) {
                    SensorManager.getRotationMatrixFromVector(rot, e.values)
                    SensorManager.getOrientation(rot, ori)
                    val az = ((Math.toDegrees(ori[0].toDouble()) + 360) % 360).toFloat()
                    // كنتبعو أقصر دورة باش البوصلة ما تدورش دورة كاملة
                    var d = az - (heading % 360)
                    if (d > 180) d -= 360
                    if (d < -180) d += 360
                    heading += d
                }
                override fun onAccuracyChanged(s: Sensor?, a: Int) {}
            }
            sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
            onDispose { sm.unregisterListener(l) }
        }
    }
    val dial by animateFloatAsState(-heading, spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessLow), label = "dial")
    val qibla = u.qibla.toFloat()
    // واش التلفون مقابل القبلة؟
    val diff = (((qibla - (heading % 360)) % 360) + 540) % 360 - 180
    val aligned = hasSensor && kotlin.math.abs(diff) < 4f
    val ring by animateColorAsState(if (aligned) Color(0xFF10AC84) else Gold, label = "ring")
    val pulse = rememberPulse(0.6f, 1f, 900)

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF0B3D26), Color(0xFF145C3A))))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("🕋 اتجاه القبلة", color = Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(
            "${qibla.toInt().toArabicDigits()}° من الشمال • ${u.distanceKm.toInt().toArabicDigits()} كلم للكعبة",
            color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp,
        )
        Spacer(Modifier.height(12.dp))
        Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().graphicsLayer { rotationZ = if (hasSensor) dial else 0f }) {
                val r = size.minDimension / 2
                drawCircle(Color.White.copy(alpha = 0.06f), r)
                drawCircle(ring.copy(alpha = if (aligned) pulse else 0.8f), r - 3.dp.toPx(), style = Stroke(3.dp.toPx()))
                // علامات الدرجات
                for (k in 0 until 72) {
                    val a = Math.toRadians(k * 5.0 - 90)
                    val len = if (k % 18 == 0) 14.dp.toPx() else if (k % 2 == 0) 8.dp.toPx() else 4.dp.toPx()
                    val o = r - 8.dp.toPx()
                    drawLine(
                        Color.White.copy(alpha = if (k % 18 == 0) 0.9f else 0.35f),
                        Offset(center.x + o * cos(a).toFloat(), center.y + o * sin(a).toFloat()),
                        Offset(center.x + (o - len) * cos(a).toFloat(), center.y + (o - len) * sin(a).toFloat()),
                        strokeWidth = 1.5.dp.toPx(),
                    )
                }
                // الشمال (أحمر)
                val n = Path().apply {
                    moveTo(center.x, center.y - r + 26.dp.toPx())
                    lineTo(center.x - 8.dp.toPx(), center.y - r + 44.dp.toPx())
                    lineTo(center.x + 8.dp.toPx(), center.y - r + 44.dp.toPx())
                    close()
                }
                drawPath(n, Color(0xFFE74C3C))
                // سهم القبلة + الكعبة
                rotate(qibla) {
                    drawLine(Brush.verticalGradient(listOf(Gold, Gold.copy(alpha = 0.1f))), center, Offset(center.x, center.y - r * 0.72f), 6.dp.toPx(), cap = StrokeCap.Round)
                    val k = Offset(center.x, center.y - r * 0.72f)
                    drawCircle(Gold.copy(alpha = 0.3f * pulse), 24.dp.toPx(), k)
                    val s = 13.dp.toPx()
                    drawRect(Color(0xFF1E1E1E), topLeft = Offset(k.x - s, k.y - s), size = androidx.compose.ui.geometry.Size(2 * s, 2 * s))
                    drawRect(Gold, topLeft = Offset(k.x - s, k.y - s * 0.5f), size = androidx.compose.ui.geometry.Size(2 * s, s * 0.35f))
                }
                drawStar(center, 12.dp.toPx(), Gold)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            when {
                !hasSensor -> "التلفون ما فيهش البوصلة: السهم الذهبي كيبين الاتجاه من الشمال (الأحمر)"
                aligned -> "✅ نتا مقابل القبلة"
                else -> "دور التلفون حتى يتلاقى السهم الذهبي مع الفوق"
            },
            color = if (aligned) Color(0xFF7CF0C3) else Color.White, textAlign = TextAlign.Center,
        )
        Text("💡 بعد التلفون على الحديد والمغناطيس، ودير شكل 8 فالهوا إلا كانت البوصلة مخلطة", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}
