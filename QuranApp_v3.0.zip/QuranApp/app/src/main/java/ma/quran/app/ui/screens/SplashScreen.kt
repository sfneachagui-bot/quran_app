package ma.quran.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import ma.quran.app.ui.theme.DeepGreen
import ma.quran.app.ui.theme.Gold
import ma.quran.app.ui.theme.GoldParticles
import ma.quran.app.ui.theme.QuranFont
import ma.quran.app.ui.theme.rememberShimmerBrush
import ma.quran.app.ui.theme.starPath

/**
 * شاشة البداية: النجمة الثمانية كترسم براسها بخط ذهبي، الأشعة كدور،
 * العنوان كيبان بلمعان، والبسملة من بعد. فالأخير كلشي كيتلاشى.
 */
@OptIn(ExperimentalTextApi::class)
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val draw = remember { Animatable(0f) }      // رسم النجمة
    val fill = remember { Animatable(0f) }      // تعمير النجمة
    val title = remember { Animatable(0f) }     // العنوان
    val sub = remember { Animatable(0f) }       // البسملة
    val exit = remember { Animatable(1f) }      // التلاشي فالأخير

    LaunchedEffect(Unit) {
        launch { draw.animateTo(1f, tween(1300, easing = FastOutSlowInEasing)) }
        delay(900)
        launch { fill.animateTo(1f, tween(700)) }
        launch { title.animateTo(1f, spring(dampingRatio = 0.6f, stiffness = 120f)) }
        delay(600)
        sub.animateTo(1f, tween(600))
        delay(900)
        exit.animateTo(0f, tween(450))
        onFinished()
    }

    val t = rememberInfiniteTransition(label = "splash")
    val rays by t.animateFloat(0f, 360f, infiniteRepeatable(tween(20000, easing = LinearEasing)), label = "rays")
    val shimmer = rememberShimmerBrush()

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = exit.value }
            // كنمنعو اللمسات توصل للشاشة اللي تحت
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .background(Brush.radialGradient(listOf(Color(0xFF1C7A4D), DeepGreen, Color(0xFF041A10)))),
        contentAlignment = Alignment.Center,
    ) {
        GoldParticles(Modifier.fillMaxSize(), count = 40)
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(Modifier.size(220.dp)) {
                val r = size.minDimension / 2
                // الأشعة الذهبية
                rotate(rays) {
                    for (k in 0 until 16) {
                        rotate(k * 22.5f) {
                            drawLine(
                                Brush.verticalGradient(listOf(Gold.copy(alpha = 0.35f * draw.value), Color.Transparent), startY = center.y, endY = 0f),
                                Offset(center.x, center.y - r * 0.55f),
                                Offset(center.x, center.y - r),
                                strokeWidth = (if (k % 2 == 0) 3f else 1.5f).dp.toPx(),
                                cap = StrokeCap.Round,
                            )
                        }
                    }
                }
                // هالة
                drawCircle(
                    Brush.radialGradient(listOf(Gold.copy(alpha = 0.35f * fill.value), Color.Transparent), center, r * 0.75f),
                    r * 0.75f,
                )
                // النجمة كترسم شوية بشوية
                val star = starPath(center, r * 0.55f)
                val pm = PathMeasure().apply { setPath(star, false) }
                val seg = Path()
                pm.getSegment(0f, pm.length * draw.value, seg, true)
                rotate(-45f * (1f - draw.value)) {
                    drawPath(star, Gold.copy(alpha = 0.9f * fill.value))
                    drawPath(seg, Color(0xFFFFF4C2), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
                    val inner = starPath(center, r * 0.34f)
                    drawPath(inner, DeepGreen.copy(alpha = fill.value))
                    drawPath(inner, Gold.copy(alpha = fill.value), style = Stroke(1.5.dp.toPx()))
                }
                drawCircle(Gold.copy(alpha = fill.value), r * 0.08f)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "القرآن الكريم",
                fontFamily = QuranFont,
                fontSize = 46.sp,
                style = TextStyle(brush = shimmer),
                modifier = Modifier.graphicsLayer {
                    alpha = title.value
                    val s = 0.7f + 0.3f * title.value
                    scaleX = s; scaleY = s
                    translationY = (1f - title.value) * 40f
                },
            )
            Text(
                "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ",
                fontFamily = QuranFont,
                fontSize = 22.sp,
                color = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.graphicsLayer { alpha = sub.value; translationY = (1f - sub.value) * 20f },
            )
        }
    }
}
