package ma.quran.app.ui.theme

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/* ─────────────────────────  الحركة (Motion)  ─────────────────────────
 * كل التأثيرات ديال النسخة 2.0 هنا: خلفيات متحركة، غبار ذهبي، لمعان،
 * حلقة التقدم، أعمدة الإحصائيات، الإكولايزر، ودخول العناصر بالتتابع.
 */

/** زخرفة النجوم كتتحرك بشوية (كتزلق وكدور) */
@Composable
fun AnimatedStarPattern(
    modifier: Modifier = Modifier,
    color: Color = Color.White.copy(alpha = 0.08f),
    cell: Dp = 46.dp,
) {
    val t = rememberInfiniteTransition(label = "pattern")
    val shift by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(14000, easing = LinearEasing)),
        label = "shift",
    )
    val spin by t.animateFloat(
        0f, 45f,
        infiniteRepeatable(tween(9000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "spin",
    )
    Canvas(modifier) {
        val c = cell.toPx()
        val dx = shift * c
        val dy = shift * c * 0.87f * 2
        var row = -2
        var y = -2 * c * 0.87f + dy
        while (y < size.height + c) {
            var x = (if (row % 2 == 0) 0f else c / 2) - c + dx
            while (x < size.width + c) {
                val o = Offset(x, y)
                rotate(spin, pivot = o) { drawStar(o, c * 0.32f, color, stroke = 1.2.dp.toPx()) }
                x += c
            }
            y += c * 0.87f
            row++
        }
    }
}

private class Particle(val x: Float, val speed: Float, val size: Float, val phase: Float, val drift: Float)

/** غبار ذهبي كيطلع للفوق بشوية ويلمع */
@Composable
fun GoldParticles(modifier: Modifier = Modifier, count: Int = 26, color: Color = Gold) {
    val particles = remember(count) {
        val r = Random(7)
        List(count) { Particle(r.nextFloat(), 0.4f + r.nextFloat() * 0.8f, 1.2f + r.nextFloat() * 2.6f, r.nextFloat(), r.nextFloat() * 2 - 1) }
    }
    val t = rememberInfiniteTransition(label = "particles")
    val time by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(12000, easing = LinearEasing)),
        label = "time",
    )
    Canvas(modifier) {
        particles.forEach { p ->
            val prog = (time * p.speed + p.phase) % 1f
            val y = size.height * (1f - prog)
            val x = size.width * p.x + sin((prog * 2 * PI + p.phase * 6).toFloat()) * 18.dp.toPx() * p.drift
            // كيبان فالوسط وكيختفي فالطرفين
            val alpha = sin((prog * PI).toFloat()).coerceIn(0f, 1f)
            val twinkle = 0.6f + 0.4f * sin((time * 40 + p.phase * 10).toFloat())
            val r = p.size.dp.toPx()
            drawCircle(color.copy(alpha = 0.25f * alpha * twinkle), r * 3f, Offset(x, y))
            drawCircle(color.copy(alpha = 0.9f * alpha * twinkle), r, Offset(x, y))
        }
    }
}

/** فرشاة ذهبية كيدوز فيها ضوء (للعناوين) */
@Composable
fun rememberShimmerBrush(base: Color = Gold, highlight: Color = Color(0xFFFFF4C2), widthPx: Float = 600f): Brush {
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(
        -widthPx, widthPx * 2,
        infiniteRepeatable(tween(2800, delayMillis = 900, easing = LinearEasing)),
        label = "x",
    )
    return Brush.linearGradient(
        listOf(base, base, highlight, base, base),
        start = Offset(x - widthPx / 2, 0f),
        end = Offset(x + widthPx / 2, 60f),
    )
}

/** ضغطة = الكارت كيصغر شوية بنعومة */
fun Modifier.pressScale(interaction: MutableInteractionSource, pressed: Float = 0.96f): Modifier = composed {
    val isPressed by interaction.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (isPressed) pressed else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press",
    )
    graphicsLayer { scaleX = s; scaleY = s }
}

/** العناصر الأولى ديال اللائحة كيدخلو واحد بواحد (fade + slide) */
fun Modifier.staggeredEntrance(index: Int, maxAnimated: Int = 14): Modifier = composed {
    if (index >= maxAnimated) return@composed this
    val alpha = remember { Animatable(0f) }
    val offset = remember { Animatable(40f) }
    LaunchedEffect(Unit) {
        delay(index * 45L)
        launch { alpha.animateTo(1f, tween(420)) }
        offset.animateTo(0f, spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessLow))
    }
    graphicsLayer {
        this.alpha = alpha.value
        translationY = offset.value * density
    }
}

/** حلقة التقدم بتدرج ذهبي، كترسم راسها بالحركة */
@Composable
fun ProgressRing(
    progress: Float,
    modifier: Modifier = Modifier,
    stroke: Dp = 9.dp,
    track: Color = Color.White.copy(alpha = 0.15f),
    colors: List<Color> = listOf(Color(0xFFF7E08B), Gold, Color(0xFFB8860B), Color(0xFFF7E08B)),
    content: @Composable () -> Unit = {},
) {
    val anim = remember { Animatable(0f) }
    LaunchedEffect(progress) { anim.animateTo(progress.coerceIn(0f, 1f), tween(1400, easing = FastOutSlowInEasing)) }
    val t = rememberInfiniteTransition(label = "ring")
    val glow by t.animateFloat(0.35f, 0.8f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "glow")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = stroke.toPx()
            val d = size.minDimension - sw
            val tl = Offset((size.width - d) / 2, (size.height - d) / 2)
            drawArc(track, 0f, 360f, false, tl, Size(d, d), style = Stroke(sw))
            val sweep = 360f * anim.value
            if (sweep > 0f) {
                rotate(-90f) {
                    drawArc(Brush.sweepGradient(colors), 0f, sweep, false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
                }
                // نقطة مضيئة فراس الحلقة
                val a = Math.toRadians((sweep - 90f).toDouble())
                val c = Offset(size.width / 2 + (d / 2) * cos(a).toFloat(), size.height / 2 + (d / 2) * sin(a).toFloat())
                drawCircle(Gold.copy(alpha = glow * 0.5f), sw * 1.3f, c)
                drawCircle(Color(0xFFFFF4C2), sw * 0.45f, c)
            }
        }
        content()
    }
}

/** أعمدة الإحصائيات (كيطلعو من التحت بالتتابع) */
@Composable
fun AnimatedBarChart(
    values: List<Int>,
    labels: List<String>,
    modifier: Modifier = Modifier,
    barColor: Color = Gold,
    todayColor: Color = Color(0xFFFFF4C2),
    labelColor: Color = Color.White.copy(alpha = 0.7f),
    height: Dp = 86.dp,
) {
    val max = (values.maxOrNull() ?: 0).coerceAtLeast(1)
    Row(modifier, verticalAlignment = Alignment.Bottom) {
        values.forEachIndexed { i, v ->
            val anim = remember { Animatable(0f) }
            LaunchedEffect(v) {
                delay(250L + i * 90L)
                anim.animateTo(v.toFloat() / max, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow))
            }
            androidx.compose.foundation.layout.Column(
                Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(Modifier.height(height).width(18.dp), contentAlignment = Alignment.BottomCenter) {
                    // الخلفية ديال العمود
                    Box(
                        Modifier
                            .fillMaxHeight()
                            .width(18.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(Color.White.copy(alpha = 0.08f)),
                    )
                    val last = i == values.lastIndex
                    Box(
                        Modifier
                            .fillMaxHeight(anim.value.coerceIn(0f, 1f).let { if (v > 0) it.coerceAtLeast(0.06f) else 0f })
                            .width(18.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(
                                Brush.verticalGradient(
                                    if (last) listOf(todayColor, barColor) else listOf(barColor, barColor.copy(alpha = 0.55f)),
                                ),
                            ),
                    )
                }
                Spacer(Modifier.height(4.dp))
                androidx.compose.material3.Text(
                    labels.getOrElse(i) { "" },
                    color = if (i == values.lastIndex) todayColor else labelColor,
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                )
            }
        }
    }
}

/** إكولايزر صغير كيتحرك ملي كيكون الصوت خدام */
@Composable
fun AudioBars(playing: Boolean, modifier: Modifier = Modifier, color: Color = Gold, bars: Int = 4) {
    val t = rememberInfiniteTransition(label = "eq")
    Row(modifier.height(18.dp), verticalAlignment = Alignment.Bottom) {
        repeat(bars) { i ->
            val h by t.animateFloat(
                0.25f, 1f,
                infiniteRepeatable(tween(380 + i * 110, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                label = "bar$i",
            )
            val target by animateFloatAsState(if (playing) h else 0.2f, tween(200), label = "barH$i")
            Box(
                Modifier
                    .width(3.dp)
                    .fillMaxHeight(target)
                    .clip(RoundedCornerShape(2.dp))
                    .background(color),
            )
            if (i < bars - 1) Spacer(Modifier.width(2.dp))
        }
    }
}

/** نجمة ذهبية كدور وكتنبض (للشعار والتحميل) */
@Composable
fun SpinningStar(modifier: Modifier = Modifier, size: Dp = 56.dp, color: Color = Gold) {
    val t = rememberInfiniteTransition(label = "star")
    val a by t.animateFloat(0f, 360f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "a")
    val p by t.animateFloat(0.9f, 1.05f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "p")
    Canvas(modifier.size(size)) {
        val r = this.size.minDimension / 2 * p
        drawCircle(color.copy(alpha = 0.15f), r * 1.2f)
        rotate(a) { drawStar(center, r * 0.95f, color, stroke = 2.dp.toPx()) }
        rotate(-a * 1.5f) { drawStar(center, r * 0.6f, color.copy(alpha = 0.8f)) }
    }
}

/** ضوء كينبض (هالة) ورا آية كتتقرا */
@Composable
fun rememberPulse(min: Float = 0.35f, max: Float = 1f, millis: Int = 1100): Float {
    val t = rememberInfiniteTransition(label = "pulse")
    val v by t.animateFloat(min, max, infiniteRepeatable(tween(millis, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "v")
    return v
}
