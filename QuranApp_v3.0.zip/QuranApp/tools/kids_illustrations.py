"""Generates kid-friendly flat illustrations (wudu & salah steps).
Every shape is a <path> so the same data renders as SVG (preview) and
Android VectorDrawable XML. Character is faceless (common in Islamic kids apps).
"""
import math, os, sys

W = H = 240
OUT = sys.argv[1] if len(sys.argv) > 1 else "."

SKIN = "#F2C29B"; SKIN_D = "#DFA47A"
TUNIC = "#2E9E6B"; TUNIC_D = "#227A52"
CAP = "#FFFFFF"; CAP_LINE = "#D8E3DD"
WATER = "#4FB3FF"; WATER_L = "#B9E2FF"
GOLD = "#F6B93B"; RUG = "#C0392B"; RUG_L = "#E8A33D"
TAP = "#9AA7B4"; TAP_D = "#6F7D8B"
WHITE = "#FFFFFF"; INK = "#2D3436"


def circle(cx, cy, r):
    return f"M{cx - r:.1f},{cy:.1f}a{r:.1f},{r:.1f} 0 1,0 {2 * r:.1f},0a{r:.1f},{r:.1f} 0 1,0 {-2 * r:.1f},0Z"


def ellipse(cx, cy, rx, ry):
    return f"M{cx - rx:.1f},{cy:.1f}a{rx:.1f},{ry:.1f} 0 1,0 {2 * rx:.1f},0a{rx:.1f},{ry:.1f} 0 1,0 {-2 * rx:.1f},0Z"


def rrect(x, y, w, h, r):
    return (f"M{x + r},{y}h{w - 2 * r}a{r},{r} 0 0,1 {r},{r}v{h - 2 * r}a{r},{r} 0 0,1 {-r},{r}"
            f"h{-(w - 2 * r)}a{r},{r} 0 0,1 {-r},{-r}v{-(h - 2 * r)}a{r},{r} 0 0,1 {r},{-r}Z")


def poly(*pts):
    return "M" + "L".join(f"{x:.1f},{y:.1f}" for x, y in pts)


def drop(cx, cy, s):
    """water drop pointing up"""
    return (f"M{cx:.1f},{cy - 1.6 * s:.1f}C{cx + 0.2 * s:.1f},{cy - 1.0 * s:.1f} {cx + s:.1f},{cy - 0.3 * s:.1f} {cx + s:.1f},{cy + 0.3 * s:.1f}"
            f"A{s:.1f},{s:.1f} 0 1,1 {cx - s:.1f},{cy + 0.3 * s:.1f}C{cx - s:.1f},{cy - 0.3 * s:.1f} {cx - 0.2 * s:.1f},{cy - 1.0 * s:.1f} {cx:.1f},{cy - 1.6 * s:.1f}Z")


def star(cx, cy, r, points=4, inner=0.4, rot=-90):
    pts = []
    for k in range(points * 2):
        a = math.radians(rot + k * 180 / points)
        rr = r if k % 2 == 0 else r * inner
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    return poly(*pts) + "Z"


def heart(cx, cy, s):
    return (f"M{cx:.1f},{cy + s:.1f}C{cx - 1.4 * s:.1f},{cy:.1f} {cx - 1.1 * s:.1f},{cy - 1.1 * s:.1f} {cx:.1f},{cy - 0.45 * s:.1f}"
            f"C{cx + 1.1 * s:.1f},{cy - 1.1 * s:.1f} {cx + 1.4 * s:.1f},{cy:.1f} {cx:.1f},{cy + s:.1f}Z")


def arc_arrow(cx, cy, r, a0, a1, head=7):
    """curved arrow from angle a0 to a1 (degrees), returns (stroke path, head fill path)"""
    p0 = (cx + r * math.cos(math.radians(a0)), cy + r * math.sin(math.radians(a0)))
    p1 = (cx + r * math.cos(math.radians(a1)), cy + r * math.sin(math.radians(a1)))
    large = 1 if abs(a1 - a0) > 180 else 0
    sweep = 1 if a1 > a0 else 0
    line = f"M{p0[0]:.1f},{p0[1]:.1f}A{r},{r} 0 {large},{sweep} {p1[0]:.1f},{p1[1]:.1f}"
    # tangent direction at end
    t = math.radians(a1 + (90 if sweep else -90))
    tx, ty = math.cos(t), math.sin(t)
    nx, ny = -ty, tx
    tip = (p1[0] + tx * head, p1[1] + ty * head)
    b1 = (p1[0] + nx * head * 0.7, p1[1] + ny * head * 0.7)
    b2 = (p1[0] - nx * head * 0.7, p1[1] - ny * head * 0.7)
    return line, poly(tip, b1, b2) + "Z"


def arrow(x0, y0, x1, y1, head=8):
    dx, dy = x1 - x0, y1 - y0
    L = math.hypot(dx, dy); ux, uy = dx / L, dy / L
    nx, ny = -uy, ux
    bx, by = x1 - ux * head, y1 - uy * head
    return poly((x0, y0), (bx, by)), poly((x1, y1), (bx + nx * head * 0.7, by + ny * head * 0.7), (bx - nx * head * 0.7, by - ny * head * 0.7)) + "Z"


class Pic:
    def __init__(self, name, bg):
        self.name = name
        self.items = []  # (d, fill, stroke, width)
        self.fill(f"M0,0H{W}V{H}H0Z", bg[0])
        self.fill(circle(W * 0.78, H * 0.2, 58), bg[1])
        self.fill(circle(W * 0.12, H * 0.85, 46), bg[1])

    def fill(self, d, color):
        self.items.append((d, color, None, 0)); return self

    def line(self, d, color, w):
        self.items.append((d, None, color, w)); return self

    def svg(self):
        out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">']
        for d, f, s, w in self.items:
            if f:
                out.append(f'<path d="{d}" fill="{f}"/>')
            else:
                out.append(f'<path d="{d}" fill="none" stroke="{s}" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round"/>')
        out.append("</svg>")
        return "\n".join(out)

    @staticmethod
    def argb(c):
        # SVG: #RRGGBBAA  ->  Android: #AARRGGBB
        return "#" + c[7:9] + c[1:7] if c and len(c) == 9 else c

    def vector(self):
        out = ['<?xml version="1.0" encoding="utf-8"?>',
               '<vector xmlns:android="http://schemas.android.com/apk/res/android"',
               f'    android:width="{W}dp" android:height="{H}dp"',
               f'    android:viewportWidth="{W}" android:viewportHeight="{H}">']
        for d, f, s, w in self.items:
            if f:
                out.append(f'    <path android:fillColor="{self.argb(f)}" android:pathData="{d}"/>')
            else:
                out.append(f'    <path android:strokeColor="{s}" android:strokeWidth="{w}" android:strokeLineCap="round"'
                           f' android:strokeLineJoin="round" android:fillColor="#00000000" android:pathData="{d}"/>')
        out.append("</vector>")
        return "\n".join(out)

    # ---------- reusable bits ----------
    def sparkles(self, pts, color=GOLD):
        for x, y, r in pts:
            self.fill(star(x, y, r), color)
        return self

    def drops(self, pts):
        for x, y, s in pts:
            self.fill(drop(x, y, s), WATER)
            self.fill(circle(x - s * 0.35, y + s * 0.1, s * 0.25), WATER_L)
        return self

    def floor(self, cx=120, y=206, rx=78):
        return self.fill(ellipse(cx, y, rx, 9), "#00000018")

    def rug(self, x0=34, x1=206, y=200):
        self.fill(rrect(x0, y - 6, x1 - x0, 16, 4), RUG)
        self.fill(rrect(x0 + 6, y - 2, x1 - x0 - 12, 8, 2), RUG_L)
        for i in range(6):
            cx = x0 + 18 + i * (x1 - x0 - 36) / 5
            self.fill(star(cx, y + 2, 4, 4, 0.45, -45), RUG)
        return self

    def head(self, cx, cy, r=17, tilt=0.0):
        """faceless head with a kufi cap; tilt in degrees (cap rotates)"""
        self.fill(circle(cx, cy, r), SKIN)
        a = math.radians(tilt)
        # cap = upper half disk rotated by tilt
        def pt(ang, rr):
            return (cx + rr * math.cos(ang + a), cy + rr * math.sin(ang + a))
        p0 = pt(math.pi, r + 1); p1 = pt(0, r + 1)
        self.fill(f"M{p0[0]:.1f},{p0[1]:.1f}A{r + 1},{r + 1} 0 0,1 {p1[0]:.1f},{p1[1]:.1f}Z", CAP)
        b0 = pt(math.pi * 0.98, r + 1); b1 = pt(0.02, r + 1)
        self.line(f"M{b0[0]:.1f},{b0[1]:.1f}L{b1[0]:.1f},{b1[1]:.1f}", CAP_LINE, 3)
        return self

    def limb(self, pts, w, color):
        return self.line(poly(*pts), color, w)

    def hand(self, x, y, r=6.5):
        return self.fill(circle(x, y, r), SKIN)

    def foot(self, x, y, dirx=-1):
        return self.fill(ellipse(x + dirx * 4, y, 9, 5), SKIN_D)

    def body(self, neck, hip, w=30):
        return self.line(poly(neck, hip), TUNIC, w)


def save(p):
    with open(os.path.join(OUT, "svg", p.name + ".svg"), "w") as f:
        f.write(p.svg())
    with open(os.path.join(OUT, "drawable", "kid_" + p.name + ".xml"), "w") as f:
        f.write(p.vector())


BLUE_BG = ("#E3F3FF", "#CDE9FF")
ORANGE_BG = ("#FFF3E0", "#FFE2BA")

# ======================= standard figures ===============================

def standing(p, arms="down", cx=120):
    """front view standing child. arms: down | up (takbir) | dua | chest"""
    neck = (cx, 92); hip = (cx, 150)
    p.floor(cx)
    # legs (tunic to ankles)
    p.limb([(cx - 9, 148), (cx - 11, 196)], 16, TUNIC_D)
    p.limb([(cx + 9, 148), (cx + 11, 196)], 16, TUNIC_D)
    p.foot(cx - 13, 200, -1); p.foot(cx + 13, 200, 1)
    p.body(neck, hip, 38)
    p.fill(rrect(cx - 24, 96, 48, 64, 18), TUNIC)
    if arms == "down":
        for s in (-1, 1):
            p.limb([(cx + s * 21, 104), (cx + s * 27, 130), (cx + s * 27, 152)], 11, TUNIC_D)
            p.hand(cx + s * 27, 156)
    elif arms == "up":
        for s in (-1, 1):
            p.limb([(cx + s * 21, 104), (cx + s * 36, 98), (cx + s * 32, 76)], 11, TUNIC_D)
            p.hand(cx + s * 32, 70, 7.5)
    elif arms == "dua":
        for s in (-1, 1):
            p.limb([(cx + s * 21, 104), (cx + s * 30, 128), (cx + s * 14, 120)], 11, TUNIC_D)
            p.fill(ellipse(cx + s * 9, 114, 8, 10), SKIN)
    elif arms == "chest":
        for s in (-1, 1):
            p.limb([(cx + s * 21, 104), (cx + s * 26, 126), (cx + s * 6, 124)], 11, TUNIC_D)
        p.fill(ellipse(cx, 122, 12, 7), SKIN)
    p.head(cx, 74, 19)
    return p


def side_standing(p, cx=120, hands="sides"):
    """side view, facing left"""
    p.rug()
    p.limb([(cx + 2, 150), (cx + 2, 196)], 18, TUNIC_D)
    p.foot(cx - 2, 198, -1)
    p.fill(rrect(cx - 16, 96, 34, 66, 15), TUNIC)
    if hands == "sides":
        p.limb([(cx + 2, 106), (cx - 2, 132), (cx - 2, 152)], 11, TUNIC_D)
        p.hand(cx - 2, 156)
    p.head(cx - 1, 74, 19)
    return p


def bowing(p):
    """ruku: back flat, hands on knees, facing left"""
    p.rug()
    hip = (150, 120)
    p.limb([(152, 124), (150, 196)], 18, TUNIC_D)
    p.foot(146, 198, -1)
    p.line(poly((150, 116), (92, 116)), TUNIC, 34)
    p.limb([(98, 120), (124, 146), (146, 152)], 11, TUNIC_D)
    p.hand(148, 154)
    p.head(70, 116, 18, tilt=-90)
    return p


def prostrating(p):
    """sujud facing left: forehead, hands, knees, toes on ground"""
    p.rug()
    # shin on ground
    p.limb([(170, 190), (124, 192)], 16, TUNIC_D)
    p.fill(ellipse(180, 194, 8, 5), SKIN_D)
    # thigh up to hip
    p.limb([(128, 186), (150, 150)], 18, TUNIC_D)
    # back from hip down to shoulders
    p.line(poly((150, 148), (96, 166)), TUNIC, 32)
    # arm to hands on ground
    p.limb([(100, 170), (84, 192)], 11, TUNIC_D)
    p.fill(ellipse(80, 195, 9, 5), SKIN)
    p.head(70, 178, 17, tilt=-150)
    return p


def sitting(p, finger=False, turn=False):
    """julus facing left, sitting on folded legs"""
    p.rug()
    p.limb([(150, 192), (104, 192)], 18, TUNIC_D)
    p.fill(ellipse(160, 194, 10, 5), SKIN_D)
    p.fill(rrect(108, 108, 40, 76, 16), TUNIC)
    p.limb([(118, 120), (110, 150), (92, 176)], 11, TUNIC_D)
    p.hand(90, 178)
    if finger:
        p.line(poly((88, 176), (80, 166)), SKIN, 5)
    if turn:
        p.head(126, 86, 19, tilt=0)
        l, h = arc_arrow(126, 86, 32, 200, 310)
        p.line(l, GOLD, 5).fill(h, GOLD)
    else:
        p.head(124, 86, 19)
    return p


# ======================= WUDU ===========================================

def tap(p, x, y):
    p.fill(rrect(x - 50, y - 12, 62, 16, 7), TAP)
    p.fill(rrect(x - 6, y - 12, 16, 30, 6), TAP)
    p.fill(rrect(x - 40, y - 22, 14, 12, 4), TAP_D)
    return p


def stream(p, x, y0, y1, w=12):
    p.line(poly((x, y0), (x, y1)), WATER, w)
    p.line(poly((x - 2, y0 + 4), (x - 2, y1 - 6)), WATER_L, 3)
    return p


def make_all():
    pics = []

    p = Pic("wudu_01_niyyah", BLUE_BG); standing(p, "chest")
    p.fill(ellipse(176, 46, 34, 26), WHITE); p.fill(circle(150, 76, 7), WHITE); p.fill(circle(140, 90, 4), WHITE)
    p.fill(heart(166, 46, 12), "#FF6B9D"); p.drops([(190, 46, 7)]); pics.append(p)

    p = Pic("wudu_02_bismillah", BLUE_BG); standing(p, "down")
    p.fill(rrect(140, 24, 80, 46, 18), WHITE); p.fill(poly((150, 66), (140, 84), (166, 68)) + "Z", WHITE)
    for i, x in enumerate((158, 180, 202)):
        p.fill(star(x, 47, 9 if i == 1 else 7), GOLD)
    pics.append(p)

    p = Pic("wudu_03_hands", BLUE_BG); tap(p, 150, 52); stream(p, 152, 70, 118)
    p.fill(ellipse(132, 140, 30, 16), SKIN); p.fill(ellipse(168, 140, 30, 16), SKIN)
    p.limb([(102, 150), (70, 176)], 22, TUNIC_D); p.limb([(198, 150), (226, 176)], 22, TUNIC_D)
    for x in (118, 128, 138, 162, 172, 182):
        p.line(poly((x, 132), (x + (2 if x < 150 else -2), 148)), SKIN_D, 2.5)
    p.drops([(116, 172, 6), (150, 180, 7), (186, 170, 6), (132, 112, 5)])
    p.sparkles([(60, 70, 8), (206, 108, 6)]); pics.append(p)

    def face_closeup(p, highlight):
        p.fill(circle(120, 112, 62), SKIN)
        p.fill(f"M56,112A64,64 0 0,1 184,112Z", CAP); p.line("M58,110L182,110", CAP_LINE, 5)
        p.fill(ellipse(58, 130, 9, 14), SKIN_D); p.fill(ellipse(182, 130, 9, 14), SKIN_D)
        if highlight == "mouth":
            p.fill(ellipse(120, 152, 16, 8), "#C96B6B")
        if highlight == "nose":
            p.fill(ellipse(120, 132, 8, 11), SKIN_D)
        return p

    p = Pic("wudu_04_mouth", BLUE_BG); face_closeup(p, "mouth")
    p.fill(ellipse(150, 192, 30, 16), SKIN); p.fill(ellipse(150, 186, 20, 7), WATER)
    p.limb([(174, 202), (214, 226)], 20, TUNIC_D)
    l, h = arc_arrow(120, 152, 30, 200, 340); p.line(l, WATER, 5).fill(h, WATER)
    p.drops([(96, 190, 6)]); pics.append(p)

    p = Pic("wudu_05_nose", BLUE_BG); face_closeup(p, "nose")
    p.fill(ellipse(134, 176, 26, 14), SKIN); p.fill(ellipse(134, 170, 16, 6), WATER)
    p.limb([(156, 186), (200, 214)], 20, TUNIC_D)
    a, h = arrow(120, 160, 120, 146, 7); p.line(a, WATER, 5).fill(h, WATER)
    p.drops([(80, 176, 6)]); pics.append(p)

    p = Pic("wudu_06_face", BLUE_BG); face_closeup(p, "")
    p.fill(ellipse(66, 150, 16, 30), SKIN); p.fill(ellipse(174, 150, 16, 30), SKIN)
    p.limb([(60, 180), (40, 226)], 20, TUNIC_D); p.limb([(180, 180), (200, 226)], 20, TUNIC_D)
    p.drops([(98, 132, 6), (142, 140, 7), (120, 168, 6), (88, 160, 5), (152, 170, 5)])
    p.sparkles([(26, 60, 8), (214, 74, 7)]); pics.append(p)

    p = Pic("wudu_07_arms", BLUE_BG)
    p.limb([(40, 150), (196, 150)], 30, SKIN)
    p.fill(circle(36, 150, 18), SKIN)
    p.limb([(196, 150), (232, 150)], 34, TUNIC_D)
    p.fill(circle(192, 150, 9), SKIN_D)  # elbow
    a, h = arrow(46, 112, 186, 112, 10); p.line(a, GOLD, 6).fill(h, GOLD)
    p.line(poly((192, 100), (192, 124)), GOLD, 4)
    p.drops([(70, 182, 7), (110, 186, 6), (150, 182, 7), (90, 124, 5)]); pics.append(p)

    p = Pic("wudu_08_head", BLUE_BG)
    p.fill(circle(120, 132, 60), SKIN)
    p.fill(circle(120, 126, 58), "#4A3B33")  # hair seen from above-front
    p.fill(ellipse(96, 86, 24, 13), SKIN); p.fill(ellipse(144, 86, 24, 13), SKIN)
    p.limb([(76, 90), (40, 70)], 18, TUNIC_D); p.limb([(164, 90), (200, 70)], 18, TUNIC_D)
    l, h = arc_arrow(120, 140, 40, 250, 110); p.line(l, GOLD, 6).fill(h, GOLD)
    p.drops([(60, 190, 6), (180, 192, 6)]); pics.append(p)

    p = Pic("wudu_09_ears", BLUE_BG)
    p.fill(circle(120, 122, 56), SKIN)
    p.fill("M64,122A56,56 0 0,1 176,122Z", CAP); p.line("M66,120L174,120", CAP_LINE, 5)
    for s in (-1, 1):
        x = 120 + s * 60
        p.fill(ellipse(x, 136, 13, 20), SKIN_D); p.fill(ellipse(x, 136, 6, 11), SKIN)
        p.line(poly((x + s * 22, 190), (x + s * 2, 148)), SKIN, 7)
        p.limb([(x + s * 24, 196), (x + s * 32, 230)], 20, TUNIC_D)
    p.sparkles([(40, 76, 7), (200, 76, 7)]); p.drops([(120, 196, 6)]); pics.append(p)

    p = Pic("wudu_10_feet", BLUE_BG); tap(p, 150, 46); stream(p, 152, 64, 124)
    p.fill("M70,150Q72,122 108,128L178,134Q206,138 204,156Q202,172 176,170L92,168Q68,166 70,150Z", SKIN)
    for i in range(5):
        p.fill(circle(196 - i * 1.5, 146 + i * 5.2, 5 - i * 0.4), SKIN_D)
    p.limb([(76, 140), (46, 96)], 26, TUNIC_D)
    p.drops([(120, 188, 7), (160, 186, 6), (190, 182, 5), (140, 120, 5)])
    a, h = arrow(100, 206, 176, 206, 8); p.line(a, GOLD, 5).fill(h, GOLD); pics.append(p)

    p = Pic("wudu_11_dua", BLUE_BG); standing(p, "dua")
    p.sparkles([(56, 54, 10), (186, 48, 12), (204, 98, 7), (40, 110, 6)])
    p.fill(circle(120, 30, 10), GOLD).fill(circle(124, 27, 9), BLUE_BG[0]); pics.append(p)

    # ======================= SALAH ======================================
    p = Pic("salah_01_wudu", ORANGE_BG); standing(p, "down")
    p.drops([(56, 70, 12), (186, 60, 10), (200, 120, 7), (40, 130, 7)])
    p.sparkles([(170, 30, 7)]); pics.append(p)

    p = Pic("salah_02_qibla", ORANGE_BG)
    p.fill(circle(120, 120, 74), WHITE); p.line(circle(120, 120, 74), "#E0C9A6", 6)
    for k in range(8):
        a = math.radians(k * 45)
        p.fill(circle(120 + 62 * math.cos(a), 120 + 62 * math.sin(a), 3), "#C9B08A")
    p.fill(poly((120, 62), (132, 120), (120, 178), (108, 120)) + "Z", "#E0C9A6")
    p.fill(poly((120, 62), (132, 120), (108, 120)) + "Z", "#E74C3C")
    p.fill(rrect(96, 36, 48, 44, 4), INK); p.fill(rrect(96, 46, 48, 7, 1), GOLD)
    p.fill(circle(120, 120, 7), INK)
    p.sparkles([(46, 46, 8), (200, 190, 7)]); pics.append(p)

    p = Pic("salah_03_niyyah", ORANGE_BG); standing(p, "down")
    p.fill(ellipse(176, 46, 34, 26), WHITE); p.fill(circle(150, 76, 7), WHITE); p.fill(circle(140, 90, 4), WHITE)
    p.fill(heart(176, 46, 13), "#FF6B9D"); pics.append(p)

    p = Pic("salah_04_takbir", ORANGE_BG); standing(p, "up")
    p.sparkles([(48, 52, 9), (192, 52, 9), (120, 24, 7)]); pics.append(p)

    p = Pic("salah_05_qiyam", ORANGE_BG); side_standing(p)
    p.fill(rrect(150, 36, 62, 46, 10), WHITE); p.fill(rrect(158, 44, 22, 30, 3), "#2E9E6B"); p.fill(rrect(182, 44, 22, 30, 3), "#2E9E6B")
    p.line("M181,44L181,74", GOLD, 2); pics.append(p)

    p = Pic("salah_06_ruku", ORANGE_BG); bowing(p); pics.append(p)
    p = Pic("salah_07_itidal", ORANGE_BG); side_standing(p)
    a, h = arrow(170, 150, 170, 96, 9); p.line(a, GOLD, 6).fill(h, GOLD); pics.append(p)
    p = Pic("salah_08_sujud", ORANGE_BG); prostrating(p); p.sparkles([(60, 140, 7)]); pics.append(p)
    p = Pic("salah_09_julus", ORANGE_BG); sitting(p); pics.append(p)
    p = Pic("salah_10_sujud2", ORANGE_BG); prostrating(p)
    p.fill(circle(180, 60, 22), GOLD); p.fill(poly((170, 60), (178, 68), (192, 52)), GOLD)
    p.line(poly((170, 60), (178, 68), (192, 52)), WHITE, 5); pics.append(p)
    p = Pic("salah_11_tashahhud", ORANGE_BG); sitting(p, finger=True); p.sparkles([(70, 140, 7)]); pics.append(p)
    p = Pic("salah_12_salawat", ORANGE_BG); sitting(p)
    p.fill(heart(180, 56, 16), "#FF6B9D"); p.sparkles([(150, 36, 7), (210, 90, 6), (60, 60, 8)]); pics.append(p)
    p = Pic("salah_13_salam", ORANGE_BG); sitting(p, turn=True); p.sparkles([(60, 50, 8), (196, 40, 7)]); pics.append(p)
    return pics


if __name__ == "__main__":
    os.makedirs(os.path.join(OUT, "svg"), exist_ok=True)
    os.makedirs(os.path.join(OUT, "drawable"), exist_ok=True)
    pics = make_all()
    for p in pics:
        save(p)
    with open(os.path.join(OUT, "preview.html"), "w") as f:
        f.write('<html><body style="margin:0;background:#888;display:flex;flex-wrap:wrap;gap:8px;padding:8px;width:1280px">')
        for p in pics:
            f.write(f'<div style="text-align:center;font:11px sans-serif"><div style="border-radius:28px;overflow:hidden;width:240px;height:240px">{p.svg()}</div><br>{p.name}</div>')
        f.write("</body></html>")
    print(len(pics), "illustrations")
