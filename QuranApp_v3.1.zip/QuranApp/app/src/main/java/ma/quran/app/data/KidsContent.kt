package ma.quran.app.data

import androidx.annotation.DrawableRes
import ma.quran.app.R

/** خطوة فدرس مصور (الوضوء ولا الصلاة) */
data class LessonStep(
    val emoji: String,
    val title: String,
    val text: String,
    /** شي ذكر كيتقال فهاد الخطوة (اختياري) */
    val say: String? = null,
    val times: String? = null,
    /** رسم توضيحي للخطوة (res/drawable/kid_*.xml) */
    @DrawableRes val image: Int? = null,
)

data class Lesson(
    val id: String,
    val title: String,
    val emoji: String,
    val intro: String,
    val steps: List<LessonStep>,
    val note: String? = null,
    /** صورة الغلاف (المقدمة وكارت ركن الأطفال) */
    @DrawableRes val cover: Int? = null,
)

/** كنزيدو الرسوم للخطوات بالترتيب */
private fun List<LessonStep>.withImages(images: List<Int>) =
    mapIndexed { i, s -> s.copy(image = images.getOrNull(i)) }

private val WUDU_IMAGES = listOf(
    R.drawable.kid_wudu_01_niyyah, R.drawable.kid_wudu_02_bismillah, R.drawable.kid_wudu_03_hands,
    R.drawable.kid_wudu_04_mouth, R.drawable.kid_wudu_05_nose, R.drawable.kid_wudu_06_face,
    R.drawable.kid_wudu_07_arms, R.drawable.kid_wudu_08_head, R.drawable.kid_wudu_09_ears,
    R.drawable.kid_wudu_10_feet, R.drawable.kid_wudu_11_dua,
)

private val SALAH_IMAGES = listOf(
    R.drawable.kid_salah_01_wudu, R.drawable.kid_salah_02_qibla, R.drawable.kid_salah_03_niyyah,
    R.drawable.kid_salah_04_takbir, R.drawable.kid_salah_05_qiyam, R.drawable.kid_salah_06_ruku,
    R.drawable.kid_salah_07_itidal, R.drawable.kid_salah_08_sujud, R.drawable.kid_salah_09_julus,
    R.drawable.kid_salah_10_sujud2, R.drawable.kid_salah_11_tashahhud, R.drawable.kid_salah_12_salawat,
    R.drawable.kid_salah_13_salam,
)

data class QuizQuestion(val question: String, val options: List<String>, val answer: Int, val emoji: String = "❓")

data class Quiz(val id: String, val title: String, val questions: List<QuizQuestion>)

/** المقرئين ديال المصحف المعلم (القارئ كيقرا بشوية والطفل كيعاود) */
val TEACHER_RECITERS = listOf(
    // الأول = الافتراضي: الشيخ كيقرا والأطفال كيعاودو من وراه
    Reciter("minshawy_t", "🧒 المنشاوي مع الأطفال (المصحف المعلم)", "Minshawy_Teacher_128kbps"),
    Reciter("husary_mu", "الحصري (المصحف المعلم)", "Husary_Muallim_128kbps"),
    Reciter("husary", "الحصري (مرتل)", "Husary_128kbps"),
    Reciter("alafasy", "مشاري العفاسي", "Alafasy_128kbps"),
)

/** قصار السور للأطفال: الفاتحة ومن الناس حتى الضحى، من بعد باقي جزء عم */
val KIDS_SURAHS: List<Int> = listOf(1) + (114 downTo 78).toList()

object KidsContent {

    val wudu = Lesson(
        id = "wudu",
        title = "تعلّم الوضوء",
        emoji = "💧",
        intro = "الوضوء هو الطهارة اللي كنديروها قبل الصلاة وقبل ما نمسّو المصحف. يلاه نتعلموه خطوة بخطوة!",
        steps = listOf(
            LessonStep("💭", "النية", "نوي فقلبك أنك غادي تتوضأ باش تصلي ولا تقرا القرآن. النية كتكون فالقلب."),
            LessonStep("🗣️", "التسمية", "قول: بسم الله", say = "بِسْمِ اللَّه"),
            LessonStep("🙌", "غسل اليدين", "غسل يديك بجوج حتى للمعصم، ودخل الما بين الصوابع.", times = "3 مرات"),
            LessonStep("👄", "المضمضة", "دخل الما لفمك، حركو مزيان، ومن بعد خرجو.", times = "3 مرات"),
            LessonStep("👃", "الاستنشاق والاستنثار", "جبد الما بنيفك بشوية، ومن بعد خرجو بيدك اليسرى.", times = "3 مرات"),
            LessonStep("😊", "غسل الوجه", "غسل وجهك كامل: من فوق الجبهة حتى للدقن، ومن ودن لودن.", times = "3 مرات"),
            LessonStep("💪", "غسل اليدين حتى للمرفق", "غسل يدك اليمنى من الصوابع حتى للمرفق (الكوع)، ومن بعد اليسرى.", times = "3 مرات"),
            LessonStep("🧑", "مسح الرأس", "فزك يديك بالما، ودوز بيهم على راسك من القدام حتى للور، ورجعهم للقدام."),
            LessonStep("👂", "مسح الأذنين", "مسح ودنيك من الداخل بالسبابة ومن اللور بالإبهام."),
            LessonStep("🦶", "غسل الرجلين", "غسل رجلك اليمنى حتى للكعب، ودخل الما بين الصوابع، ومن بعد اليسرى.", times = "3 مرات"),
            LessonStep(
                "🤲", "الدعاء بعد الوضوء", "ملي تسالي، قول هاد الدعاء:",
                say = "أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ",
            ),
        ).withImages(WUDU_IMAGES),
        cover = R.drawable.kid_wudu_03_hands,
        note = "💡 ما تسرفش فالما! النبي ﷺ كان كيتوضأ بشوية ديال الما.",
    )

    val salah = Lesson(
        id = "salah",
        title = "تعلّم الصلاة",
        emoji = "🕌",
        intro = "الصلاة هي الركن الثاني من أركان الإسلام، وكنصليو 5 ديال الصلوات فالنهار. يلاه نتعلموها!",
        steps = listOf(
            LessonStep("💧", "الوضوء", "قبل الصلاة خاصك تكون متوضئ ونقي، وحوايجك نقيين."),
            LessonStep("🧭", "استقبال القبلة", "وقف ووجهك للقبلة (جهة الكعبة فمكة)."),
            LessonStep("💭", "النية", "نوي فقلبك الصلاة اللي غادي تصلي، مثلا: صلاة الصبح."),
            LessonStep("🙋", "تكبيرة الإحرام", "رفع يديك وقول: الله أكبر. بهاد التكبيرة كتبدا الصلاة.", say = "اللَّهُ أَكْبَرُ"),
            LessonStep("🧍", "القراءة", "وانت واقف، اقرا سورة الفاتحة، ومن بعدها سورة قصيرة (فالركعة الأولى والثانية).", say = "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ…"),
            LessonStep("🙇", "الركوع", "قول الله أكبر وطيح ظهرك حتى يولي مستوي، وحط يديك على ركابيك.", say = "سُبْحَانَ رَبِّيَ الْعَظِيمِ", times = "3 مرات"),
            LessonStep("🧍", "الرفع من الركوع", "نوض ووقف مستوي وقول:", say = "سَمِعَ اللَّهُ لِمَنْ حَمِدَهُ، رَبَّنَا وَلَكَ الْحَمْدُ"),
            LessonStep("🧎", "السجود", "قول الله أكبر واسجد: الجبهة والنيف واليدين والركابي وصوابع الرجلين فالأرض.", say = "سُبْحَانَ رَبِّيَ الْأَعْلَى", times = "3 مرات"),
            LessonStep("🧘", "الجلوس بين السجدتين", "قول الله أكبر وجلس شوية مرتاح.", say = "رَبِّ اغْفِرْ لِي"),
            LessonStep("🧎", "السجدة الثانية", "قول الله أكبر واسجد مرة أخرى بحال الأولى. هكا كملتي ركعة وحدة! 🎉"),
            LessonStep(
                "🧘", "التشهد", "من بعد ركعتين كتجلس وكتقرا التشهد:",
                say = "التَّحِيَّاتُ لِلَّهِ، الزَّاكِيَاتُ لِلَّهِ، الطَّيِّبَاتُ الصَّلَوَاتُ لِلَّهِ، السَّلَامُ عَلَيْكَ أَيُّهَا النَّبِيُّ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُهُ، السَّلَامُ عَلَيْنَا وَعَلَى عِبَادِ اللَّهِ الصَّالِحِينَ، أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ",
            ),
            LessonStep("🤲", "الصلاة على النبي ﷺ", "فالتشهد الأخير، صلي على النبي ﷺ (الصلاة الإبراهيمية)."),
            LessonStep("👋", "السلام", "فالأخير، دور وجهك لليمين وقول: السلام عليكم. هكا كملتي الصلاة! 🌟", say = "السَّلَامُ عَلَيْكُمْ"),
        ).withImages(SALAH_IMAGES),
        cover = R.drawable.kid_salah_04_takbir,
        note = "📋 عدد الركعات: الصبح ٢ • الظهر ٤ • العصر ٤ • المغرب ٣ • العشاء ٤\n" +
            "👨‍👩‍👧 كاينين تفاصيل صغيرة كتختالف بين المذاهب؛ تعلّمها مع الوالدين ولا الفقيه. التشهد اللي هنا هو اللي فالموطأ (المذهب المالكي).",
    )

    val lessons = listOf(wudu, salah)

    val wuduQuiz = Quiz(
        "wudu", "اختبار الوضوء",
        listOf(
            QuizQuestion("شنو أول حاجة كنديروها فالوضوء؟", listOf("غسل الرجلين", "النية", "مسح الرأس"), 1, "💭"),
            QuizQuestion("شحال من مرة كنغسلو الوجه؟", listOf("مرة وحدة", "3 مرات", "10 مرات"), 1, "😊"),
            QuizQuestion("حتى فين كنغسلو اليدين؟", listOf("حتى للمرفق", "غير الصوابع", "حتى للكتف"), 0, "💪"),
            QuizQuestion("الراس كنغسلوه ولا كنمسحوه؟", listOf("كنغسلوه", "كنمسحوه", "ما كنقربوش ليه"), 1, "🧑"),
            QuizQuestion("آخر عضو كنغسلوه فالوضوء هو…", listOf("الوجه", "اليدين", "الرجلين"), 2, "🦶"),
            QuizQuestion("واش مزيان نسرفو بزاف ديال الما؟", listOf("إيه", "لا، كنقتصدو فالما"), 1, "💧"),
        ),
    )

    val salahQuiz = Quiz(
        "salah", "اختبار الصلاة",
        listOf(
            QuizQuestion("شحال من صلاة كنصليو فالنهار؟", listOf("3", "5", "7"), 1, "🕌"),
            QuizQuestion("بأش كتبدا الصلاة؟", listOf("السلام عليكم", "الله أكبر", "آمين"), 1, "🙋"),
            QuizQuestion("شنو كنقولو فالركوع؟", listOf("سبحان ربي العظيم", "سبحان ربي الأعلى", "رب اغفر لي"), 0, "🙇"),
            QuizQuestion("شنو كنقولو فالسجود؟", listOf("سمع الله لمن حمده", "سبحان ربي الأعلى", "الله أكبر"), 1, "🧎"),
            QuizQuestion("شحال من ركعة فصلاة الصبح؟", listOf("2", "3", "4"), 0, "🌅"),
            QuizQuestion("شحال من ركعة فصلاة المغرب؟", listOf("2", "3", "4"), 1, "🌇"),
            QuizQuestion("بأش كتسالي الصلاة؟", listOf("الله أكبر", "السلام عليكم", "بسم الله"), 1, "👋"),
            QuizQuestion("أول سورة كنقراوها فكل ركعة هي…", listOf("سورة الإخلاص", "سورة الفاتحة", "سورة الناس"), 1, "📖"),
        ),
    )

    fun quiz(id: String): Quiz? = when (id) {
        "wudu" -> wuduQuiz
        "salah" -> salahQuiz
        else -> null
    }

    /** اختبار سورة: "شنو الآية اللي من بعد…؟" كيتصاوب أوتوماتيكيا */
    fun surahQuiz(s: Surah, count: Int = 5): Quiz {
        val ayahs = s.ayahs
        val rnd = kotlin.random.Random(s.id * 31 + (System.currentTimeMillis() / 86_400_000L).toInt())
        val qs = ArrayList<QuizQuestion>()
        if (ayahs.size >= 3) {
            val candidates = (0 until ayahs.size - 1).shuffled(rnd).take(count)
            for (i in candidates.sorted()) {
                val right = ayahs[i + 1].text
                val wrong = ayahs.indices.filter { it != i + 1 && it != i && ayahs[it].text != right }
                    .shuffled(rnd).take(2).map { ayahs[it].text }
                if (wrong.size < 2) continue
                val opts = (wrong + right).shuffled(rnd)
                qs += QuizQuestion("شنو الآية اللي كتجي من بعد:\n«${ayahs[i].text}»", opts, opts.indexOf(right), "📖")
            }
        }
        if (qs.isEmpty()) {
            qs += QuizQuestion(
                "شحال من آية فسورة ${s.name}؟",
                listOf(s.ayahs.size, s.ayahs.size + 2, (s.ayahs.size - 1).coerceAtLeast(1) + 5).map { it.toString() }.distinct(),
                0, "🔢",
            )
        }
        return Quiz("surah_${s.id}", "اختبار سورة ${s.name}", qs)
    }
}
