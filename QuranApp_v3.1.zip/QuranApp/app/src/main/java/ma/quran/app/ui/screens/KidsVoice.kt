package ma.quran.app.ui.screens

import android.content.Context
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import java.util.Locale

/**
 * صوت طفولي (التركيب الصوتي ديال التلفون بصوت حاد) كيقرا الشروحات والأسئلة والتشجيع.
 * ⚠️ ما كيقراش القرآن أبدا: التلاوة ديما بأصوات حقيقية (المصحف المعلم مع الأطفال).
 */
class KidsVoice(private val context: Context) {
    private val prefs = context.getSharedPreferences("kids_voice", Context.MODE_PRIVATE)
    var enabled by mutableStateOf(prefs.getBoolean("on", true))
        private set
    var ready by mutableStateOf(false)
        private set
    private var warned = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            val t = tts ?: return@TextToSpeech
            if (status != TextToSpeech.SUCCESS) return@TextToSpeech
            val lang = listOf(Locale("ar", "MA"), Locale("ar", "SA"), Locale("ar"))
                .firstOrNull { t.isLanguageAvailable(it) >= TextToSpeech.LANG_AVAILABLE }
            if (lang != null) {
                t.language = lang
                // صوت حاد وبطيء شوية = صوت ديال طفل
                t.setPitch(1.75f)
                t.setSpeechRate(0.9f)
                ready = true
            }
        }
    }

    fun toggle() {
        enabled = !enabled
        prefs.edit().putBoolean("on", enabled).apply()
        if (!enabled) stop()
    }

    /** كيقرا النص إلا كان الصوت مشعول (force = الزر 🔊) */
    fun say(text: String, force: Boolean = false) {
        if (!enabled && !force) return
        if (!ready) {
            if (force && !warned) {
                warned = true
                Toast.makeText(context, "ثبت الصوت العربي فالتلفون: الإعدادات ← اللغة ← تحويل النص إلى كلام (Google)", Toast.LENGTH_LONG).show()
            }
            return
        }
        // كنحيدو الإيموجي باش ما يتقراش
        val clean = text.replace(Regex("[\\p{So}\\p{Cn}\\uFE0F\\u200D]"), " ").trim()
        if (clean.isNotEmpty()) tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "kids")
    }

    fun stop() { tts?.stop() }

    fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

@Composable
fun rememberKidsVoice(): KidsVoice {
    val context = LocalContext.current
    val voice = remember { KidsVoice(context) }
    DisposableEffect(voice) { onDispose { voice.release() } }
    return voice
}
