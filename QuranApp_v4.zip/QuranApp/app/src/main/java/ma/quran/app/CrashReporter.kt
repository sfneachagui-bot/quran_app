package ma.quran.app

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/** كيحفظ سبب أي خطأ (crash) فملف باش يبان فالمرة الجاية ونصيفطوه للمطور */
object CrashReporter {
    private fun file(c: Context) = File(c.filesDir, "last_crash.txt")

    fun install(c: Context) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                file(c).writeText(
                    "Version: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})\n" +
                        "Android: ${android.os.Build.VERSION.RELEASE} / ${android.os.Build.MODEL}\n\n" + sw.toString()
                )
            }
            previous?.uncaughtException(t, e)
        }
    }

    fun read(c: Context): String? = file(c).takeIf { it.exists() }?.readText()
    fun clear(c: Context) { file(c).delete() }
}
