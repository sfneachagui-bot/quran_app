package ma.quran.app.data

object ArabicText {
    private val diacritics = Regex("[\\u0610-\\u061A\\u064B-\\u065F\\u0670\\u06D6-\\u06ED\\u0640]")

    /** كيحيد التشكيل وكيوحد الحروف باش البحث يخدم بلا ما يكتب المستعمل التشكيل */
    fun normalize(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in diacritics.replace(s, "")) {
            sb.append(
                when (c) {
                    'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                    'ى', 'ئ' -> 'ي'
                    'ؤ' -> 'و'
                    'ة' -> 'ه'
                    else -> c
                }
            )
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    /** الرسم العثماني كيحيد بزاف ديال الألفات (الصرط/الصراط)، هادي كتقارن بلا ألف */
    fun skeleton(normalized: String) = normalized.replace("ا", "")
}
