package ma.quran.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate

@Serializable
data class OfflineHadithDto(val n: Int, val ar: String, val fr: String)

@Serializable
data class OfflineCollectionDto(val name: String, val hadiths: List<OfflineHadithDto>)

@Serializable
data class SectionMeta(val n: Int, val name: String, val first: Int, val last: Int) {
    val count: Int get() = (last - first + 1).coerceAtLeast(0)
}

@Serializable
data class CollectionMeta(val id: String, val name: String, val total: Int, val sections: List<SectionMeta>)

data class Hadith(
    val collection: String,
    val section: Int,
    val number: Int,
    val text: String,
    val fr: String? = null,
    /** الحكم على الحديث (من الألباني ولا غيرو) إلا كان */
    val grade: String? = null,
) {
    /** كيتخزن فالمفضلة: collection:section:number */
    val key: String get() = "$collection:$section:$number"
}

/** الكتب اللي كاينين فالتطبيق بلا أنترنيت */
val OFFLINE_COLLECTIONS = listOf("nawawi", "qudsi")

/**
 * الأحاديث: الأربعون النووية والقدسية مخزنين فالتطبيق،
 * والكتب الستة + الموطأ كيتجابو كتاب بكتاب من hadith-api (fawazahmed0) وكيتخباو فالتلفون.
 */
class HadithRepository(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true }
    private val mutex = Mutex()
    private var offline: Map<String, Pair<String, List<Hadith>>>? = null
    private var meta: List<CollectionMeta>? = null
    private val sections = HashMap<String, List<Hadith>>()

    private fun asset(name: String) = context.assets.open(name).bufferedReader().use { it.readText() }

    /** id -> (الاسم، الأحاديث) */
    suspend fun offline(): Map<String, Pair<String, List<Hadith>>> = mutex.withLock {
        offline ?: withContext(Dispatchers.IO) {
            json.decodeFromString<Map<String, OfflineCollectionDto>>(asset("hadith_offline.json"))
                .mapValues { (id, c) -> c.name to c.hadiths.map { Hadith(id, 1, it.n, it.ar, it.fr.ifBlank { null }) } }
                .also { offline = it }
        }
    }

    suspend fun meta(): List<CollectionMeta> = meta ?: withContext(Dispatchers.IO) {
        json.decodeFromString<List<CollectionMeta>>(asset("hadith_meta.json")).also { meta = it }
    }

    fun isCached(collection: String, section: Int) = cacheFile(collection, section).exists()

    private fun cacheFile(c: String, s: Int) = File(context.filesDir, "hadith/ara-${c}_$s.json")

    suspend fun section(collection: String, section: Int): Result<List<Hadith>> = runCatching {
        val key = "$collection:$section"
        sections[key]?.let { return@runCatching it }
        val file = cacheFile(collection, section)
        val raw = withContext(Dispatchers.IO) {
            if (file.exists()) file.readText()
            else download("https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/ara-$collection/sections/$section.min.json").also {
                file.parentFile?.mkdirs()
                file.writeText(it)
            }
        }
        val list = withContext(Dispatchers.Default) {
            json.parseToJsonElement(raw).jsonObject["hadiths"]!!.jsonArray.mapNotNull { e ->
                val o = e.jsonObject
                val text = o["text"]?.jsonPrimitive?.content?.trim().orEmpty()
                if (text.isEmpty()) return@mapNotNull null
                Hadith(
                    collection = collection,
                    section = section,
                    number = o["hadithnumber"]!!.jsonPrimitive.content.toDouble().toInt(),
                    text = text,
                    grade = o["grades"]?.jsonArray?.let { grades ->
                        val all = grades.map { it.jsonObject }
                        val g = all.firstOrNull { it["name"]?.jsonPrimitive?.content?.contains("Albani") == true } ?: all.firstOrNull()
                        g?.let {
                            val who = it["name"]?.jsonPrimitive?.content.orEmpty()
                            val what = gradeAr(it["grade"]?.jsonPrimitive?.content.orEmpty())
                            if (who.contains("Albani")) "حكم الألباني: $what" else "الحكم: $what ($who)"
                        }
                    },
                )
            }
        }
        sections[key] = list
        list
    }

    /** حديث اليوم: كيتبدل كل نهار من الأربعين النووية والقدسية */
    suspend fun hadithOfDay(): Hadith {
        val all = offline().values.flatMap { it.second }
        return all[(LocalDate.now().toEpochDay() % all.size).toInt()]
    }

    /** كيرجع حديث من المفضلة (من التطبيق ولا من اللي متخبي فالتلفون) */
    suspend fun find(key: String): Hadith? {
        val p = key.split(":")
        if (p.size != 3) return null
        val (c, s, n) = Triple(p[0], p[1].toIntOrNull() ?: return null, p[2].toIntOrNull() ?: return null)
        if (c in OFFLINE_COLLECTIONS) return offline()[c]?.second?.firstOrNull { it.number == n }
        if (!isCached(c, s) && sections["$c:$s"] == null) return null
        return section(c, s).getOrNull()?.firstOrNull { it.number == n }
    }

    suspend fun collectionName(id: String): String =
        offline()[id]?.first ?: meta().firstOrNull { it.id == id }?.name ?: id

    private fun download(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        try {
            if (conn.responseCode != 200) error("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        fun gradeAr(g: String): String {
            val s = g.lowercase()
            return when {
                "hasan sahih" in s || "hasan saheeh" in s -> "حسن صحيح"
                "sahih" in s || "saheeh" in s -> if ("lighairihi" in s.replace(" ", "")) "صحيح لغيره" else "صحيح"
                "hasan" in s -> if ("lighairihi" in s.replace(" ", "")) "حسن لغيره" else "حسن"
                "maudu" in s || "mawdu" in s || "fabricated" in s -> "موضوع"
                "munkar" in s -> "منكر"
                "shadh" in s -> "شاذ"
                "da'if" in s || "daif" in s || "da`if" in s || "weak" in s || "dhaif" in s -> "ضعيف"
                else -> g
            }
        }
    }
}
