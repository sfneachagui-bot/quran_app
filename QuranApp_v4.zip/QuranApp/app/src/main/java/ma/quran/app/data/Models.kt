package ma.quran.app.data

import kotlinx.serialization.Serializable
import java.util.Locale

@Serializable
data class SurahDto(
    val id: Int,
    val name: String,
    val tr: String,
    val meaning: String,
    val meaningEn: String,
    val type: String,
    val verses: List<VerseDto>,
)

@Serializable
data class VerseDto(val ar: String, val fr: String, val en: String)

data class Surah(
    val id: Int,
    val name: String,
    val transliteration: String,
    val meaningFr: String,
    val meaningEn: String,
    val isMeccan: Boolean,
    val ayahs: List<Ayah>,
)

data class Ayah(
    val surah: Int,
    val number: Int,
    val text: String,
    val fr: String,
    val en: String,
    /** نص بلا تشكيل، للبحث */
    val plain: String,
) {
    val key: String get() = "$surah:$number"
}

data class AyahRef(val surah: Int, val ayah: Int) : Comparable<AyahRef> {
    override fun toString() = "$surah:$ayah"
    override fun compareTo(other: AyahRef) = compareValuesBy(this, other, { it.surah }, { it.ayah })

    companion object {
        fun parse(s: String?): AyahRef? {
            val p = s?.split(":") ?: return null
            if (p.size != 2) return null
            val a = p[0].toIntOrNull() ?: return null
            val b = p[1].toIntOrNull() ?: return null
            return AyahRef(a, b)
        }
    }
}

enum class Translation(val label: String) { NONE("بلا ترجمة"), FR("Français"), EN("English") }

enum class TafsirEdition(val apiId: String, val label: String) {
    MUYASSAR("ar.muyassar", "التفسير الميسر"),
    JALALAYN("ar.jalalayn", "تفسير الجلالين"),
}

data class Reciter(val id: String, val name: String, val folder: String) {
    /** صوت آية واحدة من everyayah.com */
    fun url(surah: Int, ayah: Int) =
        String.format(Locale.ROOT, "https://everyayah.com/data/%s/%03d%03d.mp3", folder, surah, ayah)
}

val RECITERS = listOf(
    Reciter("alafasy", "مشاري العفاسي", "Alafasy_128kbps"),
    Reciter("abdulbasit", "عبد الباسط عبد الصمد (مرتل)", "Abdul_Basit_Murattal_192kbps"),
    Reciter("husary", "محمود خليل الحصري", "Husary_128kbps"),
    Reciter("minshawy", "محمد صديق المنشاوي (مرتل)", "Minshawy_Murattal_128kbps"),
    Reciter("maher", "ماهر المعيقلي", "MaherAlMuaiqly128kbps"),
    Reciter("shuraym", "سعود الشريم", "Saood_ash-Shuraym_128kbps"),
)

fun Int.toArabicDigits(): String =
    toString().map { if (it.isDigit()) '٠' + (it - '0') else it }.joinToString("")

@Serializable
data class PartsDto(val juz: List<List<Int>>, val rub: List<List<Int>>)

/** بدايات الأجزاء (30) وأرباع الأحزاب (240) */
class Parts(val juz: List<AyahRef>, val rub: List<AyahRef>) {
    private fun indexOf(list: List<AyahRef>, ref: AyahRef): Int {
        var i = list.binarySearch(ref)
        if (i < 0) i = -i - 2
        return i.coerceIn(0, list.lastIndex)
    }

    /** رقم الجزء 1..30 */
    fun juzOf(ref: AyahRef) = indexOf(juz, ref) + 1

    /** رقم الربع 1..240 */
    fun rubOf(ref: AyahRef) = indexOf(rub, ref) + 1

    fun hizbOf(ref: AyahRef) = (rubOf(ref) - 1) / 4 + 1

    /** "الحزب ١٢" أو "¼ الحزب ١٢" ... */
    fun hizbLabel(ref: AyahRef): String {
        val r = rubOf(ref) - 1
        val h = (r / 4 + 1).toArabicDigits()
        return when (r % 4) {
            0 -> "الحزب $h"
            1 -> "ربع الحزب $h"
            2 -> "نصف الحزب $h"
            else -> "ثلاثة أرباع الحزب $h"
        }
    }

    fun isQuarterStart(ref: AyahRef) = rub.binarySearch(ref) >= 0
}

val QUARTER_NAMES = listOf("بداية الحزب", "الربع", "النصف", "ثلاثة أرباع")
