package ma.quran.app.player

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import ma.quran.app.data.AyahRef
import ma.quran.app.data.Reciter
import ma.quran.app.data.Surah

data class PlayerState(
    val current: AyahRef? = null,
    val surahName: String = "",
    val reciterName: String = "",
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val repeatAyah: Boolean = false,
    val error: String? = null,
)

/** كيتواصل مع PlaybackService عبر MediaController */
class PlayerController(context: Context) {
    private val appContext = context.applicationContext
    private var controller: MediaController? = null
    private var connecting = false
    private val pending = ArrayList<(MediaController) -> Unit>()

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = update(player)
        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
            _state.value = _state.value.copy(error = "ما قدرناش نشغلو الصوت، تأكد من الأنترنيت")
        }
    }

    private fun withController(action: (MediaController) -> Unit) {
        controller?.let { action(it); return }
        pending += action
        if (connecting) return
        connecting = true
        val token = SessionToken(appContext, ComponentName(appContext, PlaybackService::class.java))
        val future = MediaController.Builder(appContext, token).buildAsync()
        future.addListener({
            connecting = false
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            controller = c
            c.addListener(listener)
            update(c)
            pending.toList().forEach { it(c) }
            pending.clear()
        }, ContextCompat.getMainExecutor(appContext))
    }

    fun connect() = withController { }

    fun playSurah(surah: Surah, fromAyah: Int, reciter: Reciter) = withController { c ->
        val items = surah.ayahs.map { a ->
            MediaItem.Builder()
                .setMediaId("${surah.id}:${a.number}")
                .setUri(reciter.url(surah.id, a.number))
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle("سورة ${surah.name} - الآية ${a.number}")
                        .setArtist(reciter.name)
                        .setAlbumTitle("سورة ${surah.name}")
                        .build()
                )
                .build()
        }
        _state.value = _state.value.copy(surahName = surah.name, reciterName = reciter.name, error = null)
        c.setMediaItems(items, (fromAyah - 1).coerceIn(0, items.lastIndex), 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() = withController { c -> if (c.isPlaying) c.pause() else c.play() }
    fun next() = withController { it.seekToNextMediaItem() }
    fun previous() = withController { it.seekToPreviousMediaItem() }

    fun toggleRepeatAyah() = withController { c ->
        c.repeatMode = if (c.repeatMode == Player.REPEAT_MODE_ONE) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ONE
    }

    fun stop() = withController { c ->
        c.stop()
        c.clearMediaItems()
    }

    fun clearError() { _state.value = _state.value.copy(error = null) }

    private fun update(p: Player) {
        val item = p.currentMediaItem
        val title = item?.mediaMetadata?.albumTitle?.toString()?.removePrefix("سورة ")
        _state.value = _state.value.copy(
            current = AyahRef.parse(item?.mediaId),
            surahName = title ?: _state.value.surahName,
            reciterName = item?.mediaMetadata?.artist?.toString() ?: _state.value.reciterName,
            isPlaying = p.isPlaying,
            isBuffering = p.playbackState == Player.STATE_BUFFERING,
            repeatAyah = p.repeatMode == Player.REPEAT_MODE_ONE,
        )
    }
}
