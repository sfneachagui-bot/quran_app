package ma.quran.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ma.quran.app.data.toArabicDigits
import ma.quran.app.ui.QuranViewModel
import ma.quran.app.ui.theme.QuranFont

@Composable
fun BookmarksScreen(vm: QuranViewModel, openReader: (Int, Int) -> Unit) {
    val bookmarks by vm.bookmarks.collectAsStateWithLifecycle()
    val surahs by vm.surahs.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text(
            "العلامات",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(20.dp),
        )
        if (bookmarks.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
                Text(
                    "ما زال ما حطيتي حتى علامة.\nضغط على أيقونة العلامة حدا أي آية باش تحفظها هنا.",
                    textAlign = TextAlign.Center,
                )
            }
            return@Column
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(bookmarks, key = { it.toString() }) { ref ->
                val a = vm.ayah(ref) ?: return@items
                Card(
                    onClick = { openReader(ref.surah, ref.ayah) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "سورة ${surahs.getOrNull(ref.surah - 1)?.name.orEmpty()} • الآية ${ref.ayah.toArabicDigits()}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f),
                            )
                            IconButton(onClick = { vm.toggleBookmark(ref) }) { Icon(Icons.Filled.Delete, "حذف") }
                        }
                        Text(
                            a.text,
                            fontFamily = QuranFont,
                            fontSize = 22.sp,
                            lineHeight = 40.sp,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}
