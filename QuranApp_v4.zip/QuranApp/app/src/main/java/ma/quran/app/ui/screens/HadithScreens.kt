package ma.quran.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ma.quran.app.data.Hadith
import ma.quran.app.data.OFFLINE_COLLECTIONS
import ma.quran.app.data.toArabicDigits
import ma.quran.app.ui.HadithViewModel
import ma.quran.app.ui.theme.DeepGreen
import ma.quran.app.ui.theme.Gold
import ma.quran.app.ui.theme.OrnamentDivider
import ma.quran.app.ui.theme.QuranFont
import ma.quran.app.ui.theme.StarBadge
import ma.quran.app.ui.theme.StarPattern

private val GreenBrush = Brush.linearGradient(listOf(Color(0xFF0B3D26), DeepGreen, Color(0xFF1C7A4D)))

// ------------------------------------------------------------------
// الصفحة الرئيسية ديال الحديث
// ------------------------------------------------------------------
@Composable
fun HadithHomeScreen(hvm: HadithViewModel, open: (String) -> Unit) {
    val meta by hvm.meta.collectAsStateWithLifecycle()
    val offline by hvm.offline.collectAsStateWithLifecycle()
    val day by hvm.hadithOfDay.collectAsStateWithLifecycle()
    val favs by hvm.favKeys.collectAsStateWithLifecycle()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                    .background(GreenBrush),
            ) {
                StarPattern(Modifier.matchParentSize())
                Column(
                    Modifier
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp)
                        .padding(top = 12.dp, bottom = 22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("الحديث النبوي الشريف", fontFamily = QuranFont, fontSize = 32.sp, color = Gold)
                    OrnamentDivider(Modifier.width(180.dp).height(14.dp))
                    Spacer(Modifier.height(14.dp))
                    day?.let { h ->
                        Surface(
                            onClick = { open("hadith/${h.collection}?n=${h.number}") },
                            shape = RoundedCornerShape(22.dp),
                            color = Color.White.copy(alpha = 0.12f),
                            contentColor = Color.White,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(Modifier.padding(18.dp)) {
                                Text("حديث اليوم", style = MaterialTheme.typography.labelLarge, color = Gold)
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    h.text,
                                    style = MaterialTheme.typography.bodyLarge,
                                    lineHeight = 28.sp,
                                    maxLines = 6,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "${hvm.name(h.collection)} • الحديث ${h.number.toArabicDigits()}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White.copy(alpha = 0.75f),
                                )
                            }
                        }
                    }
                }
            }
        }

        item { SectionTitle("المفضلة") }
        item {
            CollectionRow(
                badge = favs.size,
                title = "الأحاديث المفضلة",
                subtitle = if (favs.isEmpty()) "ضغط على ♡ حدا أي حديث باش تحفظو هنا" else "${favs.size.toArabicDigits()} حديث",
                trailing = null,
                onClick = { open("hadith_favs") },
            )
        }

        item { SectionTitle("متاحة بلا أنترنيت") }
        OFFLINE_COLLECTIONS.forEach { id ->
            val c = offline[id] ?: return@forEach
            item(key = id) {
                CollectionRow(
                    badge = c.second.size,
                    title = c.first,
                    subtitle = "${c.second.size.toArabicDigits()} حديث • مع الترجمة الفرنسية",
                    trailing = Icons.Filled.CloudDone,
                    onClick = { open("hadith/$id") },
                )
            }
        }

        item { SectionTitle("الكتب الستة وموطأ مالك") }
        items(meta, key = { it.id }) { c ->
            CollectionRow(
                badge = c.sections.size,
                title = c.name,
                subtitle = "${c.total.toArabicDigits()} حديث • ${c.sections.size.toArabicDigits()} كتاب",
                trailing = Icons.Filled.CloudDownload,
                onClick = { open("hadith/${c.id}") },
            )
        }
        item {
            Text(
                "الكتب الكبيرة كتتجاب من الأنترنيت كتاب بكتاب أول مرة، ومن بعد كتبقى فالتلفون.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            )
        }
    }
}

@Composable
private fun SectionTitle(t: String) {
    Text(
        t,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 6.dp),
    )
}

@Composable
private fun CollectionRow(
    badge: Int,
    title: String,
    subtitle: String,
    trailing: androidx.compose.ui.graphics.vector.ImageVector?,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 3.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StarBadge(badge)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            )
        }
        if (trailing != null) Icon(trailing, null, tint = MaterialTheme.colorScheme.secondary)
    }
}

// ------------------------------------------------------------------
// شريط فوقاني أخضر
// ------------------------------------------------------------------
@Composable
fun GreenTopBar(title: String, subtitle: String?, onBack: () -> Unit, actions: (@Composable () -> Unit)? = null) {
    Box(
        Modifier
            .fillMaxWidth()
            .background(GreenBrush),
    ) {
        StarPattern(Modifier.matchParentSize())
        Row(
            Modifier
                .statusBarsPadding()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = Color.White) }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(title, fontFamily = QuranFont, fontSize = 24.sp, color = Gold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(alpha = 0.85f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            if (actions != null) actions() else Spacer(Modifier.width(48.dp))
        }
    }
}

// ------------------------------------------------------------------
// كتاب: الأربعين/القدسية (قائمة الأحاديث) ولا كتاب كبير (قائمة الأبواب)
// ------------------------------------------------------------------
@Composable
fun HadithCollectionScreen(
    hvm: HadithViewModel,
    id: String,
    focus: Int,
    onBack: () -> Unit,
    openSection: (Int) -> Unit,
) {
    val offline by hvm.offline.collectAsStateWithLifecycle()
    val meta by hvm.meta.collectAsStateWithLifecycle()
    val favs by hvm.favKeys.collectAsStateWithLifecycle()
    var showFr by rememberSaveable { mutableStateOf(false) }

    val off = offline[id]
    if (off != null) {
        val listState = androidx.compose.foundation.lazy.rememberLazyListState()
        LaunchedEffect(focus, off) {
            if (focus > 0) {
                val i = off.second.indexOfFirst { it.number == focus }
                if (i >= 0) listState.scrollToItem(i)
            }
        }
        Column(Modifier.fillMaxSize().navigationBarsPadding()) {
            GreenTopBar(off.first, "${off.second.size.toArabicDigits()} حديث", onBack) {
                IconButton(onClick = { showFr = !showFr }) {
                    Icon(Icons.Filled.Translate, "الترجمة", tint = if (showFr) Gold else Color.White)
                }
            }
            LazyColumn(state = listState, contentPadding = PaddingValues(vertical = 8.dp)) {
                items(off.second, key = { it.key }) { h ->
                    HadithCard(h, h.key in favs, showFr, onFav = { hvm.toggleFav(h) }, source = off.first)
                }
            }
        }
        return
    }

    val c = meta.firstOrNull { it.id == id }
    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        GreenTopBar(c?.name ?: "", c?.let { "${it.sections.size.toArabicDigits()} كتاب" }, onBack)
        if (c == null) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            return@Column
        }
        LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
            items(c.sections, key = { it.n }) { s ->
                val cached = hvm.isCached(id, s.n)
                CollectionRow(
                    badge = if (s.n == 0) 0 else s.n,
                    title = if (s.n == 0) "المقدمة" else "الكتاب ${s.n.toArabicDigits()}",
                    subtitle = "${s.name} • الأحاديث ${s.first.toArabicDigits()}–${s.last.toArabicDigits()}",
                    trailing = if (cached) Icons.Filled.CloudDone else Icons.Filled.CloudDownload,
                    onClick = { openSection(s.n) },
                )
            }
        }
    }
}

// ------------------------------------------------------------------
// أحاديث باب (كتاب) من الكتب الكبيرة
// ------------------------------------------------------------------
@Composable
fun HadithSectionScreen(hvm: HadithViewModel, id: String, section: Int, onBack: () -> Unit) {
    val ui by hvm.section.collectAsStateWithLifecycle()
    val meta by hvm.meta.collectAsStateWithLifecycle()
    val favs by hvm.favKeys.collectAsStateWithLifecycle()
    val c = meta.firstOrNull { it.id == id }
    val s = c?.sections?.firstOrNull { it.n == section }
    LaunchedEffect(id, section) { hvm.loadSection(id, section) }

    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        GreenTopBar(
            c?.name ?: "",
            s?.let { (if (it.n == 0) "المقدمة" else "الكتاب ${it.n.toArabicDigits()}") + " • " + it.name },
            onBack,
        )
        when {
            ui.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp))
                    Text("كنجيبو الأحاديث…")
                }
            }
            ui.error != null -> Box(Modifier.fillMaxSize().padding(24.dp), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(ui.error!!, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { hvm.loadSection(id, section) }) { Text("عاود المحاولة") }
                }
            }
            else -> LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
                items(ui.hadiths, key = { it.key }) { h ->
                    HadithCard(h, h.key in favs, false, onFav = { hvm.toggleFav(h) }, source = c?.name ?: "")
                }
            }
        }
    }
}

// ------------------------------------------------------------------
// المفضلة
// ------------------------------------------------------------------
@Composable
fun HadithFavoritesScreen(hvm: HadithViewModel, onBack: () -> Unit) {
    val favs by hvm.favorites.collectAsStateWithLifecycle()
    val keys by hvm.favKeys.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        GreenTopBar("الأحاديث المفضلة", null, onBack)
        val list = favs
        when {
            list == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
                Text("ما زال ما حفظتي حتى حديث.\nضغط على ♡ حدا أي حديث.", textAlign = TextAlign.Center)
            }
            else -> LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
                items(list, key = { it.key }) { h ->
                    HadithCard(h, h.key in keys, false, onFav = { hvm.toggleFav(h) }, source = hvm.name(h.collection))
                }
            }
        }
    }
}

// ------------------------------------------------------------------
// بطاقة الحديث
// ------------------------------------------------------------------
@Composable
fun HadithCard(h: Hadith, isFav: Boolean, showFr: Boolean, onFav: () -> Unit, source: String) {
    val context = LocalContext.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StarBadge(h.number, size = 38.dp)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(source, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Text("الحديث ${h.number.toArabicDigits()}", style = MaterialTheme.typography.labelSmall)
            }
            IconButton(onClick = onFav) {
                Icon(
                    if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    "المفضلة",
                    tint = if (isFav) Color(0xFFC0392B) else MaterialTheme.colorScheme.onSurface,
                )
            }
            IconButton(onClick = { copyHadith(context, h, source) }) { Icon(Icons.Filled.ContentCopy, "نسخ") }
            IconButton(onClick = { shareHadith(context, h, source) }) { Icon(Icons.Filled.Share, "مشاركة") }
        }
        Spacer(Modifier.height(8.dp))
        SelectionContainer {
            Text(h.text, style = MaterialTheme.typography.bodyLarge, fontSize = 19.sp, lineHeight = 34.sp)
        }
        if (h.grade != null) {
            Spacer(Modifier.height(8.dp))
            val weak = h.grade.contains("ضعيف") || h.grade.contains("موضوع") || h.grade.contains("منكر")
            Surface(
                shape = RoundedCornerShape(50),
                color = if (weak) Color(0x33C0392B) else MaterialTheme.colorScheme.primaryContainer,
            ) {
                Text(
                    h.grade,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                )
            }
        }
        if (showFr && h.fr != null) {
            Spacer(Modifier.height(10.dp))
            Text(
                h.fr,
                style = MaterialTheme.typography.bodyMedium.copy(textDirection = TextDirection.Ltr),
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f),
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

private fun hadithText(h: Hadith, source: String) =
    "${h.text}\n[$source - الحديث ${h.number.toArabicDigits()}]" + (h.grade?.let { "\n$it" } ?: "")

private fun copyHadith(context: Context, h: Hadith, source: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("حديث", hadithText(h, source)))
    Toast.makeText(context, "تنسخ الحديث", Toast.LENGTH_SHORT).show()
}

private fun shareHadith(context: Context, h: Hadith, source: String) {
    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, hadithText(h, source))
    context.startActivity(Intent.createChooser(i, "مشاركة الحديث"))
}
