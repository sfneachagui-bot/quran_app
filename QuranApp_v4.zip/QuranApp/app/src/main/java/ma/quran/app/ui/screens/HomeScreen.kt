package ma.quran.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ma.quran.app.data.AyahRef
import ma.quran.app.data.Parts
import ma.quran.app.data.QUARTER_NAMES
import ma.quran.app.data.Surah
import ma.quran.app.data.toArabicDigits
import ma.quran.app.ui.QuranViewModel
import ma.quran.app.ui.theme.DeepGreen
import ma.quran.app.ui.theme.Gold
import ma.quran.app.ui.theme.OrnamentDivider
import ma.quran.app.ui.theme.QuranFont
import ma.quran.app.ui.theme.StarBadge
import ma.quran.app.ui.theme.StarPattern

private val TABS = listOf("السور", "الأجزاء", "الأحزاب")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: QuranViewModel, openReader: (Int, Int) -> Unit) {
    val surahs by vm.surahs.collectAsStateWithLifecycle()
    val parts by vm.parts.collectAsStateWithLifecycle()
    val last by vm.lastRead.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    if (surahs.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        return
    }

    LazyColumn(Modifier.fillMaxSize()) {
        item(key = "hero") { Hero(surahs, parts, last, openReader) }
        item(key = "tabs") {
            SingleChoiceSegmentedButtonRow(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
            ) {
                TABS.forEachIndexed { i, label ->
                    SegmentedButton(
                        selected = tab == i,
                        onClick = { tab = i },
                        shape = SegmentedButtonDefaults.itemShape(i, TABS.size),
                        label = { Text(label, fontWeight = FontWeight.SemiBold) },
                    )
                }
            }
        }
        when (tab) {
            0 -> surahList(surahs, openReader)
            1 -> parts?.let { juzList(it, surahs, openReader) }
            else -> parts?.let { hizbList(it, surahs, openReader) }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun Hero(surahs: List<Surah>, parts: Parts?, last: AyahRef?, openReader: (Int, Int) -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF0B3D26), DeepGreen, Color(0xFF1C7A4D)))),
    ) {
        StarPattern(Modifier.matchParentSize())
        Column(
            Modifier
                .statusBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(top = 12.dp, bottom = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("القرآن الكريم", fontFamily = QuranFont, fontSize = 38.sp, color = Gold)
            OrnamentDivider(Modifier.width(180.dp).height(14.dp))
            Spacer(Modifier.height(16.dp))
            val ref = last
            val s = ref?.let { surahs.getOrNull(it.surah - 1) }
            Surface(
                onClick = { if (ref != null) openReader(ref.surah, ref.ayah) else openReader(1, 1) },
                shape = RoundedCornerShape(22.dp),
                color = Color.White.copy(alpha = 0.12f),
                contentColor = Color.White,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (s != null) "كمّل القراءة" else "ابدأ القراءة",
                            style = MaterialTheme.typography.labelLarge,
                            color = Gold,
                        )
                        Text(
                            "سورة ${s?.name ?: surahs.first().name}",
                            fontFamily = QuranFont,
                            fontSize = 28.sp,
                        )
                        if (ref != null && parts != null) {
                            Text(
                                "الآية ${ref.ayah.toArabicDigits()} • الجزء ${parts.juzOf(ref).toArabicDigits()} • ${parts.hizbLabel(ref)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.8f),
                            )
                        }
                    }
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(Gold)
                            .padding(12.dp),
                    ) {
                        // في RTL السهم "للأمام" كيشير لليسار
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = DeepGreen)
                    }
                }
            }
        }
    }
}

@Composable
private fun Row3(
    badge: Int,
    title: String,
    subtitle: String,
    trailing: String?,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 3.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StarBadge(badge)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (trailing != null) {
            Text(
                trailing,
                fontFamily = QuranFont,
                fontSize = 22.sp,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 150.dp),
            )
        }
    }
}

private fun LazyListScope.surahList(surahs: List<Surah>, openReader: (Int, Int) -> Unit) {
    items(surahs, key = { "s${it.id}" }) { s ->
        Row3(
            badge = s.id,
            title = "${s.transliteration} • ${s.meaningFr}",
            subtitle = "${if (s.isMeccan) "مكية" else "مدنية"} • ${s.ayahs.size.toArabicDigits()} آية",
            trailing = s.name,
            onClick = { openReader(s.id, 1) },
        )
    }
}

private fun firstWords(surahs: List<Surah>, ref: AyahRef): String {
    val text = surahs.getOrNull(ref.surah - 1)?.ayahs?.getOrNull(ref.ayah - 1)?.text ?: return ""
    return text.split(" ").take(4).joinToString(" ") + "…"
}

private fun LazyListScope.juzList(parts: Parts, surahs: List<Surah>, openReader: (Int, Int) -> Unit) {
    items(parts.juz.size, key = { "j$it" }) { i ->
        val ref = parts.juz[i]
        Row3(
            badge = i + 1,
            title = "الجزء ${(i + 1).toArabicDigits()}",
            subtitle = "سورة ${surahs[ref.surah - 1].name} • الآية ${ref.ayah.toArabicDigits()}",
            trailing = firstWords(surahs, ref),
            onClick = { openReader(ref.surah, ref.ayah) },
        )
    }
}

private fun LazyListScope.hizbList(parts: Parts, surahs: List<Surah>, openReader: (Int, Int) -> Unit) {
    for (h in 0 until 60) {
        item(key = "h$h") {
            val ref = parts.rub[h * 4]
            Column {
                Row3(
                    badge = h + 1,
                    title = "الحزب ${(h + 1).toArabicDigits()} • الجزء ${(h / 2 + 1).toArabicDigits()}",
                    subtitle = "سورة ${surahs[ref.surah - 1].name} • الآية ${ref.ayah.toArabicDigits()}",
                    trailing = firstWords(surahs, ref),
                    onClick = { openReader(ref.surah, ref.ayah) },
                )
                // الأرباع ديال الحزب
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 66.dp, end = 12.dp, bottom = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    for (q in 1..3) {
                        val r = parts.rub[h * 4 + q]
                        Surface(
                            onClick = { openReader(r.surah, r.ayah) },
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(
                                QUARTER_NAMES[q],
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 1,
                                modifier = Modifier.padding(vertical = 6.dp, horizontal = 8.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}
