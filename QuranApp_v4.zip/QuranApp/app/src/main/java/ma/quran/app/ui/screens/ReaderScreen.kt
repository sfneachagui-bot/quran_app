package ma.quran.app.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.TextDecrease
import androidx.compose.material.icons.filled.TextIncrease
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import ma.quran.app.data.Ayah
import ma.quran.app.data.AyahRef
import ma.quran.app.data.Parts
import ma.quran.app.data.Settings
import ma.quran.app.data.Surah
import ma.quran.app.data.Translation
import ma.quran.app.data.toArabicDigits
import ma.quran.app.player.PlayerState
import ma.quran.app.ui.QuranViewModel
import ma.quran.app.ui.theme.DeepGreen
import ma.quran.app.ui.theme.Gold
import ma.quran.app.ui.theme.OrnamentDivider
import ma.quran.app.ui.theme.QuranFont
import ma.quran.app.ui.theme.StarPattern

private const val BASMALA = "بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ"

/** علامة نهاية الآية: ۝ متبوعة بالرقم (خط Amiri كيرسمها دائرة فيها الرقم) */
private fun ayahMark(n: Int) = "۝" + n.toArabicDigits()

/** مجموعة ديال الآيات كتتعرض فنص واحد متصل (وضع المصحف) */
private class Block(val ayahs: List<Ayah>) {
    val first get() = ayahs.first().number
    val last get() = ayahs.last().number
}

private fun makeBlocks(s: Surah, maxChars: Int = 420): List<Block> {
    val out = ArrayList<Block>()
    var cur = ArrayList<Ayah>()
    var len = 0
    for (a in s.ayahs) {
        if (cur.isNotEmpty() && len + a.text.length > maxChars) {
            out += Block(cur); cur = ArrayList(); len = 0
        }
        cur += a; len += a.text.length
    }
    if (cur.isNotEmpty()) out += Block(cur)
    return out
}

private fun Context.findActivity(): Activity? {
    var c = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@OptIn(FlowPreview::class, ExperimentalLayoutApi::class)
@Composable
fun ReaderScreen(
    vm: QuranViewModel,
    surahId: Int,
    startAyah: Int,
    onBack: () -> Unit,
    onOpenSurah: (Int) -> Unit,
) {
    val surahs by vm.surahs.collectAsStateWithLifecycle()
    val parts by vm.parts.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val bookmarks by vm.bookmarks.collectAsStateWithLifecycle()
    val player by vm.player.state.collectAsStateWithLifecycle()
    val surah = surahs.getOrNull(surahId - 1)
    val bookmarkSet = remember(bookmarks) { bookmarks.map { it.toString() }.toSet() }
    val cardMode = settings.cardMode

    var chrome by rememberSaveable { mutableStateOf(true) }
    var flash by remember { mutableStateOf(if (startAyah > 1) startAyah else 0) }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current

    // ---------- الشاشة الكاملة ----------
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    DisposableEffect(chrome) {
        val window = view.context.findActivity()?.window
        val ctrl = window?.let { WindowCompat.getInsetsController(it, view) }
        ctrl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (chrome) ctrl?.show(WindowInsetsCompat.Type.systemBars())
        else ctrl?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { ctrl?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    // كيتخباو الأزرار بوحدهم بعد 3 ثواني ملي كتحل السورة
    LaunchedEffect(surahId) {
        delay(3000)
        chrome = false
    }
    LaunchedEffect(flash) {
        if (flash > 0) { delay(2500); flash = 0 }
    }

    if (surah == null) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        return
    }

    val blocks = remember(surah) { makeBlocks(surah) }
    val blockOf = remember(blocks) {
        IntArray(surah.ayahs.size + 1).also { arr -> blocks.forEachIndexed { i, b -> b.ayahs.forEach { arr[it.number] = i } } }
    }
    val layouts = remember(blocks) { HashMap<Int, TextLayoutResult>() }
    val ranges = remember(blocks) { HashMap<Int, List<Pair<Int, IntRange>>>() }
    val listState = rememberLazyListState()

    // رقم العنصر فالقائمة (0 = رأس السورة)
    fun itemOf(ayah: Int) = if (cardMode) ayah else blockOf[ayah] + 1

    suspend fun scrollToAyah(ayah: Int, animate: Boolean) {
        val idx = itemOf(ayah)
        var offset = 0
        if (!cardMode) {
            val b = blockOf[ayah]
            val start = ranges[b]?.firstOrNull { it.first == ayah }?.second?.first
            val layout = layouts[b]
            if (start != null && layout != null) {
                val line = layout.getLineForOffset(start)
                offset = (layout.getLineTop(line) - with(density) { 90.dp.toPx() }).toInt().coerceAtLeast(0)
            }
        }
        if (animate) listState.animateScrollToItem(idx, offset) else listState.scrollToItem(idx, offset)
    }

    /** الآية اللي فوق ديال الشاشة (لحفظ آخر قراءة والجزء/الحزب) */
    fun ayahAtTop(): Int {
        val i = listState.firstVisibleItemIndex
        if (i == 0) return 1
        if (cardMode) return i.coerceIn(1, surah.ayahs.size)
        val b = (i - 1).coerceIn(0, blocks.lastIndex)
        val layout = layouts[b] ?: return blocks[b].first
        val y = listState.firstVisibleItemScrollOffset.toFloat()
        val off = layout.getOffsetForPosition(androidx.compose.ui.geometry.Offset(layout.size.width / 2f, y))
        return ranges[b]?.firstOrNull { off <= it.second.last }?.first ?: blocks[b].first
    }

    // أول مرة: سير للآية المطلوبة
    LaunchedEffect(surahId, cardMode) {
        if (startAyah > 1) {
            scrollToAyah(startAyah, animate = false)
            delay(80) // تسنى حتى يتحسب شكل النص باش نوصلو للسطر بالضبط
            scrollToAyah(startAyah, animate = false)
        }
    }

    // حفظ آخر قراءة
    LaunchedEffect(surahId, cardMode) {
        snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
            .debounce(800)
            .collect { vm.saveLastRead(AyahRef(surahId, ayahAtTop())) }
    }

    // تتبع المقرئ: كننزلو مع الآية اللي كتتقرا
    LaunchedEffect(player.current, cardMode) {
        val cur = player.current ?: return@LaunchedEffect
        if (cur.surah == surahId) scrollToAyah(cur.ayah, animate = true)
    }

    val topRef by remember(surahId, cardMode) {
        androidx.compose.runtime.derivedStateOf {
            listState.firstVisibleItemIndex.let { AyahRef(surahId, ayahAtTop()) }
        }
    }

    val playing = player.current?.takeIf { it.surah == surahId }?.ayah ?: 0
    val topPad = WindowInsets.statusBarsIgnoringVisibility.asPaddingValues().calculateTopPadding() + 64.dp
    val bottomPad = WindowInsets.navigationBarsIgnoringVisibility.asPaddingValues().calculateBottomPadding() + 96.dp

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(top = topPad, bottom = bottomPad),
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) { detectTapGestures(onTap = { chrome = !chrome }) },
        ) {
            item(key = "header") { SurahHeader(surah) }
            if (cardMode) {
                items(surah.ayahs, key = { it.key }) { a ->
                    AyahCard(
                        ayah = a,
                        settings = settings,
                        highlighted = a.number == playing || a.number == flash,
                        isBookmarked = a.key in bookmarkSet,
                        isQuarter = parts?.isQuarterStart(AyahRef(a.surah, a.number)) == true,
                        onTap = { chrome = !chrome },
                        onLongPress = { vm.openAyahMenu(a) },
                    )
                }
            } else {
                items(blocks.size, key = { "b$it" }) { i ->
                    val block = blocks[i]
                    val hl = when {
                        playing in block.first..block.last -> playing
                        flash in block.first..block.last -> flash
                        else -> 0
                    }
                    MushafBlock(
                        index = i,
                        block = block,
                        settings = settings,
                        highlight = hl,
                        bookmarkSet = bookmarkSet,
                        parts = parts,
                        layouts = layouts,
                        ranges = ranges,
                        onTap = { chrome = !chrome },
                        onLongPress = { vm.openAyahMenu(it) },
                    )
                }
            }
            item(key = "footer") {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (surahId > 1) TextButton(onClick = { onOpenSurah(surahId - 1) }) {
                        Text("السورة السابقة")
                    } else Spacer(Modifier)
                    if (surahId < 114) FilledTonalButton(onClick = { onOpenSurah(surahId + 1) }) {
                        Text("السورة التالية: ${surahs[surahId].name}")
                    }
                }
            }
        }

        // ---------- الشريط الفوقاني ----------
        AnimatedVisibility(
            visible = chrome,
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter),
        ) {
            ReaderTopBar(
                surah = surah,
                info = parts?.let { "الجزء ${it.juzOf(topRef).toArabicDigits()} • ${it.hizbLabel(topRef)}" } ?: "",
                cardMode = cardMode,
                onBack = onBack,
                onToggleMode = { vm.setCardMode(!cardMode) },
            )
        }

        // ---------- الشريط التحتاني: المقرئ + حجم الخط ----------
        AnimatedVisibility(
            visible = chrome,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            ReaderBottomBar(
                player = player,
                surahId = surahId,
                reciterName = settings.reciter.name,
                onPlaySurah = { vm.play(surah, topRef.ayah) },
                vm = vm,
                fontSize = settings.fontSize,
            )
        }

        // زر صغير ملي الأزرار مخبيين والتلاوة خدامة
        AnimatedVisibility(
            visible = !chrome && player.current != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomStart)
                .navigationBarsPadding()
                .padding(16.dp),
        ) {
            SmallFloatingActionButton(
                onClick = vm.player::togglePlay,
                containerColor = DeepGreen,
                contentColor = Gold,
            ) {
                Icon(if (player.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "تشغيل/إيقاف")
            }
        }
    }
}

@Composable
private fun ReaderTopBar(
    surah: Surah,
    info: String,
    cardMode: Boolean,
    onBack: () -> Unit,
    onToggleMode: () -> Unit,
) {
    Box(
        Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B3D26), DeepGreen))),
    ) {
        StarPattern(Modifier.matchParentSize())
        Row(
            Modifier
                .statusBarsPadding()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = Color.White) }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("سورة ${surah.name}", fontFamily = QuranFont, fontSize = 24.sp, color = Gold)
                Text(info, style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.85f))
            }
            IconButton(onClick = onToggleMode) {
                Icon(
                    if (cardMode) Icons.Filled.AutoStories else Icons.Filled.ViewAgenda,
                    if (cardMode) "وضع المصحف" else "آية بآية مع الترجمة",
                    tint = Color.White,
                )
            }
        }
    }
}

@Composable
private fun ReaderBottomBar(
    player: PlayerState,
    surahId: Int,
    reciterName: String,
    onPlaySurah: () -> Unit,
    vm: QuranViewModel,
    fontSize: Float,
) {
    val active = player.current?.surah == surahId
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        tonalElevation = 4.dp,
        shadowElevation = 8.dp,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (active) "الآية ${player.current!!.ayah.toArabicDigits()}" else "استمع للسورة",
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Text(
                        if (active) player.reciterName else reciterName,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    )
                }
                if (active) {
                    IconButton(onClick = vm.player::toggleRepeatAyah) {
                        Icon(
                            Icons.Filled.RepeatOne, "تكرار الآية",
                            tint = if (player.repeatAyah) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f),
                        )
                    }
                    // RTL: السابق على اليمين
                    IconButton(onClick = vm.player::previous) { Icon(Icons.Filled.SkipNext, "الآية السابقة") }
                }
                Box(contentAlignment = Alignment.Center) {
                    if (active && player.isBuffering) CircularProgressIndicator(Modifier.size(48.dp), strokeWidth = 2.dp)
                    FilledIconButton(
                        onClick = { if (active) vm.player.togglePlay() else onPlaySurah() },
                        modifier = Modifier.size(44.dp),
                    ) {
                        Icon(if (active && player.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "تشغيل")
                    }
                }
                if (active) {
                    IconButton(onClick = vm.player::next) { Icon(Icons.Filled.SkipPrevious, "الآية التالية") }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("حجم الخط", style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = { vm.setFontSize((fontSize - 2f).coerceAtLeast(18f)) }) {
                    Icon(Icons.Filled.TextDecrease, "تصغير الخط")
                }
                Text(fontSize.toInt().toArabicDigits(), style = MaterialTheme.typography.labelLarge)
                IconButton(onClick = { vm.setFontSize((fontSize + 2f).coerceAtMost(44f)) }) {
                    Icon(Icons.Filled.TextIncrease, "تكبير الخط")
                }
            }
        }
    }
}

@Composable
private fun SurahHeader(s: Surah) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.linearGradient(listOf(Color(0xFF0B3D26), DeepGreen, Color(0xFF1C7A4D))),
                    RoundedCornerShape(20.dp),
                ),
            contentAlignment = Alignment.Center,
        ) {
            StarPattern(Modifier.matchParentSize())
            Column(
                Modifier.padding(vertical = 14.dp, horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("سورة ${s.name}", fontFamily = QuranFont, fontSize = 32.sp, color = Gold)
                Text(
                    "${if (s.isMeccan) "مكية" else "مدنية"} • ${s.ayahs.size.toArabicDigits()} آية",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.White.copy(alpha = 0.85f),
                )
            }
        }
        // الفاتحة: البسملة هي الآية 1، والتوبة بلا بسملة
        if (s.id != 1 && s.id != 9) {
            Spacer(Modifier.height(14.dp))
            Text(BASMALA, fontFamily = QuranFont, fontSize = 26.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(6.dp))
        OrnamentDivider(Modifier.width(160.dp).height(12.dp))
    }
}

@Composable
private fun MushafBlock(
    index: Int,
    block: Block,
    settings: Settings,
    highlight: Int,
    bookmarkSet: Set<String>,
    parts: Parts?,
    layouts: HashMap<Int, TextLayoutResult>,
    ranges: HashMap<Int, List<Pair<Int, IntRange>>>,
    onTap: () -> Unit,
    onLongPress: (Ayah) -> Unit,
) {
    val markColor = MaterialTheme.colorScheme.primary
    val hlColor = MaterialTheme.colorScheme.secondaryContainer
    val quarterColor = MaterialTheme.colorScheme.secondary
    val text: AnnotatedString = remember(block, highlight, bookmarkSet, parts, markColor, hlColor) {
        val rs = ArrayList<Pair<Int, IntRange>>()
        val str = buildAnnotatedString {
            for (a in block.ayahs) {
                val start = length
                if (parts?.isQuarterStart(AyahRef(a.surah, a.number)) == true && !(a.surah == 1 && a.number == 1)) {
                    pushStyle(SpanStyle(color = quarterColor))
                    append("۞ ")
                    pop()
                }
                append(a.text)
                append(" ")
                pushStyle(SpanStyle(color = if (a.key in bookmarkSet) Gold else markColor))
                append(ayahMark(a.number))
                pop()
                val end = length
                append(" ")
                rs += a.number to (start until end)
                if (a.number == highlight) addStyle(SpanStyle(background = hlColor), start, end)
            }
        }
        ranges[index] = rs
        str
    }
    Text(
        text = text,
        fontFamily = QuranFont,
        fontSize = settings.fontSize.sp,
        lineHeight = (settings.fontSize * 2.0f).sp,
        textAlign = TextAlign.Justify,
        onTextLayout = { layouts[index] = it },
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp)
            .pointerInput(block) {
                detectTapGestures(
                    onTap = { onTap() },
                    onLongPress = { pos ->
                        val layout = layouts[index] ?: return@detectTapGestures
                        val off = layout.getOffsetForPosition(pos)
                        val num = ranges[index]?.firstOrNull { off <= it.second.last }?.first ?: return@detectTapGestures
                        block.ayahs.firstOrNull { it.number == num }?.let(onLongPress)
                    },
                )
            },
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AyahCard(
    ayah: Ayah,
    settings: Settings,
    highlighted: Boolean,
    isBookmarked: Boolean,
    isQuarter: Boolean,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
) {
    val bg by animateColorAsState(
        if (highlighted) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.5f),
        label = "ayahBg",
    )
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .background(bg, RoundedCornerShape(18.dp))
            .combinedClickable(onClick = onTap, onLongClick = onLongPress)
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        Text(
            buildAnnotatedString {
                if (isQuarter && !(ayah.surah == 1 && ayah.number == 1)) {
                    pushStyle(SpanStyle(color = MaterialTheme.colorScheme.secondary)); append("۞ "); pop()
                }
                append(ayah.text)
                append(" ")
                pushStyle(SpanStyle(color = if (isBookmarked) Gold else MaterialTheme.colorScheme.primary))
                append(ayahMark(ayah.number))
                pop()
            },
            fontFamily = QuranFont,
            fontSize = settings.fontSize.sp,
            lineHeight = (settings.fontSize * 1.9f).sp,
            textAlign = TextAlign.Right,
            modifier = Modifier.fillMaxWidth(),
        )
        val tr = when (settings.translation) {
            Translation.FR -> ayah.fr
            Translation.EN -> ayah.en
            Translation.NONE -> null
        }
        if (tr != null) {
            Spacer(Modifier.height(6.dp))
            Text(
                tr,
                style = MaterialTheme.typography.bodyMedium.copy(textDirection = TextDirection.Ltr),
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f),
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}
