package ma.quran.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ma.quran.app.data.toArabicDigits
import ma.quran.app.ui.QuranViewModel
import ma.quran.app.ui.theme.QuranFont

@Composable
fun SearchScreen(vm: QuranViewModel, openReader: (Int, Int) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val results by vm.searchResults.collectAsStateWithLifecycle()
    val surahs by vm.surahs.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it; vm.search(it) },
            placeholder = { Text("ابحث بكلمة من القرآن أو من الترجمة…") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { query = ""; vm.search("") }) {
                    Icon(Icons.Filled.Close, "مسح")
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().padding(16.dp),
        )
        if (query.trim().length >= 2) {
            Text(
                "${results.size.toArabicDigits()} نتيجة",
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(horizontal = 20.dp),
            )
        }
        if (query.trim().length >= 2 && results.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text("ما كاين حتى نتيجة", textAlign = TextAlign.Center)
            }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(results, key = { it.key }) { a ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable { openReader(a.surah, a.number) }
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                ) {
                    Text(
                        "سورة ${surahs.getOrNull(a.surah - 1)?.name.orEmpty()} • الآية ${a.number.toArabicDigits()}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        a.text,
                        fontFamily = QuranFont,
                        fontSize = 22.sp,
                        lineHeight = 40.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            }
        }
    }
}
