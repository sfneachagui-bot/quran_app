package ma.quran.app.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ma.quran.app.data.toArabicDigits
import kotlin.math.cos
import kotlin.math.sin

/** نجمة ثمانية (بحال ۞) : جوج مربعات، واحد مدور بـ 45 درجة */
fun starPath(center: Offset, radius: Float): Path {
    val p = Path()
    for (k in 0 until 16) {
        val angle = Math.toRadians(-90.0 + k * 22.5)
        // الرؤوس (k زوجي) بعاد، والزوايا الداخلية (k فردي) قراب
        val r = if (k % 2 == 0) radius else radius * 0.76f
        val x = center.x + (r * cos(angle)).toFloat()
        val y = center.y + (r * sin(angle)).toFloat()
        if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    return p
}

fun DrawScope.drawStar(center: Offset, radius: Float, color: Color, stroke: Float? = null) {
    val path = starPath(center, radius)
    if (stroke == null) drawPath(path, color, style = Fill) else drawPath(path, color, style = Stroke(stroke))
}

/** خلفية فيها نجوم صغيرة مكررة (زخرفة خفيفة) */
@Composable
fun StarPattern(modifier: Modifier = Modifier, color: Color = Color.White.copy(alpha = 0.07f), cell: Dp = 44.dp) {
    Canvas(modifier) {
        val c = cell.toPx()
        var row = 0
        var y = 0f
        while (y < size.height + c) {
            var x = if (row % 2 == 0) 0f else c / 2
            while (x < size.width + c) {
                drawStar(Offset(x, y), c * 0.32f, color, stroke = 1.2.dp.toPx())
                x += c
            }
            y += c * 0.87f
            row++
        }
    }
}

/** شارة على شكل نجمة فيها رقم (للسور والأجزاء والأحزاب) */
@Composable
fun StarBadge(n: Int, modifier: Modifier = Modifier, size: Dp = 42.dp) {
    val fill = MaterialTheme.colorScheme.secondaryContainer
    val line = MaterialTheme.colorScheme.secondary
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val r = this.size.minDimension / 2
            drawStar(center, r * 0.98f, fill)
            drawStar(center, r * 0.98f, line, stroke = 1.3.dp.toPx())
            drawCircle(line.copy(alpha = 0.35f), radius = r * 0.62f, style = Stroke(0.8.dp.toPx()))
        }
        Text(
            n.toArabicDigits(),
            fontSize = if (n >= 100) 11.sp else 13.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
        )
    }
}

/** خط مزخرف: خط - نجمة - خط */
@Composable
fun OrnamentDivider(modifier: Modifier = Modifier, color: Color = Gold) {
    Canvas(modifier) {
        val cy = size.height / 2
        val cx = size.width / 2
        val r = size.height / 2
        drawLine(color.copy(alpha = 0.6f), Offset(0f, cy), Offset(cx - r * 1.6f, cy), 1.dp.toPx())
        drawLine(color.copy(alpha = 0.6f), Offset(cx + r * 1.6f, cy), Offset(size.width, cy), 1.dp.toPx())
        drawStar(Offset(cx, cy), r, color)
        drawCircle(color, r * 0.25f, Offset(cx - r * 2.3f, cy))
        drawCircle(color, r * 0.25f, Offset(cx + r * 2.3f, cy))
    }
}
