package ma.quran.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import ma.quran.app.R

val Gold = Color(0xFFD4AF37)
val DeepGreen = Color(0xFF0F5132)

val QuranFont = FontFamily(Font(R.font.amiri_quran))

private val Light = lightColorScheme(
    primary = DeepGreen,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD7EBDD),
    onPrimaryContainer = Color(0xFF062C1B),
    secondary = Color(0xFF9A7B1C),
    secondaryContainer = Color(0xFFF5E7B8),
    onSecondaryContainer = Color(0xFF3A2D00),
    background = Color(0xFFFBF5EA),
    surface = Color(0xFFFBF5EA),
    surfaceContainer = Color(0xFFF3EBDB),
    surfaceContainerHigh = Color(0xFFEDE3D0),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF8FD3A8),
    onPrimary = Color(0xFF00391F),
    primaryContainer = Color(0xFF1B4D33),
    onPrimaryContainer = Color(0xFFD7EBDD),
    secondary = Gold,
    secondaryContainer = Color(0xFF4A3B0B),
    onSecondaryContainer = Color(0xFFF5E7B8),
    background = Color(0xFF0E1512),
    surface = Color(0xFF0E1512),
    surfaceContainer = Color(0xFF17201B),
    surfaceContainerHigh = Color(0xFF1E2923),
)

@Composable
fun QuranTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
