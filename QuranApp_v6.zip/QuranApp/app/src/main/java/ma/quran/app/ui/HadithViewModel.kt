package ma.quran.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import ma.quran.app.QuranApplication
import ma.quran.app.data.CollectionMeta
import ma.quran.app.data.Hadith

data class SectionUi(
    val loading: Boolean = true,
    val hadiths: List<Hadith> = emptyList(),
    val error: String? = null,
)

@OptIn(ExperimentalCoroutinesApi::class)
class HadithViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as QuranApplication
    private val repo = a.hadith

    private val _meta = MutableStateFlow<List<CollectionMeta>>(emptyList())
    val meta: StateFlow<List<CollectionMeta>> = _meta.asStateFlow()

    /** id -> (الاسم، الأحاديث) */
    private val _offline = MutableStateFlow<Map<String, Pair<String, List<Hadith>>>>(emptyMap())
    val offline = _offline.asStateFlow()

    private val _ofDay = MutableStateFlow<Hadith?>(null)
    val hadithOfDay = _ofDay.asStateFlow()

    val favKeys = a.prefs.hadithFavs.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    val favorites: StateFlow<List<Hadith>?> = a.prefs.hadithFavs
        .mapLatest { keys -> keys.sorted().mapNotNull { runCatching { repo.find(it) }.getOrNull() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _section = MutableStateFlow(SectionUi())
    val section = _section.asStateFlow()

    init {
        // كل وحدة بوحدها، وإلا وقع شي مشكل فالمعطيات ما يطيحش التطبيق
        viewModelScope.launch { runCatching { _offline.value = repo.offline() } }
        viewModelScope.launch { runCatching { _meta.value = repo.meta() } }
        viewModelScope.launch { runCatching { _ofDay.value = repo.hadithOfDay() } }
    }

    fun name(id: String): String =
        _offline.value[id]?.first ?: _meta.value.firstOrNull { it.id == id }?.name ?: ""

    fun isCached(c: String, s: Int) = repo.isCached(c, s)

    fun loadSection(c: String, s: Int) {
        _section.value = SectionUi(loading = true)
        viewModelScope.launch {
            _section.value = repo.section(c, s).fold(
                { SectionUi(loading = false, hadiths = it) },
                { SectionUi(loading = false, error = "ما قدرناش نجيبو الأحاديث. تأكد من الأنترنيت (أول مرة فقط) وعاود.") },
            )
        }
    }

    fun toggleFav(h: Hadith) = viewModelScope.launch { a.prefs.toggleHadithFav(h.key) }
}
