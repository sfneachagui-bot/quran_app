package ma.quran.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("settings")

data class Settings(
    val fontSize: Float = 26f,
    val translation: Translation = Translation.FR,
    val reciterId: String = RECITERS.first().id,
    val tafsir: TafsirEdition = TafsirEdition.MUYASSAR,
    /** false = وضع المصحف (نص متصل بالشاشة كاملة)، true = آية بآية مع الترجمة */
    val cardMode: Boolean = false,
) {
    val reciter: Reciter get() = RECITERS.firstOrNull { it.id == reciterId } ?: RECITERS.first()
}

class PrefsRepository(private val context: Context) {
    private object K {
        val bookmarks = stringSetPreferencesKey("bookmarks")
        val lastRead = stringPreferencesKey("last_read")
        val fontSize = floatPreferencesKey("font_size")
        val translation = stringPreferencesKey("translation")
        val reciter = stringPreferencesKey("reciter")
        val tafsir = stringPreferencesKey("tafsir")
        val cardMode = booleanPreferencesKey("card_mode")
        val hadithFavs = stringSetPreferencesKey("hadith_favs")
        val kidsMemorized = stringSetPreferencesKey("kids_memorized")
        val kidsScores = stringSetPreferencesKey("kids_scores")
    }

    val bookmarks: Flow<List<AyahRef>> = context.dataStore.data.map { p ->
        (p[K.bookmarks] ?: emptySet()).mapNotNull { AyahRef.parse(it) }
            .sortedWith(compareBy({ it.surah }, { it.ayah }))
    }

    val hadithFavs: Flow<Set<String>> = context.dataStore.data.map { it[K.hadithFavs] ?: emptySet() }

    suspend fun toggleHadithFav(key: String) = context.dataStore.edit { p ->
        val cur = p[K.hadithFavs] ?: emptySet()
        p[K.hadithFavs] = if (key in cur) cur - key else cur + key
    }

    /** السور اللي حفظهم الطفل */
    val kidsMemorized: Flow<Set<Int>> = context.dataStore.data.map { p ->
        (p[K.kidsMemorized] ?: emptySet()).mapNotNull { it.toIntOrNull() }.toSet()
    }

    suspend fun toggleMemorized(surah: Int) = context.dataStore.edit { p ->
        val cur = p[K.kidsMemorized] ?: emptySet()
        val k = surah.toString()
        p[K.kidsMemorized] = if (k in cur) cur - k else cur + k
    }

    /** أحسن نتيجة فكل اختبار: id -> عدد النجوم (0..3) */
    val kidsScores: Flow<Map<String, Int>> = context.dataStore.data.map { p ->
        (p[K.kidsScores] ?: emptySet()).mapNotNull {
            val i = it.lastIndexOf('=')
            if (i < 0) null else it.substring(0, i) to (it.substring(i + 1).toIntOrNull() ?: 0)
        }.toMap()
    }

    suspend fun saveScore(id: String, stars: Int) = context.dataStore.edit { p ->
        val cur = (p[K.kidsScores] ?: emptySet())
        val old = cur.firstOrNull { it.startsWith("$id=") }
        val oldStars = old?.substringAfterLast('=')?.toIntOrNull() ?: -1
        if (stars > oldStars) p[K.kidsScores] = (cur - setOfNotNull(old)) + "$id=$stars"
    }

    val lastRead: Flow<AyahRef?> = context.dataStore.data.map { AyahRef.parse(it[K.lastRead]) }

    val settings: Flow<Settings> = context.dataStore.data.map { p ->
        Settings(
            fontSize = p[K.fontSize] ?: 26f,
            translation = p[K.translation]?.let { runCatching { Translation.valueOf(it) }.getOrNull() } ?: Translation.FR,
            reciterId = p[K.reciter] ?: RECITERS.first().id,
            tafsir = p[K.tafsir]?.let { runCatching { TafsirEdition.valueOf(it) }.getOrNull() } ?: TafsirEdition.MUYASSAR,
            cardMode = p[K.cardMode] ?: false,
        )
    }

    suspend fun toggleBookmark(ref: AyahRef) = context.dataStore.edit { p ->
        val cur = p[K.bookmarks] ?: emptySet()
        val k = ref.toString()
        p[K.bookmarks] = if (k in cur) cur - k else cur + k
    }

    suspend fun setLastRead(ref: AyahRef) = context.dataStore.edit { it[K.lastRead] = ref.toString() }
    suspend fun setFontSize(v: Float) = context.dataStore.edit { it[K.fontSize] = v }
    suspend fun setTranslation(t: Translation) = context.dataStore.edit { it[K.translation] = t.name }
    suspend fun setReciter(id: String) = context.dataStore.edit { it[K.reciter] = id }
    suspend fun setCardMode(v: Boolean) = context.dataStore.edit { it[K.cardMode] = v }
    suspend fun setTafsir(t: TafsirEdition) = context.dataStore.edit { it[K.tafsir] = t.name }
}
