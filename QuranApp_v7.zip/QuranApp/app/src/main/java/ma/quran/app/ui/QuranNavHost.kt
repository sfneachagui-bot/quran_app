package ma.quran.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.LocalLibrary
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import ma.quran.app.ui.screens.AyahMenuSheet
import ma.quran.app.ui.screens.ReciterPickerSheet
import ma.quran.app.ui.screens.BookmarksScreen
import ma.quran.app.ui.screens.KidsHomeScreen
import ma.quran.app.ui.screens.KidsLessonScreen
import ma.quran.app.ui.screens.KidsQuizListScreen
import ma.quran.app.ui.screens.KidsQuizScreen
import ma.quran.app.ui.screens.KidsSurahListScreen
import ma.quran.app.ui.screens.KidsSurahScreen
import ma.quran.app.ui.screens.HadithCollectionScreen
import ma.quran.app.ui.screens.HadithFavoritesScreen
import ma.quran.app.ui.screens.HadithHomeScreen
import ma.quran.app.ui.screens.HadithSectionScreen
import ma.quran.app.ui.screens.HomeScreen
import ma.quran.app.ui.screens.MiniPlayer
import ma.quran.app.ui.screens.ReaderScreen
import ma.quran.app.ui.screens.SearchScreen
import ma.quran.app.ui.screens.SettingsScreen
import ma.quran.app.ui.screens.TafsirSheet

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", "القرآن", Icons.AutoMirrored.Filled.MenuBook),
    Tab("hadith", "الحديث", Icons.Filled.LocalLibrary),
    Tab("kids", "الأطفال", Icons.Filled.ChildCare),
    Tab("bookmarks", "العلامات", Icons.Filled.Bookmarks),
    Tab("settings", "الإعدادات", Icons.Filled.Settings),
)

fun readerRoute(surah: Int, ayah: Int = 1) = "reader/$surah?ayah=$ayah"

@Composable
fun QuranNavHost() {
    val vm: QuranViewModel = viewModel()
    val hvm: HadithViewModel = viewModel()
    val kvm: KidsViewModel = viewModel()
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val onTab = tabs.any { it.route == route }
    val openReader: (Int, Int) -> Unit = { s, a -> nav.navigate(readerRoute(s, a)) }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            if (onTab) Column {
                MiniPlayer(vm = vm, onOpen = { ref -> openReader(ref.surah, ref.ayah) })
                run {
                    NavigationBar {
                        tabs.forEach { t ->
                            NavigationBarItem(
                                selected = route == t.route,
                                onClick = {
                                    nav.navigate(t.route) {
                                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(t.icon, null) },
                                label = { Text(t.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = MaterialTheme.colorScheme.secondaryContainer,
                                    selectedIconColor = MaterialTheme.colorScheme.onSecondaryContainer,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                ),
                            )
                        }
                    }
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = "home", modifier = Modifier.fillMaxSize().padding(padding)) {
            composable("home") { HomeScreen(vm, openReader, onSearch = { nav.navigate("search") }) }
            composable("kids") { KidsHomeScreen(kvm) { nav.navigate(it) } }
            composable("kids_surahs") { KidsSurahListScreen(kvm, vm, { nav.popBackStack() }) { nav.navigate(it) } }
            composable("kids_surah/{id}", arguments = listOf(navArgument("id") { type = NavType.IntType })) { e ->
                KidsSurahScreen(kvm, vm, e.arguments?.getInt("id") ?: 1, { nav.popBackStack() }) { nav.navigate(it) }
            }
            composable("kids_lesson/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                KidsLessonScreen(e.arguments?.getString("id").orEmpty(), { nav.popBackStack() }) { nav.navigate(it) }
            }
            composable("kids_quizzes") { KidsQuizListScreen(kvm, vm, { nav.popBackStack() }) { nav.navigate(it) } }
            composable("kids_quiz/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                KidsQuizScreen(kvm, vm, e.arguments?.getString("id").orEmpty()) { nav.popBackStack() }
            }
            composable("hadith") { HadithHomeScreen(hvm) { nav.navigate(it) } }
            composable(
                "hadith/{c}?n={n}",
                arguments = listOf(
                    navArgument("c") { type = NavType.StringType },
                    navArgument("n") { type = NavType.IntType; defaultValue = 0 },
                ),
            ) { e ->
                val c = e.arguments?.getString("c").orEmpty()
                HadithCollectionScreen(
                    hvm, c, e.arguments?.getInt("n") ?: 0,
                    onBack = { nav.popBackStack() },
                    openSection = { s -> nav.navigate("hadith_section/$c/$s") },
                )
            }
            composable(
                "hadith_section/{c}/{s}",
                arguments = listOf(
                    navArgument("c") { type = NavType.StringType },
                    navArgument("s") { type = NavType.IntType },
                ),
            ) { e ->
                HadithSectionScreen(hvm, e.arguments?.getString("c").orEmpty(), e.arguments?.getInt("s") ?: 1) { nav.popBackStack() }
            }
            composable("hadith_favs") { HadithFavoritesScreen(hvm) { nav.popBackStack() } }
            composable("search") { SearchScreen(vm, openReader) }
            composable("bookmarks") { BookmarksScreen(vm, openReader) }
            composable("settings") { SettingsScreen(vm) }
            composable(
                "reader/{surah}?ayah={ayah}",
                arguments = listOf(
                    navArgument("surah") { type = NavType.IntType },
                    navArgument("ayah") { type = NavType.IntType; defaultValue = 1 },
                ),
            ) { e ->
                ReaderScreen(
                    vm = vm,
                    surahId = e.arguments?.getInt("surah") ?: 1,
                    startAyah = e.arguments?.getInt("ayah") ?: 1,
                    onBack = { nav.popBackStack() },
                    onOpenSurah = { s -> nav.navigate(readerRoute(s)) { popUpTo("reader/{surah}?ayah={ayah}") { inclusive = true } } },
                )
            }
        }
    }
    TafsirSheet(vm)
    AyahMenuSheet(vm)
    ReciterPickerSheet(vm)

    // لون أيقونات شريط الحالة: فاتح فوق الأخضر (الرئيسية والقراءة)، غامق فالباقي
    val view = LocalView.current
    val dark = isSystemInDarkTheme()
    LaunchedEffect(route, dark) {
        val window = (view.context as? Activity)?.window ?: return@LaunchedEffect
        val onGreen = route == "home" || route?.startsWith("reader") == true || route?.startsWith("hadith") == true || route?.startsWith("kids") == true
        WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !onGreen && !dark
    }
}
