// أفعال مشتركة: اختيار المقرئ والتشغيل، قائمة الآية، التفسير
import { ar, esc, icon, openSheet, closeSheet, copyText, shareText, toast, spinner } from "./util.js";
import { RECITERS, settings, setSetting, ayahUrl, Q, toggleBookmark, bookmarks, TAFSIRS, tafsir, warshReciters, surahUrl, surahName } from "./data.js";
import { playQueue } from "./player.js";

/** قبل التشغيل كنطلبو المقرئ (حفص، آية بآية) */
export function playHafs(surahId, from = 1) {
  const s = Q.surahs[surahId - 1];
  const list = [...RECITERS].sort((a, b) => (b.id === settings.reciter) - (a.id === settings.reciter));
  openSheet(`<h3>اختار المقرئ</h3>
    <div class="muted" style="margin:0 20px 8px">سورة ${esc(s.name)} • من الآية ${ar(from)}</div>
    <div class="search-box" style="margin:8px 16px">${icon("search")}<input id="rq" placeholder="ابحث عن مقرئ…"></div>
    <div id="rl"></div>`, (sh) => {
    const draw = (q = "") => {
      sh.querySelector("#rl").innerHTML = list.filter((r) => !q || r.name.includes(q.trim())).map((r) =>
        `<button class="item" data-id="${r.id}">${icon("play")}<span style="${r.id === settings.reciter ? "font-weight:700" : ""}">${esc(r.name)}${r.id === settings.reciter ? "  ✓" : ""}</span></button>`).join("");
    };
    draw();
    sh.querySelector("#rq").oninput = (e) => draw(e.target.value);
    sh.querySelector("#rl").onclick = (e) => {
      const b = e.target.closest("[data-id]"); if (!b) return;
      const r = RECITERS.find((x) => x.id === b.dataset.id);
      setSetting("reciter", r.id);
      closeSheet();
      playQueue(s.ayahs.map((a) => ({
        id: `${s.id}:${a.n}`, ref: [s.id, a.n], url: ayahUrl(r, s.id, a.n),
        title: `سورة ${s.name} - الآية ${a.n}`, artist: r.name, album: `سورة ${s.name}`,
      })), from - 1);
    };
  });
}

/** ورش: السورة كاملة من mp3quran.net */
export function playWarsh(surahId) {
  openSheet(`<h3>اختار مقرئ برواية ورش</h3><div class="muted" style="margin:0 20px 8px">السورة كاملة • الآية اللي كتتقرا ما كتتلونش فورش</div><div id="wl">${spinner()}</div>`, async (sh) => {
    const box = sh.querySelector("#wl");
    try {
      const list = (await warshReciters()).filter((r) => !r.surahs.size || r.surahs.has(surahId))
        .sort((a, b) => (b.id === settings.warshReciter) - (a.id === settings.warshReciter));
      box.innerHTML = list.map((r) => `<button class="item" data-id="${r.id}">${icon("play")}<span>${esc(r.name)}${r.id === settings.warshReciter ? "  ✓" : ""}</span></button>`).join("");
      box.onclick = (e) => {
        const b = e.target.closest("[data-id]"); if (!b) return;
        const r = list.find((x) => x.id === b.dataset.id);
        setSetting("warshReciter", r.id);
        closeSheet();
        const name = surahName("warsh", surahId);
        playQueue([{ id: `full:${surahId}`, full: surahId, url: surahUrl(r, surahId), title: `سورة ${name} (ورش)`, artist: r.name, album: `سورة ${name}` }]);
      };
    } catch {
      box.innerHTML = `<div class="empty">ما قدرناش نجيبو لائحة القراء. تأكد من الأنترنيت وعاود.<br><br><button class="btn" id="rt">عاود المحاولة</button></div>`;
      box.querySelector("#rt").onclick = () => { closeSheet(); warshReciters(true).catch(() => {}); playWarsh(surahId); };
    }
  });
}

export const shareAyah = (a) => `${a.text} ﴿${ar(a.n)}﴾\n[سورة ${Q.surahs[a.s - 1].name} - الآية ${ar(a.n)}]`;

/** قائمة الآية */
export function ayahMenu(a, onChange) {
  const key = `${a.s}:${a.n}`;
  const marked = bookmarks().includes(key);
  openSheet(`<h3>سورة ${esc(Q.surahs[a.s - 1].name)} • الآية ${ar(a.n)}</h3>
    <div class="quran" style="margin:0 20px 8px;font-size:22px;line-height:1.9;color:var(--primary);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">${esc(a.text)}</div>
    <button class="item" data-a="play">${icon("play")}استمع من هذه الآية</button>
    <button class="item" data-a="tafsir">${icon("book")}التفسير</button>
    <button class="item" data-a="bm">${icon("bookmark")}${marked ? "حذف العلامة" : "إضافة علامة"}</button>
    <button class="item" data-a="copy">${icon("copy")}نسخ الآية</button>
    <button class="item" data-a="share">${icon("share")}مشاركة</button>`, (sh, close) => {
    sh.onclick = (e) => {
      const b = e.target.closest("[data-a]"); if (!b) return;
      const act = b.dataset.a;
      close();
      if (act === "play") playHafs(a.s, a.n);
      if (act === "tafsir") openTafsir(a);
      if (act === "bm") { const on = toggleBookmark(key); toast(on ? "تزادت العلامة 🔖" : "تحيدات العلامة"); onChange?.(); }
      if (act === "copy") copyText(shareAyah(a));
      if (act === "share") shareText(shareAyah(a));
    };
  });
}

/** التفسير (الميسر، الجلالين، المختصر بالفرنسية) */
export function openTafsir(a, edition = settings.tafsir) {
  openSheet(`<h3>تفسير سورة ${esc(Q.surahs[a.s - 1].name)} • الآية ${ar(a.n)}</h3>
    <div class="chips light" style="padding:0 16px 8px">${TAFSIRS.map((t) => `<button class="chip ${t.id === edition ? "on" : ""}" data-e="${t.id}">${t.label}</button>`).join("")}</div>
    <div class="quran" style="margin:4px 20px;font-size:24px;line-height:1.9;text-align:center;color:var(--primary)">${esc(a.text)}</div>
    <div class="body" id="tb">${spinner()}</div>`, async (sh) => {
    sh.querySelector(".chips").onclick = (e) => {
      const b = e.target.closest("[data-e]"); if (!b) return;
      setSetting("tafsir", b.dataset.e);
      openTafsir(a, b.dataset.e);
    };
    const tb = sh.querySelector("#tb");
    try {
      const t = await tafsir(edition, a.s, a.n);
      if (!tb.isConnected) return;
      const fr = TAFSIRS.find((x) => x.id === edition)?.fr;
      tb.className = "body" + (fr ? " ltr" : "");
      tb.innerHTML = esc(t || "—").replace(/\n/g, "<br>");
    } catch {
      if (tb.isConnected) tb.innerHTML = `<div class="empty">ما قدرناش نجيبو التفسير. تأكد من الأنترنيت (أول مرة فقط) وعاود.</div>`;
    }
  });
}
