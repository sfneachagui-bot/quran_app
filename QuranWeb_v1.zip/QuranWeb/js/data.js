// المعطيات: المصحف (حفص من quran.json، ورش من warsh.json)، الصفحات، الأجزاء، الإعدادات، العلامات، السجل
import { normalize, store, fetchJson } from "./util.js";

export const RECITERS = [
  ["alafasy", "مشاري راشد العفاسي", "Alafasy_128kbps"],
  ["abdulbasit", "عبد الباسط عبد الصمد (مرتل)", "Abdul_Basit_Murattal_192kbps"],
  ["abdulbasit_mj", "عبد الباسط عبد الصمد (مجود)", "Abdul_Basit_Mujawwad_128kbps"],
  ["husary", "محمود خليل الحصري", "Husary_128kbps"],
  ["husary_mj", "محمود خليل الحصري (مجود)", "Husary_128kbps_Mujawwad"],
  ["husary_mu", "محمود خليل الحصري (المصحف المعلم)", "Husary_Muallim_128kbps"],
  ["minshawy", "محمد صديق المنشاوي (مرتل)", "Minshawy_Murattal_128kbps"],
  ["minshawy_mj", "محمد صديق المنشاوي (مجود)", "Minshawy_Mujawwad_192kbps"],
  ["minshawy_t", "محمد صديق المنشاوي (المصحف المعلم)", "Minshawy_Teacher_128kbps"],
  ["maher", "ماهر المعيقلي", "MaherAlMuaiqly128kbps"],
  ["sudais", "عبد الرحمن السديس", "Abdurrahmaan_As-Sudais_192kbps"],
  ["shuraym", "سعود الشريم", "Saood_ash-Shuraym_128kbps"],
  ["ghamadi", "سعد الغامدي", "Ghamadi_40kbps"],
  ["shatri", "أبو بكر الشاطري", "Abu_Bakr_Ash-Shaatree_128kbps"],
  ["ajamy", "أحمد بن علي العجمي", "Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaballah.net"],
  ["dussary", "ياسر الدوسري", "Yasser_Ad-Dussary_128kbps"],
  ["qatami", "ناصر القطامي", "Nasser_Alqatami_128kbps"],
  ["hudhaify", "علي بن عبد الرحمن الحذيفي", "Hudhaify_128kbps"],
  ["budair", "صلاح البدير", "Salah_Al_Budair_128kbps"],
  ["juhany", "عبد الله عواد الجهني", "Abdullaah_3awwaad_Al-Juhaynee_128kbps"],
  ["basfar", "عبد الله بصفر", "Abdullah_Basfar_192kbps"],
  ["qahtani", "خالد القحطاني", "Khaalid_Abdullaah_al-Qahtaanee_192kbps"],
  ["rifai", "هاني الرفاعي", "Hani_Rifai_192kbps"],
  ["ayyoub", "محمد أيوب", "Muhammad_Ayyoub_128kbps"],
  ["jibreel", "محمد جبريل", "Muhammad_Jibreel_128kbps"],
  ["tablawi", "محمد محمود الطبلاوي", "Mohammad_al_Tablaway_128kbps"],
  ["bukhatir", "صلاح بوخاطر", "Salaah_AbdulRahman_Bukhatir_128kbps"],
  ["muhsin", "محسن القاسم", "Muhsin_Al_Qasim_192kbps"],
  ["fares", "فارس عباد", "Fares_Abbad_64kbps"],
  ["alijaber", "علي جابر", "Ali_Jaber_64kbps"],
  ["mustafa", "مصطفى إسماعيل", "Mustafa_Ismail_48kbps"],
  ["banna", "محمود علي البنا", "mahmoud_ali_al_banna_32kbps"],
  ["neana", "أحمد نعينع", "Ahmed_Neana_128kbps"],
  ["akhdar", "إبراهيم الأخضر", "Ibrahim_Akhdar_64kbps"],
  ["alili", "عزيز عليلي", "aziz_alili_128kbps"],
].map(([id, name, folder]) => ({ id, name, folder }));

export const ayahUrl = (r, s, a) =>
  `https://everyayah.com/data/${r.folder}/${String(s).padStart(3, "0")}${String(a).padStart(3, "0")}.mp3`;

export const TAFSIRS = [
  { id: "ar.muyassar", label: "التفسير الميسر" },
  { id: "ar.jalalayn", label: "تفسير الجلالين" },
  { id: "fr.mokhtasar", label: "Tafsir (Français)", fr: true },
];

// ───────────── الإعدادات ─────────────
const DEFAULTS = { fontSize: 26, translation: "fr", reciter: "alafasy", tafsir: "ar.muyassar", cardMode: false, riwaya: "hafs", theme: "auto", warshReciter: "" };
export const settings = { ...DEFAULTS, ...store.get("settings", {}) };
export function setSetting(k, v) { settings[k] = v; store.set("settings", settings); }
export const reciter = () => RECITERS.find((r) => r.id === settings.reciter) || RECITERS[0];

// ───────────── المصحف ─────────────
let quranP = null;
export const Q = { surahs: [], offsets: [], total: 0, parts: null };

export function loadQuran() {
  quranP ??= (async () => {
    const [raw, parts] = await Promise.all([fetchJson("data/quran.json"), fetchJson("data/parts.json")]);
    let acc = 0;
    Q.surahs = raw.map((s) => {
      const o = {
        id: s.id, name: s.name, tr: s.tr, meaning: s.meaning, meccan: s.type === "meccan",
        ayahs: s.verses.map((v, i) => ({ s: s.id, n: i + 1, text: v.ar, fr: v.fr, en: v.en, plain: null })),
      };
      Q.offsets.push(acc);
      acc += o.ayahs.length;
      return o;
    });
    Q.total = acc;
    Q.parts = { juz: parts.juz, rub: parts.rub };
    return Q;
  })();
  return quranP;
}

const cmp = (a, b) => a[0] - b[0] || a[1] - b[1];
function idxOf(list, ref) {
  let lo = 0, hi = list.length - 1, ans = 0;
  while (lo <= hi) { const m = (lo + hi) >> 1; if (cmp(list[m], ref) <= 0) { ans = m; lo = m + 1; } else hi = m - 1; }
  return ans;
}
export const juzOf = (s, a) => idxOf(Q.parts.juz, [s, a]) + 1;
export const rubOf = (s, a) => idxOf(Q.parts.rub, [s, a]) + 1;
export const isQuarterStart = (s, a) => Q.parts.rub.some((r) => r[0] === s && r[1] === a);
export const QUARTERS = ["بداية الحزب", "الربع", "النصف", "ثلاثة أرباع"];
export function hizbLabel(s, a) {
  const r = rubOf(s, a) - 1, h = String(Math.floor(r / 4) + 1).replace(/\d/g, (d) => "٠١٢٣٤٥٦٧٨٩"[d]);
  return ["الحزب ", "ربع الحزب ", "نصف الحزب ", "ثلاثة أرباع الحزب "][r % 4] + h;
}
export const globalIndex = (s, a) => (Q.offsets[s - 1] ?? 0) + a - 1;

// ───────────── البحث ─────────────
export function search(q, limit = 300) {
  q = q.trim();
  if (q.length < 2) return [];
  const isAr = /[؀-ۿ]/.test(q);
  const out = [];
  if (isAr) {
    const nq = normalize(q), sk = nq.replace(/ا/g, "");
    for (const s of Q.surahs) for (const a of s.ayahs) {
      a.plain ??= normalize(a.text);
      if (a.plain.includes(nq) || (sk.length >= 2 && a.plain.replace(/ا/g, "").includes(sk))) { out.push(a); if (out.length >= limit) return out; }
    }
  } else {
    const lq = q.toLowerCase();
    for (const s of Q.surahs) for (const a of s.ayahs) {
      if (a.fr.toLowerCase().includes(lq) || a.en.toLowerCase().includes(lq)) { out.push(a); if (out.length >= limit) return out; }
    }
  }
  return out;
}

// ───────────── الصفحات (604) ─────────────
const pagesCache = {};
const warshInfo = { names: [], counts: [] };
export async function mushafPages(riwaya) {
  if (pagesCache[riwaya]) return pagesCache[riwaya];
  if (riwaya === "warsh") {
    const raw = await fetchJson("data/warsh.json");
    const by = new Map();
    raw.forEach((su, si) => {
      warshInfo.names[si] = su.n;
      warshInfo.counts[si] = su.a.length;
      su.a.forEach(([text, pg], ai) => {
        if (!by.has(pg)) by.set(pg, []);
        by.get(pg).push({ s: si + 1, n: ai + 1, text });
      });
    });
    pagesCache.warsh = [...by.keys()].sort((a, b) => a - b).map((k) => ({ number: k, ayahs: by.get(k) }));
  } else {
    await loadQuran();
    const starts = await fetchJson("data/pages_hafs.json");
    const buckets = starts.map(() => []);
    let p = 0;
    for (const s of Q.surahs) for (const a of s.ayahs) {
      while (p + 1 < starts.length && cmp([s.id, a.n], starts[p + 1]) >= 0) p++;
      buckets[p].push({ s: s.id, n: a.n, text: a.text });
    }
    pagesCache.hafs = buckets.map((ayahs, i) => ({ number: i + 1, ayahs }));
  }
  return pagesCache[riwaya];
}
export const surahName = (riwaya, s) => (riwaya === "warsh" ? warshInfo.names[s - 1] : Q.surahs[s - 1]?.name) || "";

// ───────────── العلامات وآخر قراءة والسجل ─────────────
export const bookmarks = () => store.get("bookmarks", []);
export function toggleBookmark(key) {
  const b = new Set(bookmarks());
  b.has(key) ? b.delete(key) : b.add(key);
  store.set("bookmarks", [...b]);
  return b.has(key);
}
export const lastRead = () => store.get("lastRead", null);
export const today = () => new Date().toISOString().slice(0, 10);
export function saveLastRead(s, a) {
  const prev = lastRead();
  const log = store.get("log", {});
  if (prev && (prev[0] !== s || prev[1] !== a)) {
    const d = Math.min(40, Math.abs(globalIndex(s, a) - globalIndex(prev[0], prev[1])));
    if (d > 0) log[today()] = (log[today()] || 0) + d;
  } else if (!prev) log[today()] = (log[today()] || 0) + 1;
  // كنخليو غير آخر 90 يوم
  const keys = Object.keys(log).sort().slice(-90);
  store.set("log", Object.fromEntries(keys.map((k) => [k, log[k]])));
  store.set("lastRead", [s, a]);
}
export const readingLog = () => store.get("log", {});

// ───────────── كاش المعطيات من الأنترنيت (Cache API) ─────────────
export async function cachedJson(url) {
  try {
    const c = await caches.open("q-remote");
    const hit = await c.match(url);
    if (hit) return hit.json();
    const r = await fetch(url);
    if (!r.ok) throw new Error("HTTP " + r.status);
    await c.put(url, r.clone());
    return r.json();
  } catch (e) {
    // متصفح بلا Cache API
    if (typeof caches === "undefined") return fetchJson(url);
    throw e;
  }
}

/** التفسير: سورة كاملة فمرة، كيتخبا */
export async function tafsir(edition, s, a) {
  if (edition === "fr.mokhtasar") {
    const list = await cachedJson(`https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/french-mokhtasar/${s}.json`);
    return list.find((x) => x.ayah === a)?.text || "";
  }
  const j = await cachedJson(`https://api.alquran.cloud/v1/surah/${s}/${edition}`);
  return j.data.ayahs.find((x) => x.numberInSurah === a)?.text || "";
}

/** مقرئين ورش من mp3quran.net (السورة كاملة) */
let warshRecitersP = null;
export function warshReciters(force = false) {
  if (force) warshRecitersP = null;
  warshRecitersP ??= cachedJson("https://mp3quran.net/api/v3/reciters?language=ar").then((j) => {
    const out = [];
    for (const r of j.reciters || []) for (const m of r.moshaf || []) {
      if (!String(m.name || "").includes("ورش")) continue;
      const kind = String(m.name).split("-")[1]?.trim();
      out.push({
        id: `${r.id}-${m.id}`, name: kind ? `${r.name} (${kind})` : r.name, server: m.server,
        surahs: new Set(String(m.surah_list || "").split(",").map(Number).filter(Boolean)),
      });
    }
    if (!out.length) throw new Error("no warsh");
    return out.sort((a, b) => a.name.localeCompare(b.name, "ar"));
  }).catch((e) => { warshRecitersP = null; throw e; });
  return warshRecitersP;
}
export const surahUrl = (r, s) => r.server.replace(/\/?$/, "/") + String(s).padStart(3, "0") + ".mp3";
