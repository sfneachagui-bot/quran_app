// نقطة البداية: شاشة البداية، الراوتر (#/…)، شريط التنقل، المشغل، الـ Service Worker
import { $, $$, icon, particles, starPoints, closeSheet } from "./util.js";
import { initPlayer, setMiniOpen } from "./player.js";
import { settings } from "./data.js";

const TAB_ICONS = { home: "book", hadith: "library", duas: "hands", kids: "child", prayer: "mosque" };
const TABS = Object.keys(TAB_ICONS);

const ROUTES = [
  [/^home$/, "home"],
  [/^reader\/(\d+)(?:\/(\d+))?$/, "reader"],
  [/^search$/, "search"],
  [/^bookmarks$/, "search"],
  [/^mushaf(?:\/(\d+))?$/, "mushaf"],
  [/^downloads$/, "downloads"],
  [/^settings$/, "settings"],
  [/^prayer$/, "prayer"],
  [/^hadith(?:\/([\w-]+))?(?:\/(\d+))?$/, "hadith"],
  [/^hadith-favs$/, "hadith"],
  [/^duas$/, "duas"],
  [/^dua\/(\d+)$/, "duas"],
  [/^kids(?:\/([\w-]+))?(?:\/([\w-]+))?$/, "kids"],
];

let cleanup = null;
let renderId = 0;

async function route() {
  const path = (location.hash || "#/home").replace(/^#\/?/, "") || "home";
  let mod = "home", params = [];
  for (const [re, m] of ROUTES) {
    const r = path.match(re);
    if (r) { mod = m; params = r.slice(1); break; }
  }
  closeSheet();
  const id = ++renderId;
  const view = $("#view");
  try { cleanup?.(); } catch { /* */ }
  cleanup = null;
  const m = await import(`./views/${mod}.js`);
  if (id !== renderId) return;
  view.innerHTML = "";
  view.className = "";
  void view.offsetWidth;
  view.classList.add("view-enter");
  window.scrollTo(0, 0);
  const tab = TABS.includes(path.split("/")[0]) ? path.split("/")[0] : null;
  const onTab = tab && !path.includes("/");
  document.body.classList.toggle("no-tabs-page", !onTab);
  view.classList.toggle("no-tabs", !onTab);
  $("#tabbar").classList.toggle("hide", !onTab);
  setActiveTab(tab || (path.startsWith("reader") || path.startsWith("mushaf") || path === "search" || path === "bookmarks" ? "home" : null));
  cleanup = (await m.render(view, params, path)) || null;
}

function setActiveTab(tab) {
  const i = TABS.indexOf(tab);
  $$("#tabbar a").forEach((a) => a.classList.toggle("on", a.dataset.tab === tab));
  // فـ RTL التبويب الأول على اليمين
  if (i >= 0) $(".tab-indicator").style.transform = `translateX(${-i * 100}%)`;
}

function setupTabbar() {
  $$("#tabbar a").forEach((a) => ($(".ti", a).innerHTML = icon(TAB_ICONS[a.dataset.tab])));
}

/** شاشة البداية: النجمة كترسم براسها، الأشعة كدور، الغبار الذهبي */
function splash() {
  const el = $("#splash");
  if (sessionStorage.getItem("splashed")) { el.remove(); return; }
  sessionStorage.setItem("splashed", "1");
  const c = $("#splash-canvas");
  const stopDust = particles(c, { count: 40 });
  const star = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  star.setAttribute("viewBox", "0 0 220 220");
  star.style.cssText = "position:absolute;width:220px;height:220px;top:calc(50% - 170px);left:calc(50% - 110px)";
  const rays = Array.from({ length: 16 }, (_, k) => `<line x1="110" y1="60" x2="110" y2="0" stroke="url(#rg)" stroke-width="${k % 2 ? 1.5 : 3}" stroke-linecap="round" transform="rotate(${k * 22.5} 110 110)"/>`).join("");
  star.innerHTML = `<defs><linearGradient id="rg" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#D4AF37" stop-opacity=".45"/><stop offset="1" stop-color="#D4AF37" stop-opacity="0"/></linearGradient>
    <radialGradient id="halo"><stop offset="0" stop-color="#D4AF37" stop-opacity=".45"/><stop offset="1" stop-color="#D4AF37" stop-opacity="0"/></radialGradient></defs>
    <g style="transform-origin:110px 110px;animation:spin 20s linear infinite">${rays}</g>
    <circle cx="110" cy="110" r="80" fill="url(#halo)" style="opacity:0;animation:fadeUp .7s .9s forwards"/>
    <g style="transform-origin:110px 110px;animation:unrot 1.3s cubic-bezier(.3,.8,.3,1)">
      <polygon points="${starPoints(110, 110, 60)}" fill="#D4AF37" fill-opacity=".9" style="opacity:0;animation:fadeUp .7s .9s forwards"/>
      <polygon points="${starPoints(110, 110, 60)}" fill="none" stroke="#FFF4C2" stroke-width="3" stroke-linejoin="round" pathLength="100"
        style="stroke-dasharray:100;stroke-dashoffset:100;animation:draw 1.3s cubic-bezier(.4,.1,.2,1) forwards"/>
      <polygon points="${starPoints(110, 110, 37)}" fill="#0F5132" stroke="#D4AF37" stroke-width="1.5" style="opacity:0;animation:fadeUp .7s 1s forwards"/>
      <circle cx="110" cy="110" r="5" fill="#D4AF37"/></g>
    <style>@keyframes spin{to{transform:rotate(360deg)}}@keyframes draw{to{stroke-dashoffset:0}}@keyframes unrot{from{transform:rotate(-45deg)}}</style>`;
  el.appendChild(star);
  const done = () => { el.classList.add("gone"); setTimeout(() => { stopDust(); el.remove(); }, 500); };
  setTimeout(done, 3000);
  el.addEventListener("click", done, { once: true });
}

function applyTheme() {
  if (settings.theme === "auto") document.documentElement.removeAttribute("data-theme");
  else document.documentElement.dataset.theme = settings.theme;
}

window.addEventListener("hashchange", route);
document.addEventListener("DOMContentLoaded", () => {
  applyTheme();
  splash();
  setupTabbar();
  initPlayer();
  setMiniOpen((ref) => (location.hash = `#/reader/${ref[0]}/${ref[1]}`));
  route();
  if ("serviceWorker" in navigator && location.protocol !== "file:") {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  }
});
export { applyTheme };
