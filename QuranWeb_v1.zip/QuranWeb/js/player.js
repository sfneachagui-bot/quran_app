// المشغل: آية بآية (everyayah) ولا السورة كاملة (ورش) ولا الأدعية.
// إلا كان الملف محمل (Cache "q-audio") كنشغلوه من التلفون بلا أنترنيت.
import { $, icon, esc, ar, toast } from "./util.js";

const audio = () => $("#audio");
const listeners = new Set();
export const P = { queue: [], index: -1, playing: false, buffering: false, repeatOne: false };
let objectUrl = null;

export const onPlayer = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
const emit = () => { listeners.forEach((f) => f(P)); renderMini(); };
export const current = () => P.queue[P.index] || null;

async function resolve(url) {
  try {
    if (typeof caches === "undefined") return url;
    const c = await caches.open("q-audio");
    const hit = await c.match(url);
    if (!hit) return url;
    if (objectUrl) URL.revokeObjectURL(objectUrl);
    objectUrl = URL.createObjectURL(await hit.blob());
    return objectUrl;
  } catch { return url; }
}

async function load(i) {
  P.index = i;
  const it = current();
  if (!it) return stop();
  P.buffering = true; emit();
  const a = audio();
  a.src = await resolve(it.url);
  try { await a.play(); } catch (e) { P.buffering = false; P.playing = false; emit(); }
  updateSession(it);
}

export function playQueue(items, start = 0) {
  P.queue = items;
  load(Math.max(0, Math.min(start, items.length - 1)));
}
export function toggle() { const a = audio(); if (!current()) return; a.paused ? a.play() : a.pause(); }
export function next() { if (P.index + 1 < P.queue.length) load(P.index + 1); }
export function prev() { if (P.index > 0) load(P.index - 1); }
export function toggleRepeat() { P.repeatOne = !P.repeatOne; emit(); }
export function stop() {
  const a = audio(); a.pause(); a.removeAttribute("src"); a.load();
  P.queue = []; P.index = -1; P.playing = false; P.buffering = false; emit();
}

export function initPlayer() {
  const a = audio();
  a.addEventListener("playing", () => { P.playing = true; P.buffering = false; emit(); });
  a.addEventListener("pause", () => { P.playing = false; emit(); });
  a.addEventListener("waiting", () => { P.buffering = true; emit(); });
  a.addEventListener("ended", () => {
    if (P.repeatOne) { a.currentTime = 0; a.play(); return; }
    if (P.index + 1 < P.queue.length) load(P.index + 1);
    else { P.playing = false; emit(); }
  });
  a.addEventListener("error", () => {
    if (!current()) return;
    P.buffering = false; P.playing = false; emit();
    toast("ما قدرناش نشغلو الصوت، تأكد من الأنترنيت");
  });
  if ("mediaSession" in navigator) {
    const ms = navigator.mediaSession;
    ms.setActionHandler("play", () => a.play());
    ms.setActionHandler("pause", () => a.pause());
    ms.setActionHandler("nexttrack", next);
    ms.setActionHandler("previoustrack", prev);
  }
}

function updateSession(it) {
  if (!("mediaSession" in navigator) || !window.MediaMetadata) return;
  navigator.mediaSession.metadata = new MediaMetadata({
    title: it.title, artist: it.artist, album: it.album || "القرآن الكريم",
    artwork: [{ src: "icons/icon-512.png", sizes: "512x512", type: "image/png" }],
  });
}

// ───────────── المشغل الصغير ─────────────
let onOpen = null;
export const setMiniOpen = (fn) => (onOpen = fn);
function renderMini() {
  const el = $("#mini-player");
  const it = current();
  if (!it) { el.hidden = true; el.innerHTML = ""; return; }
  const wasHidden = el.hidden;
  el.hidden = false;
  el.classList.toggle("playing", P.playing);
  const head = it.ref ? `سورة ${esc(it.album.replace("سورة ", ""))} • الآية ${ar(it.ref[1])}` : (it.full ? `📖 ${esc(it.title)}` : `🤲 ${esc(it.title)}`);
  el.innerHTML = `
    <span class="eq"><i></i><i></i><i></i><i></i></span>
    <button class="info" data-a="open"><b>${head}</b><small>${esc(it.artist)}</small></button>
    <button class="ctl ${P.repeatOne ? "" : "off"}" data-a="rep" aria-label="تكرار">${icon("repeat")}</button>
    <button class="ctl" data-a="prev" aria-label="السابق">${icon("next")}</button>
    <button class="ctl main" data-a="toggle" aria-label="تشغيل">${P.buffering ? `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2.5" stroke-dasharray="40 20"><animateTransform attributeName="transform" type="rotate" from="0 12 12" to="360 12 12" dur="1s" repeatCount="indefinite"/></circle></svg>` : icon(P.playing ? "pause" : "play")}</button>
    <button class="ctl" data-a="next" aria-label="التالي">${icon("prev")}</button>
    <button class="ctl" data-a="close" aria-label="إغلاق">${icon("close")}</button>`;
  if (wasHidden) { el.style.animation = "none"; el.offsetHeight; el.style.animation = ""; }
  el.onclick = (e) => {
    const b = e.target.closest("[data-a]"); if (!b) return;
    ({ open: () => it.ref && onOpen?.(it.ref), rep: toggleRepeat, prev, next, toggle, close: stop })[b.dataset.a]?.();
  };
}

// ───────────── التحميل للاستماع بلا أنترنيت ─────────────
export async function isCached(url) {
  if (typeof caches === "undefined") return false;
  return !!(await (await caches.open("q-audio")).match(url));
}
/** كيحمل لائحة ديال الروابط، onProgress(0..1). كيرجع false إلا السيرفر ما كيسمحش */
export async function downloadAll(urls, onProgress, signal) {
  const c = await caches.open("q-audio");
  let done = 0;
  for (const u of urls) {
    if (signal?.aborted) throw new DOMException("aborted", "AbortError");
    if (!(await c.match(u))) {
      const r = await fetch(u, { mode: "cors", signal });
      if (!r.ok) throw new Error("HTTP " + r.status);
      await c.put(u, r);
    }
    onProgress?.(++done / urls.length);
  }
}
export async function deleteUrls(urls) {
  const c = await caches.open("q-audio");
  await Promise.all(urls.map((u) => c.delete(u)));
}
export async function usedMb() {
  try { const e = await navigator.storage?.estimate?.(); return e ? e.usage / 1048576 : 0; } catch { return 0; }
}
