// حساب مواقيت الصلاة فالتلفون بلا أنترنيت (طريقة PrayTimes) + اتجاه القبلة
export const METHODS = {
  morocco: { label: "المغرب (وزارة الأوقاف ١٩°/١٧°)", fajr: 19, isha: 17 },
  mwl: { label: "رابطة العالم الإسلامي (١٨°/١٧°)", fajr: 18, isha: 17 },
  ummalqura: { label: "أم القرى (مكة)", fajr: 18.5, ishaMin: 90 },
  egypt: { label: "الهيئة المصرية (١٩٫٥°/١٧٫٥°)", fajr: 19.5, isha: 17.5 },
  france: { label: "فرنسا UOIF (١٢°/١٢°)", fajr: 12, isha: 12 },
  isna: { label: "أمريكا الشمالية ISNA (١٥°/١٥°)", fajr: 15, isha: 15 },
};

export const PRAYERS = [
  ["fajr", "الفجر", "🌙"], ["sunrise", "الشروق", "🌅"], ["dhuhr", "الظهر", "☀️"],
  ["asr", "العصر", "🌤️"], ["maghrib", "المغرب", "🌇"], ["isha", "العشاء", "🌌"],
];

export const CITIES = [
  ["الدار البيضاء", 33.5731, -7.5898, "Africa/Casablanca"], ["الرباط", 34.0209, -6.8416, "Africa/Casablanca"],
  ["فاس", 34.0181, -5.0078, "Africa/Casablanca"], ["مراكش", 31.6295, -7.9811, "Africa/Casablanca"],
  ["طنجة", 35.7595, -5.834, "Africa/Casablanca"], ["أكادير", 30.4278, -9.5981, "Africa/Casablanca"],
  ["مكناس", 33.8935, -5.5473, "Africa/Casablanca"], ["وجدة", 34.6814, -1.9086, "Africa/Casablanca"],
  ["القنيطرة", 34.261, -6.5802, "Africa/Casablanca"], ["تطوان", 35.5785, -5.3684, "Africa/Casablanca"],
  ["الناظور", 35.1681, -2.9335, "Africa/Casablanca"], ["الحسيمة", 35.2517, -3.9372, "Africa/Casablanca"],
  ["الجديدة", 33.2316, -8.5007, "Africa/Casablanca"], ["آسفي", 32.2994, -9.2372, "Africa/Casablanca"],
  ["الصويرة", 31.5085, -9.7595, "Africa/Casablanca"], ["بني ملال", 32.3373, -6.3498, "Africa/Casablanca"],
  ["الرشيدية", 31.9314, -4.4248, "Africa/Casablanca"], ["ورزازات", 30.9189, -6.8934, "Africa/Casablanca"],
  ["العيون", 27.1253, -13.1625, "Africa/Casablanca"], ["الداخلة", 23.6848, -15.958, "Africa/Casablanca"],
  ["باريس", 48.8566, 2.3522, "Europe/Paris"], ["ليون", 45.764, 4.8357, "Europe/Paris"],
  ["مارسيليا", 43.2965, 5.3698, "Europe/Paris"], ["بروكسيل", 50.8503, 4.3517, "Europe/Brussels"],
  ["أمستردام", 52.3676, 4.9041, "Europe/Amsterdam"], ["مدريد", 40.4168, -3.7038, "Europe/Madrid"],
  ["برشلونة", 41.3874, 2.1686, "Europe/Madrid"], ["ميلانو", 45.4642, 9.19, "Europe/Rome"],
  ["مونتريال", 45.5017, -73.5673, "America/Toronto"], ["مكة المكرمة", 21.4225, 39.8262, "Asia/Riyadh"],
].map(([name, lat, lon, zone]) => ({ name, lat, lon, zone }));

const rad = (d) => (d * Math.PI) / 180, deg = (r) => (r * 180) / Math.PI;
const fix = (a, b) => { a -= b * Math.floor(a / b); return a < 0 ? a + b : a; };
function julian(y, m, d) {
  if (m <= 2) { y -= 1; m += 12; }
  const A = Math.floor(y / 100), B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
}
function sun(jd) {
  const D = jd - 2451545.0;
  const g = fix(357.529 + 0.98560028 * D, 360), q = fix(280.459 + 0.98564736 * D, 360);
  const L = fix(q + 1.915 * Math.sin(rad(g)) + 0.020 * Math.sin(rad(2 * g)), 360);
  const e = 23.439 - 0.00000036 * D;
  const RA = deg(Math.atan2(Math.cos(rad(e)) * Math.sin(rad(L)), Math.cos(rad(L)))) / 15;
  return { decl: deg(Math.asin(Math.sin(rad(e)) * Math.sin(rad(L)))), eqt: q / 15 - fix(RA, 24) };
}

/** الفرق بالساعات بين المنطقة الزمنية و UTC فداك النهار */
export function zoneOffset(zone, date) {
  try {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), 12));
    const parts = new Intl.DateTimeFormat("en-US", { timeZone: zone, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }).formatToParts(d);
    const v = Object.fromEntries(parts.map((p) => [p.type, p.value]));
    const asUtc = Date.UTC(+v.year, +v.month - 1, +v.day, +v.hour, +v.minute);
    return (asUtc - d.getTime()) / 3600000;
  } catch { return -date.getTimezoneOffset() / 60; }
}

/** كيرجع الدقائق من نص الليل لكل صلاة (بالتوقيت المحلي ديال المدينة) */
export function compute(date, lat, lon, zone, methodKey = "morocco", hanafi = false) {
  const m = METHODS[methodKey] || METHODS.morocco;
  const jDate = julian(date.getFullYear(), date.getMonth() + 1, date.getDate()) - lon / (15 * 24);
  const mid = (t) => fix(12 - sun(jDate + t).eqt, 24);
  const at = (angle, t, ccw) => {
    const { decl } = sun(jDate + t);
    const v = deg(Math.acos((-Math.sin(rad(angle)) - Math.sin(rad(decl)) * Math.sin(rad(lat))) / (Math.cos(rad(decl)) * Math.cos(rad(lat))))) / 15;
    return mid(t) + (ccw ? -v : v);
  };
  const asrT = (f, t) => { const { decl } = sun(jDate + t); return at(-deg(Math.atan(1 / (f + Math.tan(rad(Math.abs(lat - decl)))))), t, false); };
  let F = 5, S = 6, D = 12, A = 13, M = 18, I = 18;
  for (let k = 0; k < 2; k++) {
    F = at(m.fajr, F / 24, true); S = at(0.833, S / 24, true); D = mid(D / 24);
    A = asrT(hanafi ? 2 : 1, A / 24); M = at(0.833, M / 24, false);
    I = m.ishaMin ? M : at(m.isha, I / 24, false);
  }
  if (m.ishaMin) I = M + m.ishaMin / 60;
  // خطوط العرض العالية
  const night = fix(S - M + 24, 24);
  const fp = (m.fajr / 60) * night;
  if (Number.isNaN(F) || fix(S - F, 24) > fp) F = S - fp;
  if (!m.ishaMin) { const ip = (m.isha / 60) * night; if (Number.isNaN(I) || fix(I - M, 24) > ip) I = M + ip; }
  const off = zoneOffset(zone, date);
  const toMin = (h) => ((Math.round(fix(h + off - lon / 15, 24) * 60) % 1440) + 1440) % 1440;
  return { fajr: toMin(F), sunrise: toMin(S), dhuhr: toMin(D), asr: toMin(A), maghrib: toMin(M), isha: toMin(I) };
}

export function qibla(lat, lon) {
  const dl = rad(39.8262 - lon), p1 = rad(lat), p2 = rad(21.4225);
  return (deg(Math.atan2(Math.sin(dl), Math.cos(p1) * Math.tan(p2) - Math.sin(p1) * Math.cos(dl))) + 360) % 360;
}
export function distanceKm(lat, lon) {
  const dLat = rad(21.4225 - lat), dLon = rad(39.8262 - lon);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat)) * Math.cos(rad(21.4225)) * Math.sin(dLon / 2) ** 2;
  return 2 * 6371 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/** الوقت الحالي (بالدقائق والثواني) فالمنطقة الزمنية ديال المدينة */
export function nowIn(zone) {
  try {
    const parts = new Intl.DateTimeFormat("en-US", { timeZone: zone, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" }).formatToParts(new Date());
    const v = Object.fromEntries(parts.map((p) => [p.type, p.value]));
    return { date: new Date(+v.year, +v.month - 1, +v.day), sec: (+v.hour) * 3600 + (+v.minute) * 60 + (+v.second) };
  } catch {
    const d = new Date();
    return { date: new Date(d.getFullYear(), d.getMonth(), d.getDate()), sec: d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds() };
  }
}

export function hijri(date) {
  try {
    return new Intl.DateTimeFormat("ar-SA-u-ca-islamic-umalqura", { day: "numeric", month: "long", year: "numeric" }).format(date);
  } catch { return ""; }
}
