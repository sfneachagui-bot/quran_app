// أدوات مشتركة: الأرقام العربية، الأيقونات، النجوم، الزخارف، الورقة، الرسائل، التخزين

export const ar = (n) => String(n).replace(/\d/g, (d) => "٠١٢٣٤٥٦٧٨٩"[d]);
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
export const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// ───────────── التخزين (localStorage) ─────────────
export const store = {
  get(k, def) {
    try { const v = localStorage.getItem("q:" + k); return v == null ? def : JSON.parse(v); } catch { return def; }
  },
  set(k, v) { try { localStorage.setItem("q:" + k, JSON.stringify(v)); } catch { /* مساحة مملوءة */ } },
};

// ───────────── الأيقونات (SVG) ─────────────
const P = {
  book: "M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5zM4 21.5A2.5 2.5 0 0 0 6.5 22H20v-3",
  library: "M4 19V5m4 14V5m4 14 4-14 4 14M3 21h18",
  hands: "M7 11V6a1.5 1.5 0 0 1 3 0v4m0-1V4.5a1.5 1.5 0 0 1 3 0V10m0-4.5a1.5 1.5 0 0 1 3 0V12m0-4a1.5 1.5 0 0 1 3 0v6a7 7 0 0 1-7 7h-1a7 7 0 0 1-5.7-2.9L3.5 15a1.6 1.6 0 0 1 2.6-1.9L7 14",
  child: "M12 7a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm-5 15v-6l-2-5h14l-2 5v6M9 22v-4h6v4",
  mosque: "M3 21h18M5 21v-8h14v8M12 3c3 2 5 4 5 7H7c0-3 2-5 5-7zM12 1v2M10 21v-4a2 2 0 0 1 4 0v4M3 13V8m18 5V8",
  search: "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zm10 2-4.3-4.3",
  bookmark: "M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z",
  settings: "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm7.4-3a7.4 7.4 0 0 0-.1-1.2l2-1.6-2-3.4-2.4 1a7.3 7.3 0 0 0-2-1.2L14.5 3h-4l-.4 2.6a7.3 7.3 0 0 0-2 1.2l-2.4-1-2 3.4 2 1.6a7.4 7.4 0 0 0 0 2.4l-2 1.6 2 3.4 2.4-1a7.3 7.3 0 0 0 2 1.2l.4 2.6h4l.4-2.6a7.3 7.3 0 0 0 2-1.2l2.4 1 2-3.4-2-1.6c.1-.4.1-.8.1-1.2z",
  back: "M5 12h14m-6-6 6 6-6 6",
  forward: "M19 12H5m6-6-6 6 6 6",
  play: "M7 4v16l13-8z",
  pause: "M7 4h4v16H7zm6 0h4v16h-4z",
  next: "M17 5v14M4 5l10 7-10 7z",
  prev: "M7 5v14m13-14-10 7 10 7z",
  close: "M6 6l12 12M18 6 6 18",
  repeat: "M17 2l4 4-4 4M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4m14-1v2a3 3 0 0 1-3 3H3M12 10v4",
  list: "M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01",
  download: "M12 3v12m-5-5 5 5 5-5M5 21h14",
  check: "M4 12l5 5L20 6",
  trash: "M3 6h18M8 6V4h8v2m-9 0 1 14h8l1-14",
  copy: "M8 8h12v12H8zM4 16V4h12",
  share: "M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7M16 6l-4-4-4 4m4-4v14",
  info: "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zm0-6v-5m0-3h.01",
  location: "M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11zm0-8.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z",
  tune: "M4 6h10m4 0h2M4 12h4m4 0h8M4 18h12m4 0h0M14 4v4M8 10v4m8 2v4",
  text: "M4 7V5h16v2M9 19h6M12 5v14",
};
export function icon(name, extra = "") {
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ${extra}><path d="${P[name] || ""}"/></svg>`;
}
export function iconFill(name) {
  return `<svg viewBox="0 0 24 24" fill="currentColor"><path d="${P[name]}"/></svg>`;
}

// ───────────── النجمة الثمانية ─────────────
export function starPoints(cx, cy, r) {
  const pts = [];
  for (let k = 0; k < 16; k++) {
    const a = ((-90 + k * 22.5) * Math.PI) / 180;
    const rr = k % 2 === 0 ? r : r * 0.76;
    pts.push(`${(cx + rr * Math.cos(a)).toFixed(1)},${(cy + rr * Math.sin(a)).toFixed(1)}`);
  }
  return pts.join(" ");
}
export function starBadge(n, size = 42) {
  return `<span class="star-badge" style="width:${size}px;height:${size}px"><svg viewBox="0 0 42 42">
    <polygon points="${starPoints(21, 21, 20.5)}" fill="var(--sec-cont)" stroke="var(--gold-d)" stroke-width="1.3"/>
    <circle cx="21" cy="21" r="13" fill="none" stroke="var(--gold-d)" stroke-opacity=".35" stroke-width=".8"/></svg>
    <b style="font-size:${n >= 100 ? 11 : 13}px">${ar(n)}</b></span>`;
}
export function ornament() {
  return `<svg class="ornament" viewBox="0 0 180 14"><line x1="0" y1="7" x2="78" y2="7" stroke="#D4AF37" stroke-opacity=".6"/>
    <line x1="102" y1="7" x2="180" y2="7" stroke="#D4AF37" stroke-opacity=".6"/>
    <polygon points="${starPoints(90, 7, 7)}" fill="#D4AF37"/><circle cx="74" cy="7" r="1.8" fill="#D4AF37"/><circle cx="106" cy="7" r="1.8" fill="#D4AF37"/></svg>`;
}

/** زخرفة النجوم المتحركة (SVG pattern كيزلق) */
let patId = 0;
export function pattern(opacity = 0.08, cell = 46) {
  const id = "pat" + patId++;
  return `<div class="pattern"><svg><defs><pattern id="${id}" width="${cell}" height="${cell * 1.74}" patternUnits="userSpaceOnUse">
      <polygon points="${starPoints(0, 0, cell * 0.32)}" fill="none" stroke="#fff" stroke-opacity="${opacity}" stroke-width="1.2"/>
      <polygon points="${starPoints(cell, 0, cell * 0.32)}" fill="none" stroke="#fff" stroke-opacity="${opacity}" stroke-width="1.2"/>
      <polygon points="${starPoints(cell / 2, cell * 0.87, cell * 0.32)}" fill="none" stroke="#fff" stroke-opacity="${opacity}" stroke-width="1.2"/>
      <polygon points="${starPoints(0, cell * 1.74, cell * 0.32)}" fill="none" stroke="#fff" stroke-opacity="${opacity}" stroke-width="1.2"/>
      <polygon points="${starPoints(cell, cell * 1.74, cell * 0.32)}" fill="none" stroke="#fff" stroke-opacity="${opacity}" stroke-width="1.2"/>
    </pattern></defs><g class="drift"><rect x="-${cell * 2}" y="-${cell * 4}" width="200%" height="200%" fill="url(#${id})"/></g></svg></div>`;
}

/** غبار ذهبي كيطلع (canvas). كيرجع دالة باش نوقفوه */
export function particles(canvas, { count = 26, color = "212,175,55" } = {}) {
  const ctx = canvas.getContext("2d");
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  let w = 0, h = 0, raf = 0, alive = true;
  const ps = Array.from({ length: count }, (_, i) => ({ x: Math.random(), s: 0.4 + Math.random() * 0.8, r: 1.2 + Math.random() * 2.6, p: Math.random(), d: Math.random() * 2 - 1 }));
  const resize = () => {
    w = canvas.clientWidth; h = canvas.clientHeight;
    canvas.width = w * dpr; canvas.height = h * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };
  resize();
  const t0 = performance.now();
  const tick = (now) => {
    if (!alive) return;
    if (!canvas.isConnected) { alive = false; return; }
    if (canvas.clientWidth !== w || canvas.clientHeight !== h) resize();
    const time = ((now - t0) / 12000) % 1;
    ctx.clearRect(0, 0, w, h);
    for (const q of ps) {
      const prog = (time * q.s + q.p) % 1;
      const y = h * (1 - prog);
      const x = w * q.x + Math.sin(prog * 2 * Math.PI + q.p * 6) * 18 * q.d;
      const a = Math.max(0, Math.sin(prog * Math.PI));
      const tw = 0.6 + 0.4 * Math.sin((now / 300) + q.p * 10);
      ctx.fillStyle = `rgba(${color},${0.25 * a * tw})`; ctx.beginPath(); ctx.arc(x, y, q.r * 3, 0, 7); ctx.fill();
      ctx.fillStyle = `rgba(${color},${0.9 * a * tw})`; ctx.beginPath(); ctx.arc(x, y, q.r, 0, 7); ctx.fill();
    }
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);
  return () => { alive = false; cancelAnimationFrame(raf); };
}
/** كيزيد canvas ديال الغبار لعنصر */
export function addParticles(el, opts) {
  const c = document.createElement("canvas");
  c.className = "particles";
  el.prepend(c);
  requestAnimationFrame(() => particles(c, opts));
}

// ───────────── الورقة (bottom sheet) والرسائل ─────────────
let sheetClose = null;
export function openSheet(html, onMount) {
  const sheet = $("#sheet"), bd = $("#sheet-backdrop");
  sheet.innerHTML = html;
  sheet.hidden = false; bd.hidden = false;
  sheet.scrollTop = 0;
  const close = () => { sheet.hidden = true; bd.hidden = true; sheet.innerHTML = ""; sheetClose = null; };
  sheetClose = close;
  bd.onclick = close;
  onMount?.(sheet, close);
  return close;
}
export function closeSheet() { sheetClose?.(); }

let toastTimer = 0;
export function toast(msg, ms = 2400) {
  const t = $("#toast");
  t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), ms);
}

/** حلقة التقدم (SVG) */
export function ring(progress, size = 96, stroke = 9, track = "rgba(255,255,255,.15)") {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r;
  const id = "rg" + Math.random().toString(36).slice(2, 7);
  return `<svg viewBox="0 0 ${size} ${size}"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#F7E08B"/><stop offset=".5" stop-color="#D4AF37"/><stop offset="1" stop-color="#B8860B"/></linearGradient></defs>
    <circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="${track}" stroke-width="${stroke}"/>
    <circle class="arc" cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="url(#${id})" stroke-width="${stroke}" stroke-linecap="round"
      stroke-dasharray="${c.toFixed(1)}" stroke-dashoffset="${c.toFixed(1)}" data-target="${(c * (1 - Math.min(1, Math.max(0, progress)))).toFixed(1)}"/></svg>`;
}
/** كتشغل أنيميشن الحلقات اللي فالعنصر */
export function animateRings(root) {
  requestAnimationFrame(() => requestAnimationFrame(() => {
    $$(".arc[data-target]", root).forEach((a) => (a.style.strokeDashoffset = a.dataset.target));
  }));
}

/** نجمة كدور (للتحميل) */
export function spinner() {
  return `<svg class="spinner" viewBox="0 0 72 72"><g style="transform-origin:36px 36px;animation:spin 8s linear infinite">
    <polygon points="${starPoints(36, 36, 32)}" fill="none" stroke="#D4AF37" stroke-width="2"/></g>
    <g style="transform-origin:36px 36px;animation:spin 5s linear infinite reverse"><polygon points="${starPoints(36, 36, 20)}" fill="#D4AF37" fill-opacity=".8"/></g>
    <style>@keyframes spin{to{transform:rotate(360deg)}}</style></svg>`;
}

export const normalize = (s) =>
  String(s).replace(/[ؐ-ًؚ-ٰٟۖ-ۭـ]/g, "")
    .replace(/[أإآٱ]/g, "ا").replace(/[ىئ]/g, "ي").replace(/ؤ/g, "و").replace(/ة/g, "ه").replace(/\s+/g, " ").trim();

export async function fetchJson(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error("HTTP " + r.status);
  return r.json();
}

export function copyText(t) {
  if (navigator.clipboard) return navigator.clipboard.writeText(t).then(() => toast("تنسخ ✓"));
  toast("ما قدرناش ننسخو");
}
export function shareText(t) {
  if (navigator.share) navigator.share({ text: t }).catch(() => {});
  else copyText(t);
}
