// تحميل السور للاستماع بلا أنترنيت (Cache "q-audio")
import { ar, esc, icon, pattern, starBadge, spinner, toast } from "../util.js";
import { loadQuran, Q, reciter, ayahUrl, warshReciters, surahUrl, settings, setSetting } from "../data.js";
import { downloadAll, deleteUrls, isCached, usedMb } from "../player.js";

// التحميلات كتبقى خدامة حتى إلا خرجتي من الصفحة
const jobs = new Map(); // key -> {p, ctrl, err}
let redraw = null;

export async function render(el) {
  el.innerHTML = spinner();
  await loadQuran();
  let riwaya = "hafs";
  let warsh = [], warshSel = null;

  const urlsFor = (s) => (riwaya === "hafs"
    ? Q.surahs[s - 1].ayahs.map((a) => ayahUrl(reciter(), s, a.n))
    : [surahUrl(warshSel, s)]);
  const keyFor = (s) => (riwaya === "hafs" ? `h:${reciter().id}:${s}` : `w:${warshSel?.id}:${s}`);

  const draw = async () => {
    const mb = await usedMb();
    el.innerHTML = `<section class="page-header">${pattern()}<div class="content">
        <div class="hrow"><a class="icon-btn" href="#/home">${icon("back")}</a>
          <div class="grow"><h2>الاستماع بلا أنترنيت</h2><p>المساحة المستعملة: ${mb.toFixed(1)} MB</p></div></div>
        <div class="chips" style="margin-top:10px">
          <button class="chip ${riwaya === "hafs" ? "on" : ""}" data-r="hafs">حفص (آية بآية)</button>
          <button class="chip ${riwaya === "warsh" ? "on" : ""}" data-r="warsh">ورش (السورة كاملة)</button></div>
        <p>${riwaya === "hafs" ? `المقرئ: ${esc(reciter().name)} (بدلو من الإعدادات)` : `المقرئ: ${esc(warshSel?.name || "…")}`}</p>
        ${riwaya === "warsh" && warsh.length ? `<div class="chips" style="margin-top:6px">${warsh.map((r) => `<button class="chip ${r.id === warshSel?.id ? "on" : ""}" data-w="${r.id}" style="font-size:12px">${esc(r.name)}</button>`).join("")}</div>` : ""}
      </div></section>
      <div class="install-tip">💡 على iPhone: زيد التطبيق للشاشة الرئيسية (مشاركة ← "إضافة إلى الشاشة الرئيسية") باش Safari ما يمسحش التحميلات.</div>
      <div id="rows" class="stagger">${riwaya === "warsh" && !warsh.length ? spinner() : ""}</div>`;
    el.querySelector(".page-header").onclick = (e) => {
      const r = e.target.closest("[data-r]")?.dataset.r;
      if (r) { riwaya = r; draw(); if (r === "warsh") loadWarsh(); }
      const w = e.target.closest("[data-w]")?.dataset.w;
      if (w) { warshSel = warsh.find((x) => x.id === w); setSetting("warshReciter", w); draw(); }
    };
    if (riwaya === "warsh" && !warsh.length) return;
    const rows = el.querySelector("#rows");
    const html = [];
    for (let s = 1; s <= 114; s++) {
      const avail = riwaya === "hafs" || !warshSel?.surahs.size || warshSel.surahs.has(s);
      html.push(`<div class="dl-row" data-s="${s}" style="animation-delay:${Math.min(s, 14) * 40}ms">${starBadge(s, 38)}
        <div class="mid"><div class="quran" style="font-size:20px">سورة ${esc(Q.surahs[s - 1].name)}</div>
          <div class="muted st" style="font-size:12px">${riwaya === "hafs" ? ar(Q.surahs[s - 1].ayahs.length) + " آية" : avail ? "ملف واحد" : "ما متوفراش عند هاد المقرئ"}</div>
          <div class="dl-bar" hidden><i style="width:0"></i></div></div>
        <span class="act">${avail ? `<button class="icon-btn" style="background:var(--surface-2);color:var(--primary)" data-a="dl">${icon("download")}</button>` : ""}</span></div>`);
    }
    rows.innerHTML = html.join("");
    rows.onclick = (e) => {
      const b = e.target.closest("[data-a]"); if (!b) return;
      const s = +b.closest("[data-s]").dataset.s;
      const key = keyFor(s);
      if (b.dataset.a === "dl") start(key, urlsFor(s));
      if (b.dataset.a === "cancel") { jobs.get(key)?.ctrl.abort(); jobs.delete(key); refresh(); }
      if (b.dataset.a === "del") deleteUrls(urlsFor(s)).then(refresh);
    };
    refresh();
  };

  // حالة كل سطر (محملة؟ كتتحمل؟)
  const refresh = async (onlyKey) => {
    for (const r of el.querySelectorAll(".dl-row")) {
      const s = +r.dataset.s;
      if (onlyKey && keyFor(s) !== onlyKey) continue;
      const key = keyFor(s);
      const job = jobs.get(key);
      const bar = r.querySelector(".dl-bar"), act = r.querySelector(".act");
      if (!act.innerHTML) continue;
      if (job && !job.err) {
        bar.hidden = false; bar.firstElementChild.style.width = (job.p * 100).toFixed(0) + "%";
        act.innerHTML = `<button class="icon-btn" style="background:var(--surface-2);color:var(--on)" data-a="cancel">${icon("close")}</button>`;
        continue;
      }
      bar.hidden = true;
      if (job?.err) r.querySelector(".st").textContent = job.err;
      const urls = urlsFor(s);
      const done = await isCached(urls[urls.length - 1]) && await isCached(urls[0]);
      act.innerHTML = done
        ? `<span style="color:#10AC84">${icon("check", 'width="22" height="22"')}</span><button class="icon-btn" style="background:transparent;color:var(--muted)" data-a="del">${icon("trash")}</button>`
        : `<button class="icon-btn" style="background:var(--surface-2);color:var(--primary)" data-a="dl">${icon("download")}</button>`;
    }
  };

  const start = (key, urls) => {
    if (jobs.has(key)) return;
    const ctrl = new AbortController();
    const job = { p: 0, ctrl, err: null };
    jobs.set(key, job);
    refresh();
    downloadAll(urls, (p) => { job.p = p; redraw?.(key); }, ctrl.signal)
      .then(() => { jobs.delete(key); redraw?.(key); })
      .catch((e) => {
        if (e.name === "AbortError") return;
        job.err = "ما تكملش التحميل (الأنترنيت ولا السيرفر ما كيسمحش بالتحميل)";
        job.ctrl = { abort() {} };
        setTimeout(() => { jobs.delete(key); redraw?.(key); }, 6000);
        redraw?.(key);
        toast("ما تكملش التحميل");
      });
  };

  const loadWarsh = async () => {
    try {
      warsh = await warshReciters();
      warshSel = warsh.find((r) => r.id === settings.warshReciter) || warsh[0];
    } catch {
      el.querySelector("#rows").innerHTML = `<div class="empty">ما قدرناش نجيبو لائحة قراء ورش. تأكد من الأنترنيت.</div>`;
      return;
    }
    draw();
  };

  redraw = (k) => refresh(k);
  await draw();
  return () => { redraw = null; };
}
