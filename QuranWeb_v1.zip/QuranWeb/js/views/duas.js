// الأدعية والأذكار: حصن المسلم (hisnmuslim.com) — النص + الصوت + العداد
import { ar, esc, icon, pattern, addParticles, spinner, store, normalize } from "../util.js";
import { cachedJson } from "../data.js";
import { playQueue, onPlayer, current } from "../player.js";

const https = (u) => String(u || "").trim().replace(/^http:\/\//, "https://");
const DAILY = ["الصباح", "المساء", "النوم", "الاستيقاظ", "الصلاة", "المسجد", "الطعام", "السفر", "الكرب", "الهم"];

async function chapters() {
  const j = await cachedJson("https://www.hisnmuslim.com/api/ar/husn_ar.json");
  const arr = Object.values(j)[0];
  const seen = new Set();
  return arr.map((x) => ({ id: +x.ID, title: String(x.TITLE).trim(), text: https(x.TEXT) }))
    .filter((c) => c.id > 0 && !seen.has(c.id) && seen.add(c.id)).sort((a, b) => a.id - b.id);
}

const header = (title, sub, back) => `<section class="page-header">${pattern()}<div class="content"><div class="hrow">
  ${back ? `<a class="icon-btn" href="${back}">${icon("back")}</a>` : ""}<div class="grow"><h2>${title}</h2>${sub ? `<p>${sub}</p>` : ""}</div></div></div></section>`;

export async function render(el, [id]) {
  el.innerHTML = header("الأدعية والأذكار 🤲", "حصن المسلم") + spinner();
  let list;
  try { list = await chapters(); } catch {
    el.innerHTML = header("الأدعية والأذكار 🤲", "حصن المسلم") + `<div class="empty">ما قدرناش نجيبو الأذكار من hisnmuslim.com.<br>تأكد من الأنترنيت (أول مرة فقط) وعاود.</div>`;
    return;
  }
  if (id) return chapter(el, list.find((c) => c.id === +id));

  const draw = (q = "") => {
    const nq = normalize(q);
    const daily = list.filter((c) => DAILY.some((d) => c.title.includes(d)));
    const items = nq ? list.filter((c) => normalize(c.title).includes(nq)) : list;
    const row = (c, i) => `<a class="row3 press" href="#/dua/${c.id}" style="animation-delay:${Math.min(i, 14) * 40}ms">
      <span style="font-size:26px">🤲</span><div class="mid"><div class="title" style="white-space:normal">${esc(c.title)}</div></div></a>`;
    el.querySelector("#l").innerHTML = (!nq ? `<div class="section-title" style="margin-inline:4px">☀️ الأذكار اليومية</div>${daily.map(row).join("")}<div class="section-title" style="margin-inline:4px">📖 كل الأبواب</div>` : "") + items.map(row).join("");
  };
  el.innerHTML = header("الأدعية والأذكار 🤲", `حصن المسلم • ${ar(list.length)} باب`) +
    `<div class="search-box">${icon("search")}<input id="q" type="search" placeholder="ابحث فالأبواب…"></div><div class="list stagger" id="l"></div>`;
  addParticles(el.querySelector(".page-header"));
  el.querySelector("#q").oninput = (e) => draw(e.target.value);
  draw();
}

async function chapter(el, c) {
  if (!c) { location.hash = "#/duas"; return; }
  el.innerHTML = header(esc(c.title), "", "#/duas") + spinner();
  let duas;
  try {
    const j = await cachedJson(c.text);
    duas = Object.values(j)[0].map((x) => ({ id: +x.ID, text: String(x.ARABIC_TEXT || "").trim(), rep: Math.max(1, +x.REPEAT || 1), audio: https(x.AUDIO || `https://www.hisnmuslim.com/audio/ar/${x.ID}.mp3`) })).filter((d) => d.text);
  } catch {
    el.innerHTML = header(esc(c.title), "", "#/duas") + `<div class="empty">ما قدرناش نجيبو الأذكار. تأكد من الأنترنيت.</div>`;
    return;
  }
  const counts = store.get("duaCounts:" + c.id, {});
  const items = duas.map((d, i) => ({ id: `dua:${d.id}`, url: d.audio, title: `${c.title} (${i + 1})`, artist: "حصن المسلم", album: c.title }));
  el.innerHTML = header(esc(c.title), `${ar(duas.length)} ذكر`, "#/duas") +
    `<div style="padding:12px 16px"><button class="btn block" id="all">${icon("play")} استمع لكل الأذكار</button></div>
    <div class="stagger" id="l">${duas.map((d, i) => `<article class="dua" data-i="${i}" style="animation-delay:${Math.min(i, 14) * 40}ms">
      <div class="ar quran">${esc(d.text)}</div>
      <div class="hrow" style="margin-top:10px">
        <button class="btn outline" data-a="play" style="padding:8px 14px">${icon("play", 'width="18" height="18"')} استمع</button>
        <span class="grow muted" style="font-size:13px">${d.rep > 1 ? `🔁 ${ar(d.rep)} مرات` : ""}</span>
        <button class="counter ${(counts[d.id] || 0) >= d.rep ? "done" : ""}" data-a="count">${(counts[d.id] || 0) >= d.rep ? "✓" : ar(d.rep - (counts[d.id] || 0))}</button>
      </div></article>`).join("")}</div>`;
  el.querySelector("#all").onclick = () => playQueue(items, 0);
  el.querySelector("#l").onclick = (e) => {
    const b = e.target.closest("[data-a]"); if (!b) return;
    const i = +b.closest("[data-i]").dataset.i, d = duas[i];
    if (b.dataset.a === "play") playQueue([items[i]], 0);
    if (b.dataset.a === "count") {
      counts[d.id] = ((counts[d.id] || 0) + 1) % (d.rep + 1);
      store.set("duaCounts:" + c.id, counts);
      const left = d.rep - counts[d.id];
      b.classList.toggle("done", left <= 0);
      b.textContent = left <= 0 ? "✓" : ar(left);
      if (navigator.vibrate) navigator.vibrate(15);
    }
  };
  const hl = () => {
    const cur = current()?.id;
    el.querySelectorAll(".dua").forEach((x, i) => x.classList.toggle("playing", items[i].id === cur));
  };
  hl();
  return onPlayer(hl);
}
