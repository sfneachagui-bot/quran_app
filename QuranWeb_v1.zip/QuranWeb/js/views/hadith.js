// الحديث: حديث اليوم، الأربعون النووية والقدسية (بلا أنترنيت)، الكتب الستة + الموطأ (hadith-api)
import { ar, esc, icon, pattern, addParticles, spinner, store, fetchJson, copyText, shareText, toast } from "../util.js";
import { cachedJson } from "../data.js";

let offline = null, meta = null;
const loadOffline = async () => (offline ??= await fetchJson("data/hadith_offline.json"));
const loadMeta = async () => (meta ??= await fetchJson("data/hadith_meta.json"));
const favs = () => store.get("hadithFavs", []);

function gradeAr(g) {
  const s = String(g).toLowerCase(), n = s.replace(/ /g, "");
  if (s.includes("hasan sahih") || s.includes("hasan saheeh")) return "حسن صحيح";
  if (s.includes("sahih") || s.includes("saheeh")) return n.includes("lighairihi") ? "صحيح لغيره" : "صحيح";
  if (s.includes("hasan")) return n.includes("lighairihi") ? "حسن لغيره" : "حسن";
  if (/maudu|mawdu|fabricated/.test(s)) return "موضوع";
  if (s.includes("munkar")) return "منكر";
  if (s.includes("shadh")) return "شاذ";
  if (/da'if|daif|da`if|weak|dhaif/.test(s)) return "ضعيف";
  return g;
}

const header = (title, sub, back) => `<section class="page-header">${pattern()}<div class="content"><div class="hrow">
  ${back ? `<a class="icon-btn" href="${back}">${icon("back")}</a>` : ""}<div class="grow"><h2>${title}</h2>${sub ? `<p>${sub}</p>` : ""}</div>
  ${!back ? `<a class="icon-btn" href="#/hadith-favs" aria-label="المفضلة">⭐</a>` : ""}</div></div></section>`;

const card = (h, i) => {
  const key = `${h.c}:${h.id}`;
  const fav = favs().includes(key);
  const weak = h.grade && /ضعيف|موضوع|منكر/.test(h.grade);
  return `<article class="hadith" style="animation-delay:${Math.min(i, 14) * 40}ms" data-k="${key}">
    <div class="hrow"><b class="grow" style="color:var(--primary)">${esc(h.book)} • ${ar(h.id)}</b>
      <button data-a="fav" style="font-size:20px">${fav ? "⭐" : "☆"}</button>
      <button data-a="copy" class="muted">${icon("copy", 'width="20" height="20"')}</button>
      <button data-a="share" class="muted">${icon("share", 'width="20" height="20"')}</button></div>
    <div class="ar">${esc(h.text)}</div>
    ${h.fr ? `<div class="fr ltr">${esc(h.fr)}</div>` : ""}
    ${h.grade ? `<span class="grade ${weak ? "weak" : ""}">${esc(h.grade)}</span>` : ""}</article>`;
};

function bindCards(root, list) {
  root.onclick = (e) => {
    const b = e.target.closest("[data-a]"); if (!b) return;
    const key = b.closest("[data-k]").dataset.k;
    const h = list.find((x) => `${x.c}:${x.id}` === key); if (!h) return;
    const txt = `${h.text}\n[${h.book} - ${ar(h.id)}]`;
    if (b.dataset.a === "copy") copyText(txt);
    if (b.dataset.a === "share") shareText(txt);
    if (b.dataset.a === "fav") {
      const f = new Set(favs()); f.has(key) ? f.delete(key) : f.add(key);
      store.set("hadithFavs", [...f]);
      const all = store.get("hadithFavData", {});
      if (f.has(key)) all[key] = h; else delete all[key];
      store.set("hadithFavData", all);
      b.textContent = f.has(key) ? "⭐" : "☆";
      toast(f.has(key) ? "تزاد للمفضلة" : "تحيد من المفضلة");
    }
  };
}

export async function render(el, [c, sec], path) {
  el.innerHTML = spinner();
  const off = await loadOffline();
  const m = await loadMeta();

  if (path === "hadith-favs") {
    const data = store.get("hadithFavData", {});
    const list = favs().map((k) => data[k]).filter(Boolean);
    el.innerHTML = header("المفضلة ⭐", `${ar(list.length)} حديث`, "#/hadith") +
      `<div class="stagger" id="l">${list.map(card).join("") || `<div class="empty">ما زال ما زدتي حتى حديث للمفضلة</div>`}</div>`;
    bindCards(el.querySelector("#l"), list);
    return;
  }

  // كتاب بلا أنترنيت (النووية/القدسية)
  if (c && off[c]) {
    const list = off[c].hadiths.map((h) => ({ c, id: h.n, book: off[c].name, text: h.ar, fr: h.fr }));
    el.innerHTML = header(esc(off[c].name), `${ar(list.length)} حديث • بالعربية والفرنسية`, "#/hadith") + `<div class="stagger" id="l">${list.map(card).join("")}</div>`;
    bindCards(el.querySelector("#l"), list);
    return;
  }

  const book = c && m.find((b) => b.id === c);
  if (book && sec) {
    el.innerHTML = header(esc(book.name), "", `#/hadith/${c}`) + spinner();
    try {
      const j = await cachedJson(`https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/ara-${c}/sections/${sec}.min.json`);
      const seen = new Set();
      const list = j.hadiths.filter((h) => String(h.text || "").trim()).map((h) => {
        const g = (h.grades || []).find((x) => String(x.name).includes("Albani")) || (h.grades || [])[0];
        return { c, id: h.hadithnumber, book: book.name, text: h.text.trim(), grade: g ? (String(g.name).includes("Albani") ? "حكم الألباني: " : "الحكم: ") + gradeAr(g.grade) : null };
      }).filter((h) => !seen.has(h.id) && seen.add(h.id));
      const s = book.sections.find((x) => x.n === +sec);
      el.innerHTML = header(esc(book.name), esc(s?.name || ""), `#/hadith/${c}`) + `<div class="stagger" id="l">${list.map(card).join("")}</div>`;
      bindCards(el.querySelector("#l"), list);
    } catch {
      el.innerHTML = header(esc(book.name), "", `#/hadith/${c}`) + `<div class="empty">ما قدرناش نجيبو الأحاديث. تأكد من الأنترنيت (أول مرة فقط).</div>`;
    }
    return;
  }
  if (book) {
    el.innerHTML = header(esc(book.name), `${ar(book.total)} حديث • ${ar(book.sections.length)} باب`, "#/hadith") +
      `<div class="list stagger">${book.sections.map((s, i) => `<a class="row3 press" href="#/hadith/${c}/${s.n}" style="animation-delay:${Math.min(i, 14) * 40}ms">
        <span class="star-badge" style="width:42px"><b>${ar(s.n)}</b></span><div class="mid"><div class="title">${esc(s.name)}</div>
        <div class="sub">الأحاديث ${ar(s.first)} – ${ar(s.last)}</div></div></a>`).join("")}</div>`;
    return;
  }

  // الصفحة الرئيسية ديال الحديث
  const pool = Object.entries(off).flatMap(([k, v]) => v.hadiths.map((h) => ({ c: k, id: h.n, book: v.name, text: h.ar, fr: h.fr })));
  const day = Math.floor(Date.now() / 864e5);
  const hod = pool[day % pool.length];
  el.innerHTML = `${header("الحديث النبوي الشريف", "الأربعون بلا أنترنيت • الكتب الستة والموطأ")}
    <div class="section-title">✨ حديث اليوم</div><div id="hod">${card(hod, 0)}</div>
    <div class="section-title">📗 بلا أنترنيت</div>
    <div class="list stagger">${Object.entries(off).map(([k, v], i) => `<a class="row3 press" href="#/hadith/${k}" style="animation-delay:${i * 50}ms">
      <span style="font-size:28px">📗</span><div class="mid"><div class="title">${esc(v.name)}</div><div class="sub">${ar(v.hadiths.length)} حديث • عربي + فرنسي</div></div></a>`).join("")}</div>
    <div class="section-title">📚 الكتب (كتتحمل باب بباب)</div>
    <div class="list stagger">${m.map((b, i) => `<a class="row3 press" href="#/hadith/${b.id}" style="animation-delay:${i * 50}ms">
      <span style="font-size:28px">📚</span><div class="mid"><div class="title">${esc(b.name)}</div><div class="sub">${ar(b.total)} حديث</div></div></a>`).join("")}</div>`;
  addParticles(el.querySelector(".page-header"));
  bindCards(el.querySelector("#hod"), [hod]);
}
