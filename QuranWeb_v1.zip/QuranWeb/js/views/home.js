import { ar, esc, icon, ornament, pattern, addParticles, starBadge, ring, animateRings, spinner, store } from "../util.js";
import { loadQuran, Q, lastRead, juzOf, hizbLabel, globalIndex, readingLog, QUARTERS } from "../data.js";

const DAYS = ["أحد", "إثن", "ثلا", "أرب", "خمي", "جمع", "سبت"];

export async function render(el) {
  el.innerHTML = spinner();
  await loadQuran();
  const last = lastRead();
  const s = last ? Q.surahs[last[0] - 1] : null;
  const tab = store.get("homeTab", 0);
  const progress = last ? (globalIndex(last[0], last[1]) + 1) / Q.total : 0;

  el.innerHTML = `
  <section class="hero">${pattern()}
    <div class="content">
      <div class="topbar">
        <a class="icon-btn" href="#/settings" aria-label="الإعدادات">${icon("settings")}</a>
        <a class="icon-btn" href="#/bookmarks" aria-label="العلامات">${icon("bookmark")}</a>
        <h1 class="shimmer">القرآن الكريم</h1>
        <a class="icon-btn" href="#/search" aria-label="البحث">${icon("search")}</a>
      </div>
      ${ornament()}
      <div class="quick">
        <a class="card-glass press" href="#/mushaf"><button tabindex="-1"><span class="e">📖</span><span><b>المصحف بالصفحات</b><small>حفص • ورش</small></span></button></a>
        <a class="card-glass press" href="#/downloads"><button tabindex="-1"><span class="e">🎧</span><span><b>بلا أنترنيت</b><small>تحميل السور</small></span></button></a>
      </div>
      <a class="card-glass continue press" href="#/reader/${last ? last[0] + "/" + last[1] : "1/1"}">
        <div style="flex:1">
          <div class="t1">${s ? "كمّل القراءة" : "ابدأ القراءة"}</div>
          <div class="t2">سورة ${esc((s || Q.surahs[0]).name)}</div>
          ${last ? `<div class="t3">الآية ${ar(last[1])} • الجزء ${ar(juzOf(last[0], last[1]))} • ${hizbLabel(last[0], last[1])}</div>` : ""}
        </div>
        <span class="go">${icon("forward")}</span>
      </a>
    </div>
  </section>
  ${statsCard(progress)}
  <div class="segments" role="tablist">
    <span class="seg-ind"></span>
    ${["السور", "الأجزاء", "الأحزاب"].map((t, i) => `<button data-t="${i}" class="${i === tab ? "on" : ""}">${t}</button>`).join("")}
  </div>
  <div class="list stagger" id="lst"></div>`;

  addParticles(el.querySelector(".hero"));
  animateRings(el);
  // الأعمدة كيطلعو بالتتابع
  setTimeout(() => el.querySelectorAll(".bar .fill").forEach((f, i) => setTimeout(() => (f.style.height = f.dataset.h), i * 90)), 250);

  const segs = el.querySelector(".segments");
  const ind = segs.querySelector(".seg-ind");
  const moveInd = (i) => {
    const b = segs.querySelectorAll("button")[i];
    ind.style.width = b.offsetWidth + "px";
    ind.style.insetInlineStart = (segs.getBoundingClientRect().right - b.getBoundingClientRect().right) + "px";
  };
  const show = (i) => {
    store.set("homeTab", i);
    segs.querySelectorAll("button").forEach((b, k) => b.classList.toggle("on", k === i));
    moveInd(i);
    const lst = el.querySelector("#lst");
    lst.innerHTML = [surahList, juzList, hizbList][i]();
  };
  segs.onclick = (e) => { const b = e.target.closest("button"); if (b) show(+b.dataset.t); };
  show(tab);
}

function statsCard(progress) {
  const log = readingLog();
  const days = [...Array(7)].map((_, i) => { const d = new Date(); d.setDate(d.getDate() - (6 - i)); return d; });
  const vals = days.map((d) => log[d.toISOString().slice(0, 10)] || 0);
  const max = Math.max(1, ...vals);
  let streak = 0;
  const d = new Date();
  if (!log[d.toISOString().slice(0, 10)]) d.setDate(d.getDate() - 1);
  while (log[d.toISOString().slice(0, 10)]) { streak++; d.setDate(d.getDate() - 1); }
  const week = vals.reduce((a, b) => a + b, 0);
  return `<section class="stats stagger">${pattern(0.04, 34)}
    <div class="row">
      <div class="ring">${ring(progress)}<div class="lbl"><b>${ar(Math.floor(progress * 100))}٪</b><small>من المصحف</small></div></div>
      <div style="flex:1">
        <h3>إحصائيات القراءة</h3>
        <div class="stat-line"><span>🔥 السلسلة</span><b>${ar(streak)} ${streak === 1 ? "يوم" : "أيام"}</b></div>
        <div class="stat-line"><span>📖 اليوم</span><b>${ar(vals[6])} آية</b></div>
        <div class="stat-line"><span>✨ هاد السيمانة</span><b>${ar(week)} آية</b></div>
      </div>
    </div>
    <div class="bars">${vals.map((v, i) => `<div class="bar ${i === 6 ? "today" : ""}"><div class="track"><div class="fill" data-h="${v ? Math.max(6, (v / max) * 100) : 0}%"></div></div>
      <small>${i === 6 ? "اليوم" : DAYS[days[i].getDay()]}</small></div>`).join("")}</div>
  </section>`;
}

const row = (i, badge, title, sub, trail, href) =>
  `<a class="row3 press" href="${href}" style="animation-delay:${Math.min(i, 14) * 45}ms">${starBadge(badge)}
    <div class="mid"><div class="title">${title}</div><div class="sub">${sub}</div></div>
    ${trail ? `<div class="trail">${esc(trail)}</div>` : ""}</a>`;

const firstWords = (s, a) => (Q.surahs[s - 1]?.ayahs[a - 1]?.text || "").split(" ").slice(0, 4).join(" ") + "…";

function surahList() {
  return Q.surahs.map((s, i) => row(i, s.id, `${esc(s.tr)} • ${esc(s.meaning)}`, `${s.meccan ? "مكية" : "مدنية"} • ${ar(s.ayahs.length)} آية`, s.name, `#/reader/${s.id}/1`)).join("");
}
function juzList() {
  return Q.parts.juz.map(([s, a], i) => row(i, i + 1, `الجزء ${ar(i + 1)}`, `سورة ${Q.surahs[s - 1].name} • الآية ${ar(a)}`, firstWords(s, a), `#/reader/${s}/${a}`)).join("");
}
function hizbList() {
  let out = "";
  for (let h = 0; h < 60; h++) {
    const [s, a] = Q.parts.rub[h * 4];
    out += `<div style="animation-delay:${Math.min(h, 14) * 45}ms">${row(h, h + 1, `الحزب ${ar(h + 1)} • الجزء ${ar(Math.floor(h / 2) + 1)}`, `سورة ${Q.surahs[s - 1].name} • الآية ${ar(a)}`, firstWords(s, a), `#/reader/${s}/${a}`)}
      <div class="quarters">${[1, 2, 3].map((q) => { const [qs, qa] = Q.parts.rub[h * 4 + q]; return `<a href="#/reader/${qs}/${qa}"><button tabindex="-1">${QUARTERS[q]}</button></a>`; }).join("")}</div></div>`;
  }
  return out;
}
