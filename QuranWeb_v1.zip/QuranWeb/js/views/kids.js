// ركن الأطفال: حفظ قصار السور، تعلّم الوضوء والصلاة (رسوم توضيحية)، الاختبارات
import { ar, esc, icon, spinner, store, fetchJson, toast, openSheet } from "../util.js";
import { loadQuran, Q, tafsir } from "../data.js";
import { playQueue, onPlayer, current } from "../player.js";

const C = { orange: "#FF9F43", blue: "#54A0FF", purple: "#8E7CFF", green: "#10AC84", pink: "#FF6B9D", yellow: "#FECA57" };
const KIDS_SURAHS = [1, ...Array.from({ length: 37 }, (_, i) => 114 - i)];
const TEACHERS = [
  { id: "husary_mu", name: "الحصري (المصحف المعلم)", folder: "Husary_Muallim_128kbps" },
  { id: "minshawy_t", name: "المنشاوي (المصحف المعلم)", folder: "Minshawy_Teacher_128kbps" },
  { id: "husary", name: "الحصري (مرتل)", folder: "Husary_128kbps" },
  { id: "alafasy", name: "مشاري العفاسي", folder: "Alafasy_128kbps" },
];
const IMG = {
  wudu: ["01_niyyah", "02_bismillah", "03_hands", "04_mouth", "05_nose", "06_face", "07_arms", "08_head", "09_ears", "10_feet", "11_dua"].map((x) => `kids/wudu_${x}.svg`),
  salah: ["01_wudu", "02_qibla", "03_niyyah", "04_takbir", "05_qiyam", "06_ruku", "07_itidal", "08_sujud", "09_julus", "10_sujud2", "11_tashahhud", "12_salawat", "13_salam"].map((x) => `kids/salah_${x}.svg`),
};
const COVER = { wudu: "kids/wudu_03_hands.svg", salah: "kids/salah_04_takbir.svg" };
const COLORS = { wudu: [C.blue, "#48DBFB"], salah: [C.orange, C.yellow] };

let K = null;
const loadKids = async () => (K ??= await fetchJson("data/kids.json"));
const memorized = () => new Set(store.get("kidsMem", []));
const scores = () => store.get("kidsScores", {});
const stars = (n) => "⭐".repeat(n) + "☆".repeat(3 - n);

const head = (title, sub, colors, back) => `<header class="kids-head" style="background:linear-gradient(135deg,${colors[0]},${colors[1]})">
  <div class="hrow">${back ? `<a class="icon-btn" href="${back}">${icon("back")}</a>` : ""}<div class="grow"><h2>${title}</h2>${sub ? `<div style="opacity:.92;font-size:14px">${sub}</div>` : ""}</div></div></header>`;

export async function render(el, [a, b]) {
  el.innerHTML = spinner();
  await Promise.all([loadKids(), loadQuran()]);
  if (a === "surahs") return surahList(el);
  if (a === "surah") return surahView(el, +b);
  if (a === "lesson") return lesson(el, b);
  if (a === "quizzes") return quizList(el);
  if (a === "quiz") return quiz(el, b);
  return home(el);
}

function home(el) {
  const sc = scores(), mem = memorized();
  const card = (href, img, e, t, s, col) => `<a class="big-card press" href="${href}" style="background:linear-gradient(135deg,${col[0]},${col[1]})">
    ${img ? `<img src="${img}" alt="">` : `<span class="e">${e}</span>`}<b>${t}</b><small>${s}</small></a>`;
  el.innerHTML = head("ركن الأطفال 🌟", "نتعلمو القرآن والوضوء والصلاة ونلعبو!", [C.purple, C.blue]) + `
    <div class="kids-grid stagger">
      ${card("#/kids/surahs", null, "📖", "حفظ قصار السور", `المصحف المعلم • ${ar(mem.size)}/${ar(KIDS_SURAHS.length)} ⭐`, [C.green, "#1DD1A1"])}
      ${card("#/kids/lesson/wudu", COVER.wudu, "", "تعلّم الوضوء", sc.wudu != null ? stars(sc.wudu) : "١١ خطوة", COLORS.wudu)}
      ${card("#/kids/lesson/salah", COVER.salah, "", "تعلّم الصلاة", sc.salah != null ? stars(sc.salah) : "١٣ خطوة", COLORS.salah)}
      ${card("#/kids/quizzes", null, "🏆", "الاختبارات", `${ar(Object.values(sc).reduce((x, y) => x + y, 0))} ⭐ مجموع النجوم`, [C.pink, "#FF9FF3"])}
    </div>
    <p class="muted" style="margin:8px 20px;font-size:13px">💡 للوالدين: المصحف المعلم كيخلي القارئ يقرا بشوية والطفل يعاود من وراه. تقدرو تكررو كل آية 3 ولا 5 ديال المرات.</p>`;
}

function surahList(el) {
  const mem = memorized(), sc = scores();
  el.innerHTML = head("حفظ قصار السور 📖", `حفظتي ${ar(mem.size)} من ${ar(KIDS_SURAHS.length)} سورة`, [C.green, "#1DD1A1"], "#/kids") +
    `<div class="progress"><i style="width:${(mem.size / KIDS_SURAHS.length) * 100}%;background:${C.yellow}"></i></div>
    <div class="list stagger">${KIDS_SURAHS.map((id, i) => {
      const s = Q.surahs[id - 1];
      return `<a class="row3 press" href="#/kids/surah/${id}" style="animation-delay:${Math.min(i, 14) * 40}ms">
        <span style="font-size:28px">${mem.has(id) ? "⭐" : "📗"}</span><div class="mid"><div class="title quran" style="font-size:22px;font-weight:400">سورة ${esc(s.name)}</div>
        <div class="sub">${ar(s.ayahs.length)} آية${sc["surah_" + id] != null ? " • " + stars(sc["surah_" + id]) : ""}</div></div></a>`;
    }).join("")}</div>`;
}

function surahView(el, id) {
  const s = Q.surahs[id - 1];
  let times = store.get("kidsTimes", 3), teacher = TEACHERS.find((t) => t.id === store.get("kidsTeacher")) || TEACHERS[0];
  const play = (from = 1, to = s.ayahs.length) => {
    const items = [];
    for (const a of s.ayahs) {
      if (a.n < from || a.n > to) continue;
      for (let k = 0; k < times; k++) items.push({
        id: `${s.id}:${a.n}`, ref: [s.id, a.n], title: `سورة ${s.name} - الآية ${a.n}`, artist: teacher.name, album: `سورة ${s.name}`,
        url: `https://everyayah.com/data/${teacher.folder}/${String(s.id).padStart(3, "0")}${String(a.n).padStart(3, "0")}.mp3`,
      });
    }
    playQueue(items, 0);
  };
  const draw = () => {
    const mem = memorized().has(id);
    el.innerHTML = head(`سورة ${esc(s.name)}`, `${ar(s.ayahs.length)} آية • استمع وعاود من ورا الشيخ`, [C.green, "#1DD1A1"], "#/kids/surahs") + `
      <div class="section-title">🎙️ الشيخ</div><div class="chips light" style="padding:0 16px">${TEACHERS.map((t) => `<button class="chip ${t.id === teacher.id ? "on" : ""}" data-t="${t.id}">${t.name}</button>`).join("")}</div>
      <div class="section-title">🔁 شحال من مرة نعاود كل آية؟</div><div class="chips light" style="padding:0 16px">${[1, 3, 5, 10].map((n) => `<button class="chip ${n === times ? "on" : ""}" data-n="${n}">${ar(n)} ${n === 1 ? "مرة" : "مرات"}</button>`).join("")}</div>
      <div style="display:flex;gap:10px;padding:16px">
        <button class="btn block" data-a="all" style="background:${C.green}">${icon("play")} استمع للسورة كاملة</button>
        <button class="btn outline" data-a="mem" style="flex:none">${mem ? "⭐ حفظتها" : "☆ حفظتها؟"}</button></div>
      <div class="stagger">${s.ayahs.map((a, i) => `<div class="ayah-card" data-n="${a.n}" style="animation-delay:${Math.min(i, 14) * 40}ms">
        <div class="ar" style="font-size:26px;line-height:1.9">${esc(a.text)} <span class="mark">۝${ar(a.n)}</span></div>
        <div class="hrow" style="margin-top:8px"><button class="btn outline" data-a="one" style="padding:6px 12px">${icon("play", 'width="16" height="16"')} هاد الآية</button>
          <button class="btn outline" data-a="mean" style="padding:6px 12px">💡 شنو معناها؟</button></div></div>`).join("")}</div>`;
  };
  draw();
  el.onclick = (e) => {
    const t = e.target.closest("[data-t]")?.dataset.t;
    if (t) { teacher = TEACHERS.find((x) => x.id === t); store.set("kidsTeacher", t); draw(); return; }
    const n = e.target.closest("[data-n]")?.dataset.n;
    const btn = e.target.closest("[data-a]");
    if (!btn && n && e.target.closest(".chip")) { times = +n; store.set("kidsTimes", times); draw(); return; }
    if (!btn) return;
    if (btn.dataset.a === "all") play();
    if (btn.dataset.a === "mem") {
      const m = memorized(); m.has(id) ? m.delete(id) : m.add(id); store.set("kidsMem", [...m]);
      if (m.has(id)) toast("برافو! ⭐ حفظتي السورة"); draw();
    }
    const an = +btn.closest("[data-n]")?.dataset.n;
    if (btn.dataset.a === "one") play(an, an);
    if (btn.dataset.a === "mean") {
      openSheet(`<h3>💡 شنو معنى الآية ${ar(an)}؟</h3><div class="body" id="mb">${spinner()}</div>`, async (sh) => {
        try { sh.querySelector("#mb").textContent = await tafsir("ar.muyassar", id, an); }
        catch { sh.querySelector("#mb").textContent = "خاص الأنترنيت (أول مرة فقط)."; }
      });
    }
  };
  const hl = () => { const c = current(); el.querySelectorAll(".ayah-card").forEach((x) => x.classList.toggle("hl", c?.ref?.[0] === id && c.ref[1] === +x.dataset.n)); };
  const off = onPlayer(hl);
  return () => { off(); el.onclick = null; };
}

function lesson(el, id) {
  const L = K.lessons[id];
  if (!L) { location.hash = "#/kids"; return; }
  const col = COLORS[id];
  const pages = L.steps.length + 2;
  let page = 0;
  const illus = (src, emoji) => `<div class="illus"><div class="img" style="border-color:${col[0]}88;box-shadow:0 12px 30px ${col[0]}55"><img src="${src}" alt=""></div>
    <div class="badge" style="border-color:${col[0]}">${emoji}</div></div>`;
  const draw = () => {
    let body;
    if (page === 0) {
      body = `${illus(COVER[id], L.emoji)}<h3 style="color:${col[0]}">${L.title}</h3><p>${esc(L.intro)}</p><p class="muted" style="font-size:15px">👉 سحب ولا ضغط على "التالي"</p>`;
    } else if (page === pages - 1) {
      body = `<div style="font-size:90px;animation:pop .6s">🎉</div><h3 style="color:${C.green}">برافو عليك!</h3><p>كملتي ${L.title}</p>
        <p style="font-size:16px;background:${C.yellow}40;border-radius:20px;padding:14px;white-space:pre-line">${esc(L.note)}</p>
        <a class="btn block" href="#/kids/quiz/${id}" style="background:${C.pink};margin-top:12px">🏆 اختبر راسك</a>`;
    } else {
      const st = L.steps[page - 1];
      body = `<b style="color:${col[0]}">الخطوة ${ar(page)} من ${ar(L.steps.length)}</b>${illus(IMG[id][page - 1], st.emoji)}
        <h3>${esc(st.title)}</h3>${st.times ? `<span class="times">🔁 ${esc(st.times)}</span>` : ""}<p>${esc(st.text)}</p>
        ${st.say ? `<div class="say" style="background:${col[0]}26">${esc(st.say)}</div>` : ""}`;
    }
    el.innerHTML = `<div class="lesson">${head(`${L.title} ${L.emoji}`, "", col, "#/kids")}
      <div class="progress"><i style="width:${((page + 1) / pages) * 100}%;background:${col[0]}"></i></div>
      <div class="strip">${L.steps.map((st, i) => `<button data-p="${i + 1}" class="${i + 1 === page ? "on" : i + 1 < page ? "done" : ""}" style="${i + 1 === page ? `border-color:${col[0]}` : ""}">
        <img src="${IMG[id][i]}" alt=""><i style="background:${i + 1 < page ? C.green : col[0]}">${i + 1 < page ? "✓" : ar(i + 1)}</i></button>`).join("")}</div>
      <div class="step" id="st">${body}</div>
      <div class="lesson-nav"><button class="btn outline" data-go="-1" ${page === 0 ? "disabled style='opacity:.4'" : ""}>السابق</button>
        <button class="btn" data-go="1" style="background:${col[0]}" ${page === pages - 1 ? "disabled style='opacity:.4'" : ""}>التالي</button></div></div>`;
    el.querySelector(".strip .on")?.scrollIntoView({ inline: "center", block: "nearest", behavior: "smooth" });
  };
  const go = (p) => { page = Math.max(0, Math.min(pages - 1, p)); draw(); window.scrollTo(0, 0); };
  el.onclick = (e) => {
    const g = e.target.closest("[data-go]"); if (g && !g.disabled) go(page + +g.dataset.go);
    const p = e.target.closest("[data-p]"); if (p) go(+p.dataset.p);
  };
  // السحب يمين/يسار
  let x0 = null;
  const ts = (e) => (x0 = e.touches[0].clientX);
  const te = (e) => { if (x0 == null) return; const dx = e.changedTouches[0].clientX - x0; x0 = null; if (Math.abs(dx) > 60) go(page + (dx > 0 ? 1 : -1)); };
  el.addEventListener("touchstart", ts, { passive: true });
  el.addEventListener("touchend", te);
  draw();
  return () => { el.onclick = null; el.removeEventListener("touchstart", ts); el.removeEventListener("touchend", te); };
}

function quizList(el) {
  const sc = scores();
  const row = (href, e, t, s) => `<a class="row3 press" href="${href}"><span style="font-size:28px">${e}</span><div class="mid"><div class="title">${t}</div><div class="sub">${s}</div></div></a>`;
  el.innerHTML = head("الاختبارات 🏆", "جاوب وربح النجوم ⭐", [C.pink, "#FF9FF3"], "#/kids") + `<div class="list stagger" style="margin-top:12px">
    ${row("#/kids/quiz/wudu", "💧", "اختبار الوضوء", sc.wudu != null ? stars(sc.wudu) : "جديد")}
    ${row("#/kids/quiz/salah", "🕌", "اختبار الصلاة", sc.salah != null ? stars(sc.salah) : "جديد")}
    <div class="section-title" style="margin-inline:4px">📖 اختبارات السور</div>
    ${KIDS_SURAHS.map((id) => row(`#/kids/quiz/surah_${id}`, "📗", `سورة ${Q.surahs[id - 1].name}`, sc["surah_" + id] != null ? stars(sc["surah_" + id]) : "شنو الآية اللي من بعد؟")).join("")}</div>`;
}

function surahQuiz(id) {
  const s = Q.surahs[id - 1], ay = s.ayahs;
  let seed = id * 31 + Math.floor(Date.now() / 864e5);
  const rnd = () => ((seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648);
  const shuffle = (a) => a.map((x) => [rnd(), x]).sort((p, q) => p[0] - q[0]).map((p) => p[1]);
  const qs = [];
  if (ay.length >= 3) {
    for (const i of shuffle([...Array(ay.length - 1).keys()]).slice(0, 5).sort((x, y) => x - y)) {
      const right = ay[i + 1].text;
      const wrong = shuffle(ay.map((_, k) => k).filter((k) => k !== i + 1 && k !== i && ay[k].text !== right)).slice(0, 2).map((k) => ay[k].text);
      if (wrong.length < 2) continue;
      const o = shuffle([...wrong, right]);
      qs.push({ q: `شنو الآية اللي كتجي من بعد:\n«${ay[i].text}»`, o, a: o.indexOf(right), e: "📖", quran: true });
    }
  }
  if (!qs.length) qs.push({ q: `شحال من آية فسورة ${s.name}؟`, o: [String(ay.length), String(ay.length + 2), String(ay.length + 4)], a: 0, e: "🔢" });
  return { id: "surah_" + id, title: `اختبار سورة ${s.name}`, questions: qs };
}

function quiz(el, id) {
  const Z = id.startsWith("surah_") ? surahQuiz(+id.slice(6)) : K.quizzes[id];
  if (!Z) { location.hash = "#/kids/quizzes"; return; }
  let i = 0, right = 0, locked = false;
  const draw = () => {
    if (i >= Z.questions.length) {
      const st = Math.round((right / Z.questions.length) * 3);
      const sc = scores(); if ((sc[Z.id] ?? -1) < st) { sc[Z.id] = st; store.set("kidsScores", sc); }
      el.innerHTML = head(Z.title, "", [C.pink, "#FF9FF3"], "#/kids/quizzes") + `<div class="step"><div style="font-size:90px;animation:pop .6s">${st === 3 ? "🏆" : st >= 2 ? "🎉" : "💪"}</div>
        <h3>${ar(right)} من ${ar(Z.questions.length)}</h3><div style="font-size:44px">${stars(st)}</div>
        <p>${st === 3 ? "ممتاز! ما شاء الله" : st >= 2 ? "مزيان بزاف!" : "عاود وغادي تنجح إن شاء الله"}</p>
        <button class="btn block" id="again" style="background:${C.pink}">🔁 عاود</button></div>`;
      el.querySelector("#again").onclick = () => { i = 0; right = 0; draw(); };
      return;
    }
    const q = Z.questions[i];
    el.innerHTML = head(Z.title, `السؤال ${ar(i + 1)} من ${ar(Z.questions.length)}`, [C.pink, "#FF9FF3"], "#/kids/quizzes") +
      `<div class="progress"><i style="width:${(i / Z.questions.length) * 100}%;background:${C.pink}"></i></div>
      <div class="step"><div style="font-size:64px">${q.e}</div><p style="white-space:pre-line" class="${q.quran ? "quran" : ""}">${esc(q.q)}</p>
      ${q.o.map((o, k) => `<button class="quiz-opt ${q.quran ? "quran" : ""}" data-k="${k}">${esc(o)}</button>`).join("")}</div>`;
    locked = false;
  };
  el.onclick = (e) => {
    const b = e.target.closest(".quiz-opt"); if (!b || locked) return;
    locked = true;
    const q = Z.questions[i], k = +b.dataset.k;
    if (k === q.a) { right++; b.classList.add("ok"); navigator.vibrate?.(20); }
    else { b.classList.add("bad"); el.querySelector(`.quiz-opt[data-k="${q.a}"]`).classList.add("ok"); navigator.vibrate?.([30, 40, 30]); }
    setTimeout(() => { i++; draw(); }, 1100);
  };
  draw();
  return () => (el.onclick = null);
}
