// المصحف بالصفحات (604) — حفص ولا ورش، قلبان الصفحات بتأثير ثلاثي الأبعاد
import { ar, esc, icon, starBadge, spinner, store, openSheet, closeSheet } from "../util.js";
import { loadQuran, Q, settings, setSetting, mushafPages, surahName, juzOf } from "../data.js";
import { playHafs, playWarsh } from "../actions.js";

const BASMALA = { hafs: "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ", warsh: "بِسْمِ اِ۬للَّهِ اِ۬لرَّحْمَٰنِ اِ۬لرَّحِيمِ" };

export async function render(el, [startSurah]) {
  el.innerHTML = spinner();
  await loadQuran();
  let riwaya = settings.riwaya === "warsh" ? "warsh" : "hafs";
  let pages = await mushafPages(riwaya);
  const host = document.createElement("div");
  host.className = "mushaf";
  document.body.appendChild(host);
  el.innerHTML = "";

  const pageKey = () => "mushafPage:" + riwaya;
  let cur = 0;

  const pageHtml = (p) => {
    const font = riwaya === "warsh" ? "warsh" : "quran";
    const fs = settings.fontSize * 0.86;
    const first = p.ayahs[0];
    let body = "", run = [];
    const flush = () => {
      if (!run.length) return;
      body += `<div class="${font}" style="font-size:${fs}px;line-height:1.85">${run.map((a) =>
        riwaya === "warsh" ? esc(a.text) : `${esc(a.text)} <span class="mark">۝${ar(a.n)}</span>`).join(" ")}</div>`;
      run = [];
    };
    for (const a of p.ayahs) {
      if (a.n === 1) {
        flush();
        body += `<div class="banner">سُورَةُ ${esc(surahName(riwaya, a.s))}</div>`;
        if (a.s !== 9 && !(riwaya === "hafs" && a.s === 1)) body += `<div class="basmala ${font}" style="font-size:${fs * 0.95}px">${BASMALA[riwaya]}</div>`;
      }
      run.push(a);
    }
    flush();
    return `<div class="page-inner">
      <div class="page-head"><span class="s">سورة ${esc(surahName(riwaya, first.s))}</span>
        <span>${riwaya === "hafs" ? "الجزء " + ar(juzOf(first.s, first.n)) : "ورش عن نافع"}</span></div>
      <div class="page-body">${body}</div>
      <div class="page-num">${starBadge(p.number, 38)}</div></div>`;
  };

  const draw = () => {
    host.innerHTML = `
      <div class="pages" id="pg">${pages.map((p, i) => `<section class="page" data-i="${i}"></section>`).join("")}</div>
      <div class="mushaf-bar top">
        <div class="hrow">
          <button class="icon-btn" data-a="back" aria-label="رجوع">${icon("back")}</button>
          <b class="grow gold" style="font-size:17px">المصحف • ${riwaya === "warsh" ? "ورش عن نافع" : "حفص عن عاصم"}</b>
          <button class="icon-btn" data-a="index" aria-label="فهرس السور">${icon("list")}</button>
        </div>
        <div class="chips" style="margin-top:8px">
          <button class="chip ${riwaya === "hafs" ? "on" : ""}" data-r="hafs">حفص عن عاصم</button>
          <button class="chip ${riwaya === "warsh" ? "on" : ""}" data-r="warsh">ورش عن نافع</button>
        </div>
      </div>
      <div class="mushaf-bar bottom">
        <div class="hrow"><span class="grow" id="pn"></span>
          <button class="chip on" data-a="play" style="display:flex;gap:6px;align-items:center">${icon("play", 'width="18" height="18"')}<span id="pl"></span></button></div>
        <input type="range" id="rg" min="1" max="${pages.length}" value="1" dir="rtl" aria-label="الصفحة">
      </div>`;
    const pg = host.querySelector("#pg");
    const fill = (i) => {
      for (let k = Math.max(0, i - 2); k <= Math.min(pages.length - 1, i + 2); k++) {
        const sec = pg.children[k];
        if (!sec.dataset.f) { sec.innerHTML = pageHtml(pages[k]); sec.dataset.f = "1"; }
      }
      // كنفرغو الصفحات البعاد باش يبقى خفيف
      for (const sec of pg.querySelectorAll("[data-f]")) {
        if (Math.abs(+sec.dataset.i - i) > 4) { sec.innerHTML = ""; delete sec.dataset.f; }
      }
    };
    const update = () => {
      const w = pg.clientWidth || 1;
      const x = Math.abs(pg.scrollLeft) / w;
      const i = Math.round(x);
      // تأثير قلبان الصفحة
      for (let k = Math.max(0, i - 1); k <= Math.min(pages.length - 1, i + 1); k++) {
        const inner = pg.children[k].firstElementChild;
        if (!inner) continue;
        const o = Math.max(-1, Math.min(1, k - x));
        inner.style.transform = `rotateY(${o * 16}deg) scale(${1 - 0.1 * Math.abs(o)})`;
        inner.style.opacity = String(1 - 0.45 * Math.abs(o));
      }
      if (i !== cur) { cur = i; fill(i); store.set(pageKey(), i + 1); }
      const p = pages[cur];
      host.querySelector("#pn").textContent = `صفحة ${ar(p.number)} من ${ar(pages.length)}`;
      host.querySelector("#pl").textContent = `استمع • ${surahName(riwaya, p.ayahs[0].s)}`;
      host.querySelector("#rg").value = String(cur + 1);
    };
    const go = (i, smooth = false) => {
      i = Math.max(0, Math.min(pages.length - 1, i));
      fill(i);
      pg.children[i].scrollIntoView({ inline: "center", block: "nearest", behavior: smooth ? "smooth" : "auto" });
      cur = -1; update();
    };
    pg.addEventListener("scroll", () => requestAnimationFrame(update), { passive: true });
    let downX = 0;
    pg.addEventListener("pointerdown", (e) => (downX = e.clientX));
    pg.addEventListener("click", (e) => { if (Math.abs(e.clientX - downX) < 8) host.classList.toggle("bare"); });
    host.querySelector("#rg").oninput = (e) => (host.querySelector("#pn").textContent = `صفحة ${ar(+e.target.value)} من ${ar(pages.length)}`);
    host.querySelector("#rg").onchange = (e) => go(+e.target.value - 1, false);
    host.querySelector(".mushaf-bar.top").onclick = async (e) => {
      const r = e.target.closest("[data-r]")?.dataset.r;
      if (r && r !== riwaya) {
        riwaya = r; setSetting("riwaya", r);
        host.innerHTML = spinner();
        pages = await mushafPages(riwaya);
        draw();
        return;
      }
      const a = e.target.closest("[data-a]")?.dataset.a;
      if (a === "back") history.back();
      if (a === "index") index(go);
    };
    host.querySelector("[data-a=play]").onclick = () => {
      const f = pages[cur].ayahs[0];
      riwaya === "hafs" ? playHafs(f.s, f.n) : playWarsh(f.s);
    };
    const target = startSurah ? pages.findIndex((p) => p.ayahs.some((a) => a.s === +startSurah)) : (store.get(pageKey(), 1) - 1);
    startSurah = 0;
    requestAnimationFrame(() => go(Math.max(0, target)));
  };

  const index = (go) => {
    openSheet(`<h3>فهرس السور</h3><div id="ix">${Array.from({ length: 114 }, (_, k) =>
      `<button class="item" data-s="${k + 1}">${starBadge(k + 1, 36)}<span class="quran" style="font-size:20px">سورة ${esc(surahName(riwaya, k + 1))}</span></button>`).join("")}</div>`, (sh) => {
      sh.querySelector("#ix").onclick = (e) => {
        const s = +e.target.closest("[data-s]")?.dataset.s; if (!s) return;
        closeSheet();
        go(pages.findIndex((p) => p.ayahs.some((a) => a.s === s)), false);
      };
    });
  };

  draw();
  return () => host.remove();
}
