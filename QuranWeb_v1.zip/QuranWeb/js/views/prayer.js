// مواقيت الصلاة (سما متحركة، عداد، قوس الشمس) + بوصلة القبلة
import { ar, esc, icon, ring, addParticles, store, openSheet, closeSheet, toast, starPoints } from "../util.js";
import { METHODS, PRAYERS, CITIES, compute, qibla, distanceKm, nowIn, hijri } from "../prayertimes.js";

const SKY = {
  fajr: "linear-gradient(#0B1033,#2B2F77,#5B4B8A)", dhuhr: "linear-gradient(#1E6FB8,#3FA9F5,#9ED8FF)",
  asr: "linear-gradient(#2B7BB9,#F2B35B,#FFD98E)", maghrib: "linear-gradient(#3B2667,#BC4E9C,#F8A26B)", isha: "linear-gradient(#050A1F,#0F1A3D,#1F2B5C)",
};
const hhmm = (m) => ar(`${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`);
const cfg = () => ({ city: CITIES[0].name, lat: CITIES[0].lat, lon: CITIES[0].lon, zone: CITIES[0].zone, method: "morocco", hanafi: false, ...store.get("prayer", {}) });
const save = (patch) => store.set("prayer", { ...cfg(), ...patch });

export function render(el) {
  let timer = 0, compassOff = null;

  const state = () => {
    const c = cfg();
    const { date, sec } = nowIn(c.zone);
    const t = compute(date, c.lat, c.lon, c.zone, c.method, c.hanafi);
    const order = ["fajr", "dhuhr", "asr", "maghrib", "isha"];
    let next = order.find((k) => t[k] * 60 > sec);
    let nextSec, prevSec;
    if (next) {
      nextSec = t[next] * 60;
      const i = order.indexOf(next);
      prevSec = i > 0 ? t[order[i - 1]] * 60 : (compute(new Date(date.getTime() - 864e5), c.lat, c.lon, c.zone, c.method, c.hanafi).isha - 1440) * 60;
    } else {
      next = "fajr";
      nextSec = (compute(new Date(date.getTime() + 864e5), c.lat, c.lon, c.zone, c.method, c.hanafi).fajr + 1440) * 60;
      prevSec = t.isha * 60;
    }
    return { c, date, sec, t, next, nextSec, progress: Math.min(1, Math.max(0, (sec - prevSec) / (nextSec - prevSec))) };
  };

  const draw = () => {
    const s = state();
    const night = s.next === "fajr" || s.next === "isha";
    const q = qibla(s.c.lat, s.c.lon);
    el.innerHTML = `
      <section class="sky" style="background:${SKY[s.next]}">
        <svg class="pattern" id="arc"></svg>
        <div class="content">
          <div class="hrow">
            <button class="grow city" data-a="city" style="text-align:start;color:#fff"><b>${esc(s.c.city)} ▾</b><small>${hijri(s.date)} • ${s.date.toLocaleDateString("ar-MA")}</small></button>
            <button class="icon-btn" data-a="loc" aria-label="موقعي">${icon("location")}</button>
            <button class="icon-btn" data-a="opt" aria-label="طريقة الحساب">${icon("tune")}</button>
          </div>
          <div class="countdown">${ring(s.progress, 190, 10)}<div class="lbl">
            <b>${PRAYERS.find((p) => p[0] === s.next)[2]} ${PRAYERS.find((p) => p[0] === s.next)[1]}</b>
            <span class="t" id="cd"></span><small>على ${hhmm(Math.round(s.nextSec / 60) % 1440)}</small></div></div>
        </div>
      </section>
      <div class="stagger" style="margin-top:12px">${PRAYERS.map(([k, n, e], i) => `<div class="prayer-row ${k === s.next ? "next" : ""}" style="animation-delay:${i * 50}ms">
        <span style="font-size:22px">${e}</span><span class="n">${n}</span>${k === s.next ? `<small style="color:var(--primary)">الجاية</small>` : ""}<span class="t">${hhmm(s.t[k])}</span></div>`).join("")}</div>
      <section class="qibla">
        <b class="gold" style="font-size:20px">🕋 اتجاه القبلة</b>
        <div style="font-size:13px;opacity:.85">${ar(Math.round(q))}° من الشمال • ${ar(Math.round(distanceKm(s.c.lat, s.c.lon)))} كلم للكعبة</div>
        <div class="compass" id="cmp">${compassSvg(q)}</div>
        <div id="qmsg">دور التلفون حتى يتلاقى السهم الذهبي مع الفوق</div>
        <button class="btn gold" id="qbtn" style="margin-top:10px">🧭 شعل البوصلة</button>
        <div style="font-size:11px;opacity:.6;margin-top:8px">💡 بعد التلفون على الحديد والمغناطيس</div>
      </section>
      <p class="muted" style="margin:12px 20px;font-size:12px">⚠️ المواقيت محسوبة فلكيا (${METHODS[s.c.method].label}). التوقيت الرسمي يقدر يختالف بدقيقة ولا جوج.</p>`;
    addParticles(el.querySelector(".sky"), night ? { count: 40, color: "255,255,255" } : { count: 14 });
    requestAnimationFrame(() => requestAnimationFrame(() => el.querySelectorAll(".arc[data-target]").forEach((a) => (a.style.strokeDashoffset = a.dataset.target))));
    sunArc(el.querySelector("#arc"), s);
    el.querySelector(".sky").onclick = (e) => {
      const a = e.target.closest("[data-a]")?.dataset.a;
      if (a === "city") cities();
      if (a === "loc") locate();
      if (a === "opt") options();
    };
    el.querySelector("#qbtn").onclick = startCompass;
    tick();
  };

  const tick = () => {
    const s = state();
    const cd = el.querySelector("#cd");
    if (!cd) return;
    const r = Math.max(0, s.nextSec - s.sec);
    cd.textContent = ar(`${String(Math.floor(r / 3600)).padStart(2, "0")}:${String(Math.floor((r % 3600) / 60)).padStart(2, "0")}:${String(r % 60).padStart(2, "0")}`);
    const arc = el.querySelector(".countdown .arc");
    if (arc) { const c = +arc.getAttribute("stroke-dasharray"); arc.style.strokeDashoffset = String(c * (1 - s.progress)); }
    if (r === 0) setTimeout(draw, 1500);
  };

  const cities = () => openSheet(`<h3>اختار المدينة</h3>
      <button class="item" data-loc="1">${icon("location")}📍 استعمل موقعي (GPS)</button>
      ${CITIES.map((c, i) => `<button class="item" data-i="${i}">${icon("mosque")}<span style="${c.name === cfg().city ? "font-weight:700" : ""}">${esc(c.name)}</span></button>`).join("")}`,
    (sh, close) => {
      sh.onclick = (e) => {
        if (e.target.closest("[data-loc]")) { close(); locate(); return; }
        const i = e.target.closest("[data-i]")?.dataset.i; if (i == null) return;
        const c = CITIES[+i]; save({ city: c.name, lat: c.lat, lon: c.lon, zone: c.zone }); close(); draw();
      };
    });

  const options = () => openSheet(`<h3>طريقة الحساب</h3>
      ${Object.entries(METHODS).map(([k, m]) => `<button class="item" data-m="${k}"><span style="font-size:20px">${cfg().method === k ? "🔘" : "⚪"}</span>${m.label}</button>`).join("")}
      <button class="item" data-h="1"><span style="font-size:20px">${cfg().hanafi ? "☑️" : "⬜"}</span>العصر حسب المذهب الحنفي</button>`,
    (sh, close) => {
      sh.onclick = (e) => {
        const m = e.target.closest("[data-m]")?.dataset.m;
        if (m) { save({ method: m }); close(); draw(); }
        if (e.target.closest("[data-h]")) { save({ hanafi: !cfg().hanafi }); close(); draw(); }
      };
    });

  const locate = () => {
    if (!navigator.geolocation) return toast("الموقع ما متوفرش، اختار المدينة");
    toast("كنقلبو على موقعك…");
    navigator.geolocation.getCurrentPosition(
      (p) => { save({ city: "📍 موقعي", lat: p.coords.latitude, lon: p.coords.longitude, zone: Intl.DateTimeFormat().resolvedOptions().timeZone }); toast("تم تحديد موقعك ✓"); draw(); },
      () => toast("ما قدرناش نلقاو الموقع. اختار المدينة من اللائحة"),
      { enableHighAccuracy: false, timeout: 15000, maximumAge: 6 * 3600e3 },
    );
  };

  // ───────────── البوصلة ─────────────
  const startCompass = async () => {
    const DOE = window.DeviceOrientationEvent;
    if (!DOE) return toast("التلفون ما فيهش البوصلة");
    try {
      // iPhone كيطلب الإذن
      if (typeof DOE.requestPermission === "function" && (await DOE.requestPermission()) !== "granted") return toast("خاص الإذن ديال البوصلة");
    } catch { return toast("خاص الإذن ديال البوصلة"); }
    const btn = el.querySelector("#qbtn"); if (btn) btn.hidden = true;
    let heading = 0;
    const q = qibla(cfg().lat, cfg().lon);
    const on = (e) => {
      let h = null;
      if (typeof e.webkitCompassHeading === "number") h = e.webkitCompassHeading; // iPhone
      else if (e.absolute && e.alpha != null) h = 360 - e.alpha;
      if (h == null) return;
      // أقصر دورة
      let d = h - (heading % 360); if (d > 180) d -= 360; if (d < -180) d += 360;
      heading += d;
      const dial = el.querySelector(".compass .dial"); if (!dial) return;
      dial.style.transform = `rotate(${-heading}deg)`;
      const diff = ((((q - h) % 360) + 540) % 360) - 180;
      const ok = Math.abs(diff) < 4;
      el.querySelector(".compass").classList.toggle("aligned", ok);
      const msg = el.querySelector("#qmsg");
      if (msg) { msg.textContent = ok ? "✅ نتا مقابل القبلة" : "دور التلفون حتى يتلاقى السهم الذهبي مع الفوق"; msg.style.color = ok ? "#7CF0C3" : ""; }
      if (ok && navigator.vibrate) navigator.vibrate(30);
    };
    const evt = "ondeviceorientationabsolute" in window ? "deviceorientationabsolute" : "deviceorientation";
    window.addEventListener(evt, on);
    compassOff = () => window.removeEventListener(evt, on);
  };

  draw();
  timer = setInterval(tick, 1000);
  return () => { clearInterval(timer); compassOff?.(); };
}

function compassSvg(q) {
  const ticks = Array.from({ length: 72 }, (_, k) => {
    const len = k % 18 === 0 ? 14 : k % 2 === 0 ? 8 : 4;
    return `<line x1="125" y1="9" x2="125" y2="${9 + len}" stroke="#fff" stroke-opacity="${k % 18 === 0 ? 0.9 : 0.35}" stroke-width="1.5" transform="rotate(${k * 5} 125 125)"/>`;
  }).join("");
  return `<svg class="dial" viewBox="0 0 250 250">
    <circle cx="125" cy="125" r="124" fill="rgba(255,255,255,.06)"/>
    <circle class="ring-c" cx="125" cy="125" r="121" fill="none" stroke="#D4AF37" stroke-width="3"/>${ticks}
    <polygon points="125,26 117,44 133,44" fill="#E74C3C"/>
    <g transform="rotate(${q} 125 125)">
      <line x1="125" y1="125" x2="125" y2="38" stroke="#D4AF37" stroke-width="6" stroke-linecap="round"/>
      <circle cx="125" cy="35" r="24" fill="#D4AF37" fill-opacity=".25"><animate attributeName="r" values="18;26;18" dur="1.6s" repeatCount="indefinite"/></circle>
      <rect x="112" y="22" width="26" height="26" fill="#1E1E1E"/><rect x="112" y="29" width="26" height="5" fill="#D4AF37"/>
    </g>
    <polygon points="${starPoints(125, 125, 12)}" fill="#D4AF37"/></svg>`;
}

/** قوس الشمس من الشروق للغروب: كيدور على الحلقة من برا باش ما يغطيش العداد */
function sunArc(svg, s) {
  const box = svg.parentElement.getBoundingClientRect();
  const w = box.width, h = box.height;
  svg.setAttribute("viewBox", `0 0 ${w} ${h}`);
  svg.removeAttribute("preserveAspectRatio");
  const rise = s.t.sunrise * 60, set = s.t.maghrib * 60;
  const day = s.sec > rise && s.sec < set;
  const f = day ? (s.sec - rise) / (set - rise) : 0.5;
  const cx = w / 2, by = h - 6, rx = w / 2 - 14, ry = h - 60;
  const pts = [];
  for (let k = 0; k <= 60; k++) { const a = Math.PI * (1 - k / 60); pts.push(`${(cx + rx * Math.cos(a)).toFixed(1)},${(by - ry * Math.sin(a)).toFixed(1)}`); }
  // فـ RTL الشروق على اليمين
  const a = Math.PI * f, x = cx + rx * Math.cos(a), y = by - ry * Math.sin(a);
  svg.innerHTML = `<polyline points="${pts.join(" ")}" fill="none" stroke="#fff" stroke-opacity=".2" stroke-width="2" stroke-dasharray="4 6"/>` + (day
    ? `<circle cx="${x}" cy="${y}" r="20" fill="#FFE27A" fill-opacity=".3"><animate attributeName="r" values="14;22;14" dur="2s" repeatCount="indefinite"/></circle><circle cx="${x}" cy="${y}" r="9" fill="#FFE27A"/>`
    : `<circle cx="${cx}" cy="${by - ry}" r="11" fill="#F5F3CE"/><circle cx="${cx + 6}" cy="${by - ry - 4}" r="9" fill="#0F1A3D"/>`);
}
