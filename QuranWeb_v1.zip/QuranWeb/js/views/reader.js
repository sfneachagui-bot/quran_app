import { ar, esc, icon, pattern, spinner } from "../util.js";
import { loadQuran, Q, settings, setSetting, juzOf, hizbLabel, isQuarterStart, bookmarks, saveLastRead } from "../data.js";
import { onPlayer, current } from "../player.js";
import { playHafs, ayahMenu } from "../actions.js";

export async function render(el, [sid, aid]) {
  el.innerHTML = spinner();
  await loadQuran();
  const sId = Math.min(114, Math.max(1, +sid || 1));
  const s = Q.surahs[sId - 1];
  const start = Math.min(s.ayahs.length, Math.max(1, +aid || 1));

  const draw = () => {
    const bm = new Set(bookmarks());
    const fs = settings.fontSize;
    const basmala = s.id !== 1 && s.id !== 9 ? `<div class="b">بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ</div>` : "";
    const head = `<div class="surah-head">${pattern()}<div class="n">سورة ${esc(s.name)}</div>
      <div class="m">${esc(s.tr)} • ${s.meccan ? "مكية" : "مدنية"} • ${ar(s.ayahs.length)} آية</div>${basmala}</div>`;
    const mark = (a) => `<span class="mark ${bm.has(`${a.s}:${a.n}`) ? "bm" : ""}">۝${ar(a.n)}</span>`;
    const q = (a) => (isQuarterStart(a.s, a.n) && !(a.s === 1 && a.n === 1) ? `<span class="quarter">۞ </span>` : "");
    let body;
    if (settings.cardMode) {
      body = s.ayahs.map((a) => `<div class="ayah-card" data-n="${a.n}">
        <div class="ar" style="font-size:${fs}px;line-height:1.9">${q(a)}${esc(a.text)} ${mark(a)}</div>
        ${settings.translation !== "none" ? `<div class="tr ltr">${esc(settings.translation === "en" ? a.en : a.fr)}</div>` : ""}</div>`).join("");
    } else {
      body = `<div class="mushaf-text" style="font-size:${fs}px;line-height:1.95">${s.ayahs.map((a) => `<span class="ay" data-n="${a.n}">${q(a)}${esc(a.text)} ${mark(a)}</span>`).join(" ")}</div>`;
    }
    el.innerHTML = `
      <header class="reader-top">${pattern(0.06)}<div class="content">
        <a class="icon-btn" href="#/home" aria-label="رجوع">${icon("back")}</a>
        <div class="ttl"><b>سورة ${esc(s.name)}</b><small id="pos"></small></div>
        <button class="icon-btn" data-a="font" aria-label="حجم الخط">${icon("text")}</button>
        <button class="icon-btn" data-a="mode" aria-label="وضع القراءة">${icon(settings.cardMode ? "book" : "list")}</button>
        <button class="icon-btn" data-a="play" aria-label="استمع" style="background:#D4AF37;color:#0F5132">${icon("play")}</button>
      </div></header>
      ${head}
      <div id="body">${body}</div>
      <div style="display:flex;gap:10px;padding:10px 16px 20px">
        ${s.id > 1 ? `<a class="btn outline" style="flex:1" href="#/reader/${s.id - 1}/1">السورة السابقة</a>` : ""}
        ${s.id < 114 ? `<a class="btn" style="flex:1" href="#/reader/${s.id + 1}/1">السورة التالية</a>` : ""}
      </div>`;
    el.querySelector(".reader-top").onclick = (e) => {
      const b = e.target.closest("[data-a]"); if (!b) return;
      if (b.dataset.a === "play") playHafs(s.id, topAyah());
      if (b.dataset.a === "mode") { const a = topAyah(); setSetting("cardMode", !settings.cardMode); draw(); scrollTo(a, false); }
      if (b.dataset.a === "font") { const a = topAyah(); setSetting("fontSize", settings.fontSize >= 40 ? 20 : settings.fontSize + 4); draw(); scrollTo(a, false); }
    };
    el.querySelector("#body").onclick = (e) => {
      const n = e.target.closest("[data-n]")?.dataset.n; if (!n) return;
      ayahMenu(s.ayahs[n - 1], () => { const a = topAyah(); draw(); scrollTo(a, false); });
    };
    highlight();
  };

  const nodes = () => el.querySelectorAll("[data-n]");
  const topAyah = () => {
    const top = 110;
    for (const n of nodes()) if (n.getBoundingClientRect().bottom > top) return +n.dataset.n;
    return 1;
  };
  const scrollTo = (n, smooth) => {
    const node = el.querySelector(`[data-n="${n}"]`);
    if (!node) return;
    const y = node.getBoundingClientRect().top + window.scrollY - 100;
    window.scrollTo({ top: Math.max(0, y), behavior: smooth ? "smooth" : "auto" });
  };
  const highlight = () => {
    const c = current();
    const n = c?.ref && c.ref[0] === s.id ? c.ref[1] : 0;
    nodes().forEach((x) => x.classList.toggle("hl", +x.dataset.n === n));
    return n;
  };

  draw();
  if (start > 1) requestAnimationFrame(() => scrollTo(start, false));

  // تتبع المقرئ: الآية اللي كتتقرا كتلون والصفحة كتنزل معاها
  let lastN = 0;
  const off = onPlayer(() => { const n = highlight(); if (n && n !== lastN) { lastN = n; scrollTo(n, true); } });

  // حفظ آخر قراءة + إخفاء الشريط ملي كننزلو
  let t = 0, lastY = window.scrollY;
  const onScroll = () => {
    const top = el.querySelector(".reader-top");
    if (top) top.classList.toggle("hide", window.scrollY > lastY && window.scrollY > 160);
    lastY = window.scrollY;
    const pos = el.querySelector("#pos");
    clearTimeout(t);
    t = setTimeout(() => {
      const a = topAyah();
      saveLastRead(s.id, a);
      if (pos) pos.textContent = `الآية ${ar(a)} • الجزء ${ar(juzOf(s.id, a))} • ${hizbLabel(s.id, a)}`;
    }, 600);
  };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
  return () => { off(); window.removeEventListener("scroll", onScroll); clearTimeout(t); };
}
