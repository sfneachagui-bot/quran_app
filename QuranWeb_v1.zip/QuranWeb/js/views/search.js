// البحث فالقرآن + العلامات
import { ar, esc, icon, pattern, spinner } from "../util.js";
import { loadQuran, Q, search, bookmarks, toggleBookmark } from "../data.js";

const header = (title, sub) => `<section class="page-header">${pattern()}<div class="content"><div class="hrow">
  <a class="icon-btn" href="#/home">${icon("back")}</a><div class="grow"><h2>${title}</h2>${sub ? `<p>${sub}</p>` : ""}</div></div></div></section>`;

const card = (a, i, extra = "") => `<a class="ayah-card press" href="#/reader/${a.s}/${a.n}" style="display:block;animation-delay:${Math.min(i, 14) * 40}ms">
  <div class="hrow"><b class="grow" style="color:var(--primary)">سورة ${esc(Q.surahs[a.s - 1].name)} • الآية ${ar(a.n)}</b>${extra}</div>
  <div class="ar" style="font-size:22px;line-height:1.9">${esc(a.text)}</div></a>`;

export async function render(el, _p, path) {
  el.innerHTML = spinner();
  await loadQuran();
  if (path === "bookmarks") return bookmarksView(el);
  el.innerHTML = `${header("البحث فالقرآن", "بالعربية (بلا تشكيل) ولا بالفرنسية/الإنجليزية")}
    <div class="search-box">${icon("search")}<input id="q" type="search" placeholder="مثلا: الصراط المستقيم، patience…" autocomplete="off"></div>
    <div class="muted" id="cnt" style="margin:0 20px"></div><div id="res" class="stagger"></div>`;
  const q = el.querySelector("#q");
  let t = 0;
  q.oninput = () => {
    clearTimeout(t);
    t = setTimeout(() => {
      const r = search(q.value);
      el.querySelector("#cnt").textContent = q.value.trim().length >= 2 ? `${ar(r.length)} نتيجة` : "";
      el.querySelector("#res").innerHTML = r.map((a, i) => card(a, i)).join("");
    }, 300);
  };
  setTimeout(() => q.focus(), 300);
}

function bookmarksView(el) {
  const draw = () => {
    const list = bookmarks().map((k) => k.split(":").map(Number)).sort((a, b) => a[0] - b[0] || a[1] - b[1])
      .map(([s, n]) => Q.surahs[s - 1]?.ayahs[n - 1]).filter(Boolean);
    el.innerHTML = `${header("العلامات 🔖", `${ar(list.length)} آية`)}
      <div class="stagger">${list.length ? list.map((a, i) => card(a, i, `<button class="icon-btn" style="background:var(--surface-2);color:var(--muted)" data-k="${a.s}:${a.n}">${icon("trash")}</button>`)).join("")
        : `<div class="empty">ما زال ما زدتي حتى علامة.<br>ضغط على أي آية فالقراءة ← "إضافة علامة".</div>`}</div>`;
    el.querySelectorAll("[data-k]").forEach((b) => (b.onclick = (e) => { e.preventDefault(); toggleBookmark(b.dataset.k); draw(); }));
  };
  draw();
}
