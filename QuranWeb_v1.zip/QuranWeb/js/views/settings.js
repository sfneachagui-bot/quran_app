import { esc, icon, pattern } from "../util.js";
import { settings, setSetting, RECITERS, TAFSIRS } from "../data.js";
import { applyTheme } from "../main.js";

export function render(el) {
  const chip = (group, val, label, on) => `<button class="chip ${on ? "on" : ""}" data-g="${group}" data-v="${val}">${label}</button>`;
  const draw = () => {
    el.innerHTML = `<section class="page-header">${pattern()}<div class="content"><div class="hrow">
        <a class="icon-btn" href="#/home">${icon("back")}</a><div class="grow"><h2>الإعدادات</h2></div></div></div></section>
      ${isStandalone() ? "" : `<div class="install-tip"><b>📲 زيد التطبيق للشاشة الرئيسية</b><br>
        على iPhone: فـ Safari ضغط على <b>مشاركة</b> (المربع بالسهم) ← <b>"إضافة إلى الشاشة الرئيسية"</b>. هكا كيتحل بالشاشة الكاملة وكيخدم بلا أنترنيت.<br>
        على Android: القائمة ⋮ ← "تثبيت التطبيق".</div>`}
      <div class="section-title">حجم خط المصحف</div>
      <div class="card"><div class="quran" style="font-size:${settings.fontSize}px;line-height:1.9;text-align:center">ٱلۡحَمۡدُ لِلَّهِ رَبِّ ٱلۡعَٰلَمِينَ</div>
        <input type="range" min="18" max="44" step="1" value="${settings.fontSize}" id="fs" aria-label="حجم الخط"></div>
      <div class="section-title">وضع القراءة</div>
      <div class="chips light" style="padding:0 16px;flex-wrap:wrap">${chip("cardMode", "0", "مصحف (نص متصل)", !settings.cardMode)}${chip("cardMode", "1", "آية بآية مع الترجمة", settings.cardMode)}</div>
      <div class="section-title">الترجمة (فوضع آية بآية)</div>
      <div class="chips light" style="padding:0 16px">${[["none", "بلا ترجمة"], ["fr", "Français"], ["en", "English"]].map(([v, l]) => chip("translation", v, l, settings.translation === v)).join("")}</div>
      <div class="section-title">التفسير</div>
      <div class="chips light" style="padding:0 16px;flex-wrap:wrap">${TAFSIRS.map((t) => chip("tafsir", t.id, t.label, settings.tafsir === t.id)).join("")}</div>
      <div class="section-title">المظهر</div>
      <div class="chips light" style="padding:0 16px">${[["auto", "تلقائي"], ["light", "☀️ فاتح"], ["dark", "🌙 ليلي"]].map(([v, l]) => chip("theme", v, l, settings.theme === v)).join("")}</div>
      <div class="section-title">الاستماع بلا أنترنيت</div>
      <div style="padding:0 16px"><a class="btn outline block" href="#/downloads">🎧 تحميل السور (حفص ولا ورش)</a></div>
      <div class="section-title">القارئ</div>
      <div class="card" style="padding:4px 0">${RECITERS.map((r) => `<button class="item" data-g="reciter" data-v="${r.id}" style="display:flex;gap:12px;width:100%;padding:12px 16px;text-align:start">
        <span>${settings.reciter === r.id ? "🔘" : "⚪"}</span>${esc(r.name)}</button>`).join("")}</div>
      <p class="muted" style="margin:20px 16px;font-size:12px;line-height:1.8">مصادر: نص المصحف (الرسم العثماني) والترجمات من quran-json (quranenc.com و tanzil.net) • التفسير من api.alquran.cloud والمختصر بالفرنسية من tafsir_api (spa5k) •
        نص ورش وخطه من مجمع الملك فهد (KFGQPC) • الصفحات والأجزاء من quran-meta • التلاوات من everyayah.com وتلاوات ورش من mp3quran.net • الأحاديث من hadith-api (fawazahmed0) •
        الأدعية من حصن المسلم (hisnmuslim.com) • خط Amiri Quran (OFL).</p>`;
    el.querySelector("#fs").oninput = (e) => { setSetting("fontSize", +e.target.value); el.querySelector(".card .quran").style.fontSize = e.target.value + "px"; };
    el.onclick = (e) => {
      const b = e.target.closest("[data-g]"); if (!b) return;
      const g = b.dataset.g, v = b.dataset.v;
      setSetting(g, g === "cardMode" ? v === "1" : v);
      if (g === "theme") applyTheme();
      draw();
    };
  };
  draw();
  return () => (el.onclick = null);
}

const isStandalone = () => window.matchMedia("(display-mode: standalone)").matches || navigator.standalone === true;
