// Service Worker: كيخبي التطبيق والمعطيات باش يخدم بلا أنترنيت
const VERSION = "quran-web-v1";
const SHELL = [
  "./",
  "css/app.css",
  "data/hadith_meta.json",
  "data/hadith_offline.json",
  "data/kids.json",
  "data/pages_hafs.json",
  "data/parts.json",
  "data/quran.json",
  "data/warsh.json",
  "fonts/amiri_quran.ttf",
  "fonts/warsh_uthmani.ttf",
  "icons/apple-touch-icon.png",
  "icons/icon-512-maskable.png",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "index.html",
  "js/actions.js",
  "js/data.js",
  "js/main.js",
  "js/player.js",
  "js/prayertimes.js",
  "js/util.js",
  "js/views/downloads.js",
  "js/views/duas.js",
  "js/views/hadith.js",
  "js/views/home.js",
  "js/views/kids.js",
  "js/views/mushaf.js",
  "js/views/prayer.js",
  "js/views/reader.js",
  "js/views/search.js",
  "js/views/settings.js",
  "kids/salah_01_wudu.svg",
  "kids/salah_02_qibla.svg",
  "kids/salah_03_niyyah.svg",
  "kids/salah_04_takbir.svg",
  "kids/salah_05_qiyam.svg",
  "kids/salah_06_ruku.svg",
  "kids/salah_07_itidal.svg",
  "kids/salah_08_sujud.svg",
  "kids/salah_09_julus.svg",
  "kids/salah_10_sujud2.svg",
  "kids/salah_11_tashahhud.svg",
  "kids/salah_12_salawat.svg",
  "kids/salah_13_salam.svg",
  "kids/wudu_01_niyyah.svg",
  "kids/wudu_02_bismillah.svg",
  "kids/wudu_03_hands.svg",
  "kids/wudu_04_mouth.svg",
  "kids/wudu_05_nose.svg",
  "kids/wudu_06_face.svg",
  "kids/wudu_07_arms.svg",
  "kids/wudu_08_head.svg",
  "kids/wudu_09_ears.svg",
  "kids/wudu_10_feet.svg",
  "kids/wudu_11_dua.svg",
  "manifest.webmanifest",
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith("quran-web-") && k !== VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== location.origin) return; // الصوت والـ API كيتسيرو فالتطبيق
  e.respondWith(
    caches.match(e.request, { ignoreSearch: true }).then((hit) => hit || fetch(e.request).then((r) => {
      if (r.ok) { const copy = r.clone(); caches.open(VERSION).then((c) => c.put(e.request, copy)); }
      return r;
    }).catch(() => caches.match("index.html"))),
  );
});
